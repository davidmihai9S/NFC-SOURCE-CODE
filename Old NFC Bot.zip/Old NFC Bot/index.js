const { Client, GatewayIntentBits, Partials } = require('discord.js');
const config = require('./config');
const { initDatabase } = require('./database');
const { revertExpiredTemporaryGrants } = require('./economy');
const { revertExpiredTemporaryCardGrants } = require('./tempCards');
const fs = require('fs');

// Global state
const activeGames = new Map();
const activeQuizzes = new Map();
const activeQuoteQuizzes = new Map();
const chatCooldowns = new Map();
const pendingTrades = new Map();
const catchCount = {};

// Per-server spawn tracking (replaces global messageCount)
const spawnTrackers = new Map(); // guildId -> { messageCount: number, lastSpawn: timestamp }

function getSpawnTracker(guildId) {
    if (!spawnTrackers.has(guildId)) {
        spawnTrackers.set(guildId, { messageCount: 0, lastSpawn: 0 });
    }
    return spawnTrackers.get(guildId);
}

function canSpawn(guildId) {
    const tracker = getSpawnTracker(guildId);
    const now = Date.now();
    if (now - tracker.lastSpawn >= 20000) { // 20 seconds cooldown
        tracker.lastSpawn = now;
        return true;
    }
    return false;
}

const bot = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMessageReactions,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction]
});

bot.invPages = new Map();
bot.invViews = new Map();
bot.duelData = {};

// Export for other modules
module.exports = {
    bot,
    activeGames,
    activeQuizzes,
    activeQuoteQuizzes,
    chatCooldowns,
    pendingTrades,
    catchCount,
    getSpawnTracker,
    canSpawn
};

// Load events
const readyEvent = require('./events/ready');
const messageEvent = require('./events/messageCreate');
const interactionEvent = require('./events/interactionCreate');
const reactionAddEvent = require('./events/messageReactionAdd');

bot.once(readyEvent.name, (...args) => readyEvent.execute(...args));
bot.on(messageEvent.name, (...args) => messageEvent.execute(...args));
bot.on(interactionEvent.name, (...args) => interactionEvent.execute(...args));
bot.on(reactionAddEvent.name, (...args) => reactionAddEvent.execute(...args));

// Periodic cleanups
setInterval(() => {
    const now = Date.now();
    for (const [key, game] of activeGames) {
        if (!game.active && (now - game.createdAt) > 600000) {
            game.stop?.();
            activeGames.delete(key);
        }
    }
    for (const [key, quiz] of activeQuizzes) {
        if (!quiz.active && (now - quiz.createdAt) > 600000) {
            quiz.stop?.();
            activeQuizzes.delete(key);
        }
    }
    for (const [key, game] of activeQuoteQuizzes) {
        if (!game.active && (now - game.createdAt) > 600000) {
            game.stop?.();
            activeQuoteQuizzes.delete(key);
        }
    }
}, 60000);

setInterval(() => {
    const now = Date.now();
    for (const [key, ts] of chatCooldowns) {
        if (now - ts > 3600000) chatCooldowns.delete(key);
    }
}, 300000);

setInterval(() => {
    const now = Date.now();
    if (bot.invPages) {
        for (const [key, data] of bot.invPages) {
            if (now - data.timestamp > 600000) bot.invPages.delete(key);
        }
    }
    if (bot.invViews) {
        for (const [key, data] of bot.invViews) {
            if (now - data.timestamp > 600000) bot.invViews.delete(key);
        }
    }
}, 300000);

setInterval(() => {
    revertExpiredTemporaryGrants().catch(console.error);
}, 30000);

setInterval(() => {
    revertExpiredTemporaryCardGrants().catch(console.error);
}, 30000);

// Dashboard file watchers
setInterval(() => {
    if (fs.existsSync('reload.flag')) {
        try {
            const newCards = JSON.parse(fs.readFileSync('cards.json', 'utf8'));
            require('./helpers').ninjagoCards.length = 0;
            require('./helpers').ninjagoCards.push(...newCards);
            console.log(`[RELOAD] Reloaded cards.json (${require('./helpers').ninjagoCards.length} cards)`);
        } catch (err) {
            console.error('[RELOAD] Failed to reload cards.json:', err);
        }
        fs.unlinkSync('reload.flag');
    }
}, 2000);

setInterval(() => {
    if (fs.existsSync('broadcast.txt')) {
        const message = fs.readFileSync('broadcast.txt', 'utf8');
        for (const guild of bot.guilds.cache.values()) {
            const channel = guild.systemChannel || guild.channels.cache.find(c => c.type === 0 && c.permissionsFor(guild.members.me).has('SendMessages'));
            if (channel) channel.send(`📢 **Dashboard Broadcast:**\n${message}`).catch(() => {});
        }
        fs.unlinkSync('broadcast.txt');
        console.log('[BROADCAST] Sent to all servers');
    }
}, 5000);

setInterval(() => {
    if (fs.existsSync('dm.txt')) {
        const data = JSON.parse(fs.readFileSync('dm.txt', 'utf8'));
        bot.users.fetch(data.userId).then(user => {
            if (user) user.send(`📩 **Dashboard DM:**\n${data.message}`).catch(err => console.error(`Failed to DM ${data.userId}:`, err.message));
        }).catch(() => {});
        fs.unlinkSync('dm.txt');
    }
}, 5000);

// Start bot
(async () => {
    await initDatabase();
    await revertExpiredTemporaryGrants();
    await bot.login(config.TOKEN);
})();
