const { EmbedBuilder } = require('discord.js');
const { getDb } = require('./database');

const GAME_STAT_KEYS = {
    episode: { key: 'episode', label: 'Episode Guesser' },
    ep: { key: 'episode', label: 'Episode Guesser' },
    epguesser: { key: 'episode', label: 'Episode Guesser' },
    quote: { key: 'quote', label: 'Quote Guesser' },
    quotequiz: { key: 'quote', label: 'Quote Guesser' },
    quiz: { key: 'quiz', label: 'Quiz' },
    trivia: { key: 'quiz', label: 'Quiz' },
    blacktea: { key: 'blacktea', label: 'Black Tea' },
    black: { key: 'blacktea', label: 'Black Tea' },
    greentea: { key: 'greentea', label: 'Green Tea' },
    green: { key: 'greentea', label: 'Green Tea' },
    location: { key: 'location', label: 'Location Guesser' },
    locationguesser: { key: 'location', label: 'Location Guesser' },
    set: { key: 'set', label: 'Set Guesser' },
    setguesser: { key: 'set', label: 'Set Guesser' },
    minifigure: { key: 'minifigure', label: 'Minifigure Guesser' },
    minifig: { key: 'minifigure', label: 'Minifigure Guesser' },
    minifigureguesser: { key: 'minifigure', label: 'Minifigure Guesser' },
    minifigguesser: { key: 'minifigure', label: 'Minifigure Guesser' },
    tictactoe: { key: 'tictactoe', label: 'Tic Tac Toe' },
    ttt: { key: 'tictactoe', label: 'Tic Tac Toe' },
    blackjack: { key: 'blackjack', label: 'Blackjack' },
    bj: { key: 'blackjack', label: 'Blackjack' },
};

const GAME_CHOICES = [
    { name: 'Episode Guesser', value: 'episode' },
    { name: 'Quote Guesser', value: 'quote' },
    { name: 'Quiz', value: 'quiz' },
    { name: 'Black Tea', value: 'blacktea' },
    { name: 'Green Tea', value: 'greentea' },
    { name: 'Location Guesser', value: 'location' },
    { name: 'Set Guesser', value: 'set' },
    { name: 'Minifigure Guesser', value: 'minifigure' },
    { name: 'Tic Tac Toe', value: 'tictactoe' },
    { name: 'Blackjack', value: 'blackjack' },
];

function resolveGameStat(value) {
    return GAME_STAT_KEYS[String(value || '').toLowerCase().trim()] || null;
}

async function recordGameWin(statKey, userId, amount = 1) {
    const db = getDb();
    await db.run(
        'INSERT INTO game_stats (statKey, userId, wins) VALUES (?, ?, ?) ON CONFLICT(statKey, userId) DO UPDATE SET wins = wins + excluded.wins',
        [statKey, userId, amount]
    );
}

async function getGameLeaderboard(statKey, limit = 10) {
    const db = getDb();
    return db.all(
        'SELECT userId, wins FROM game_stats WHERE statKey=? ORDER BY wins DESC, userId ASC LIMIT ?',
        [statKey, limit]
    );
}

async function getGameRank(statKey, userId) {
    const db = getDb();
    const row = await db.get('SELECT wins FROM game_stats WHERE statKey=? AND userId=?', [statKey, userId]);
    const wins = row?.wins || 0;
    if (!wins) return { rank: 'N/A', wins: 0 };
    const rankRow = await db.get(
        'SELECT COUNT(*) + 1 AS rank FROM game_stats WHERE statKey=? AND wins > ?',
        [statKey, wins]
    );
    return { rank: rankRow?.rank || 1, wins };
}

async function getCoinsLeaderboard(limit = 10) {
    const db = getDb();
    return db.all(
        'SELECT userId, nfcoins FROM economy ORDER BY nfcoins DESC, userId ASC LIMIT ?',
        [limit]
    );
}

async function getCoinsRank(userId) {
    const db = getDb();
    const row = await db.get('SELECT nfcoins FROM economy WHERE userId=?', [userId]);
    const coins = row?.nfcoins || 0;
    if (!coins) return { rank: 'N/A', coins: 0 };
    const rankRow = await db.get(
        'SELECT COUNT(*) + 1 AS rank FROM economy WHERE nfcoins > ?',
        [coins]
    );
    return { rank: rankRow?.rank || 1, coins };
}

async function buildCoinsLeaderboardEmbed(bot, viewerId) {
    const top = await getCoinsLeaderboard();
    const lines = [];
    for (let i = 0; i < top.length; i++) {
        const user = await bot.users.fetch(top[i].userId).catch(() => null);
        lines.push(`${i + 1}. **${user ? user.username : 'Unknown'}** - ${top[i].nfcoins} NFC Coins`);
    }
    const viewer = await getCoinsRank(viewerId);
    if (!lines.length) lines.push('No coin data yet.');
    lines.push(`\nYour rank: **#${viewer.rank}** (${viewer.coins} NFC Coins)`);
    return new EmbedBuilder()
        .setTitle('NFC Coins Leaderboard')
        .setDescription(lines.join('\n'))
        .setColor(0xFFD700);
}

async function buildGameLeaderboardEmbed(bot, viewerId, statInput) {
    const resolved = resolveGameStat(statInput);
    if (!resolved) return null;
    const top = await getGameLeaderboard(resolved.key);
    const lines = [];
    for (let i = 0; i < top.length; i++) {
        const user = await bot.users.fetch(top[i].userId).catch(() => null);
        lines.push(`${i + 1}. **${user ? user.username : 'Unknown'}** - ${top[i].wins} wins`);
    }
    const viewer = await getGameRank(resolved.key, viewerId);
    if (!lines.length) lines.push('No wins recorded yet.');
    lines.push(`\nYour rank: **#${viewer.rank}** (${viewer.wins} wins)`);
    return new EmbedBuilder()
        .setTitle(`${resolved.label} Leaderboard`)
        .setDescription(lines.join('\n'))
        .setColor(0x3498DB);
}

module.exports = {
    GAME_CHOICES,
    resolveGameStat,
    recordGameWin,
    buildCoinsLeaderboardEmbed,
    buildGameLeaderboardEmbed,
};
