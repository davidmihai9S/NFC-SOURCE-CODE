const sqlite3 = require('sqlite3');
const { open } = require('sqlite');
const cards = require('./cards.json');

const DATABASE_PATH = './database.db';

let db;

function normalizeCardName(value) {
    return String(value || '').toLowerCase().replace(/[.\- ]/g, '');
}

async function normalizeStoredCardNames() {
    const canonicalByNormalized = new Map(cards.map(card => [normalizeCardName(card.name), card.name]));

    const inventoryRows = await db.all('SELECT userId, cardName, quantity FROM inventory');
    const mergedInventory = new Map();
    for (const row of inventoryRows) {
        const canonical = canonicalByNormalized.get(normalizeCardName(row.cardName)) || row.cardName;
        const key = `${row.userId}::${canonical}`;
        mergedInventory.set(key, (mergedInventory.get(key) || 0) + row.quantity);
    }
    await db.run('DELETE FROM inventory');
    for (const [key, quantity] of mergedInventory) {
        const [userId, cardName] = key.split('::');
        await db.run('INSERT INTO inventory (userId, cardName, quantity) VALUES (?, ?, ?)', [userId, cardName, quantity]);
    }

    const catchesRows = await db.all('SELECT rowid, cardName FROM catches');
    for (const row of catchesRows) {
        const canonical = canonicalByNormalized.get(normalizeCardName(row.cardName));
        if (canonical && canonical !== row.cardName) {
            await db.run('UPDATE catches SET cardName=? WHERE rowid=?', [canonical, row.rowid]);
        }
    }

    const tempGrantRows = await db.all('SELECT id, cardName FROM temp_card_grants');
    for (const row of tempGrantRows) {
        const canonical = canonicalByNormalized.get(normalizeCardName(row.cardName));
        if (canonical && canonical !== row.cardName) {
            await db.run('UPDATE temp_card_grants SET cardName=? WHERE id=?', [canonical, row.id]);
        }
    }

    const profileRows = await db.all('SELECT userId, favoriteCard, wishlistCard FROM profile_settings');
    for (const row of profileRows) {
        const canonical = canonicalByNormalized.get(normalizeCardName(row.favoriteCard));
        if (row.favoriteCard && canonical && canonical !== row.favoriteCard) {
            await db.run('UPDATE profile_settings SET favoriteCard=? WHERE userId=?', [canonical, row.userId]);
        }
        const wishlistCanonical = canonicalByNormalized.get(normalizeCardName(row.wishlistCard));
        if (row.wishlistCard && wishlistCanonical && wishlistCanonical !== row.wishlistCard) {
            await db.run('UPDATE profile_settings SET wishlistCard=? WHERE userId=?', [wishlistCanonical, row.userId]);
        }
    }
}

async function initDatabase() {
    db = await open({ filename: DATABASE_PATH, driver: sqlite3.Database });
    await db.exec(`
        CREATE TABLE IF NOT EXISTS inventory (userId TEXT, cardName TEXT, quantity INTEGER DEFAULT 1, PRIMARY KEY (userId, cardName));
        CREATE TABLE IF NOT EXISTS blacklist (userId TEXT PRIMARY KEY, reason TEXT);
        CREATE TABLE IF NOT EXISTS catches (userId TEXT, cardName TEXT, guildId TEXT, timestamp INTEGER);
        CREATE TABLE IF NOT EXISTS notifications (userId TEXT PRIMARY KEY, enabled INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS daily (userId TEXT PRIMARY KEY, lastDaily INTEGER, lastBonus INTEGER);
        CREATE TABLE IF NOT EXISTS authorized_users (userId TEXT PRIMARY KEY, firstSeen INTEGER);
        CREATE TABLE IF NOT EXISTS trade_requests (id TEXT PRIMARY KEY, fromId TEXT, toId TEXT, fromCard TEXT, toCard TEXT, status TEXT, createdAt INTEGER);
        CREATE TABLE IF NOT EXISTS server_config (guildId TEXT PRIMARY KEY, spawnChannelId TEXT, announcementChannelId TEXT, blacktea_hp INTEGER DEFAULT 2, blacktea_time INTEGER DEFAULT 10, greentea_pts INTEGER DEFAULT 30, tea_time INTEGER DEFAULT 10, tea_syll INTEGER DEFAULT 1400);
        CREATE TABLE IF NOT EXISTS economy (userId TEXT PRIMARY KEY, nfcoins INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS shop_items (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, description TEXT, price INTEGER, type TEXT, value TEXT);
        CREATE TABLE IF NOT EXISTS purchases (id INTEGER PRIMARY KEY AUTOINCREMENT, userId TEXT, itemId INTEGER, timestamp INTEGER);
        CREATE TABLE IF NOT EXISTS profile_settings (userId TEXT PRIMARY KEY, favoriteCard TEXT, elementalPower TEXT, wishlistCard TEXT);
        CREATE TABLE IF NOT EXISTS temp_point_grants (id INTEGER PRIMARY KEY AUTOINCREMENT, userId TEXT, amount INTEGER, expiresAt INTEGER, reverted INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS temp_card_grants (id INTEGER PRIMARY KEY AUTOINCREMENT, userId TEXT, cardName TEXT, quantity INTEGER DEFAULT 1, expiresAt INTEGER, reverted INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS streak_state (category TEXT PRIMARY KEY, userId TEXT, streak INTEGER DEFAULT 0, updatedAt INTEGER);
        CREATE TABLE IF NOT EXISTS game_stats (statKey TEXT, userId TEXT, wins INTEGER DEFAULT 0, PRIMARY KEY (statKey, userId));
        PRAGMA busy_timeout = 5000;
    `);
    const info = await db.all("PRAGMA table_info(server_config)");
    const cols = info.map(c => c.name);
    if (!cols.includes('announcementChannelId')) await db.run('ALTER TABLE server_config ADD COLUMN announcementChannelId TEXT');
    if (!cols.includes('blacktea_hp')) await db.run('ALTER TABLE server_config ADD COLUMN blacktea_hp INTEGER DEFAULT 2');
    if (!cols.includes('blacktea_time')) await db.run('ALTER TABLE server_config ADD COLUMN blacktea_time INTEGER DEFAULT 10');
    if (!cols.includes('greentea_pts')) await db.run('ALTER TABLE server_config ADD COLUMN greentea_pts INTEGER DEFAULT 30');
    if (!cols.includes('tea_time')) await db.run('ALTER TABLE server_config ADD COLUMN tea_time INTEGER DEFAULT 10');
    if (!cols.includes('tea_syll')) await db.run('ALTER TABLE server_config ADD COLUMN tea_syll INTEGER DEFAULT 1400');
    const profileInfo = await db.all("PRAGMA table_info(profile_settings)");
    const profileCols = profileInfo.map(c => c.name);
    if (!profileCols.includes('wishlistCard')) await db.run('ALTER TABLE profile_settings ADD COLUMN wishlistCard TEXT');
    await normalizeStoredCardNames();
    console.log(`[DB] Database ready and migrated: ${DATABASE_PATH}`);
    return db;
}

function getDb() { return db; }
function getDatabasePath() { return DATABASE_PATH; }

module.exports = { initDatabase, getDb, getDatabasePath };
