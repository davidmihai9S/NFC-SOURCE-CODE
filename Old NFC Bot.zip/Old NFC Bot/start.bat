@echo off
title Ninjago Bot
cd /d "%~dp0"
:loop
echo [%date% %time%] Starting bot...
node index.js
echo [%date% %time%] Bot crashed. Restarting in 3 seconds...
timeout /t 3 /nobreak
goto loop
