NFC Bot Ready

This package is set up to run on another PC with the bundled assets already included.

What to do:

1. Open `config.js`
2. Replace `PUT_YOUR_BOT_TOKEN_HERE` with your bot token
3. Run `start.bat`

Notes:

- The bot uses a local `database.db` file in this folder
- Card images are in `assets/cards`
- GIFs are in `assets/gifs`
- Set Guesser assets are in `assets/set-guesser`
- Minifigure Guesser assets are in `assets/minifigure-guesser`
- The webhook is still included, matching the current bot setup

If `start.bat` does not work, make sure Node.js is installed and available in PATH, then run:

`node index.js`
