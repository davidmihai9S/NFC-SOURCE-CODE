﻿const { EmbedBuilder } = require('discord.js');
const { addNFCoins } = require('../economy');
const { log, userField, recordWinStreak } = require('../helpers');
const { recordGameWin } = require('../stats');
const config = require('../config');

let quizData = [];
try {
    quizData = JSON.parse(require('fs').readFileSync('quizzes.json', 'utf8'));
    console.log(`[QUIZ] Loaded ${quizData.length} questions.`);
} catch(e) {
    console.error('[QUIZ] Failed to load quizzes.json - file missing or invalid JSON.');
}

class QuizGame {
    constructor(channel, hostId, total) {
        this.channel = channel;
        this.hostId = hostId;
        this.total = total;
        this.current = 0;
        this.scores = new Map();
        this.active = true;
        this.answered = new Set();
        this.timeout = null;
        this.createdAt = Date.now();
        this.roundAdvanced = false;
        this.roundResolved = false;
    }
    addPoint(userId, username) {
        const entry = this.scores.get(userId) || { userId, username, score: 0 };
        entry.score++;
        entry.username = username;
        this.scores.set(userId, entry);
    }
    getLeaderboard() {
        const arr = Array.from(this.scores.values()).sort((a, b) => b.score - a.score);
        if (arr.length === 0) return ['No points scored yet.'];
        return arr.map((d, i) => `${i + 1}. **${d.username}** - ${d.score} points`);
    }
    stop() {
        this.active = false;
        if (this.timeout) clearTimeout(this.timeout);
    }
    async finish(m) {
        const winner = Array.from(this.scores.values()).sort((a, b) => b.score - a.score)[0];
        if (winner) {
            const streak = await recordWinStreak('quiz_win', winner.userId);
            await recordGameWin('quiz', winner.userId);
            await addNFCoins(winner.userId, 500);
            await log('Quiz Won', config.LOG_COLORS.success, [
                { name: 'Winner', value: userField({ id: winner.userId, username: winner.username }) },
                { name: 'Score', value: `${winner.score}/${this.total}`, inline: true },
                { name: 'Win Streak', value: `${streak}`, inline: true },
                { name: 'Reward', value: '500 NFC Coins', inline: true },
            ]);
            await m.channel.send(`🏆 **QUIZ COMPLETE!** Winner: **${winner.username}** with **${winner.score}/${this.total}** points! +500 NFC Coins!\n\n${this.getLeaderboard().join('\n')}`);
        } else {
            await m.channel.send(`🏆 Quiz complete! No one scored.\n\n${this.getLeaderboard().join('\n')}`);
        }
        this.stop();
        require('../index').activeQuizzes.delete(m.channel.id);
    }
    async startRound(m) {
        if (!this.active) return;
        this.current++;
        if (this.current > this.total) return this.finish(m);
        const q = quizData[Math.floor(Math.random() * quizData.length)];
        this.answered.clear();
        this.roundAdvanced = false;
        this.roundResolved = false;
        const labels = ['A', 'B', 'C', 'D'];
        const timeLimit = 10;
        const optionLines = q.options.map((option, i) => `**${labels[i]}** ${option}`).join('\n');
        const embed = new EmbedBuilder()
            .setTitle(`📚 Question ${this.current}/${this.total}`)
            .setDescription(`**${q.question}**\n\n${optionLines}\n\n⏳ **${timeLimit}s** left`)
            .setColor(0x9B59B6)
            .setFooter({ text: `Season ${q.season} (${q.seasonName}) - Answer with A, B, C, D, or the exact option text` });
        const msg = await m.channel.send({ embeds: [embed] });
        let countdown = timeLimit;
        const interval = setInterval(async () => {
            countdown--;
            if (countdown >= 0 && this.active) {
                embed.setDescription(`**${q.question}**\n\n${optionLines}\n\n⏳ **${countdown}s** left`);
                await msg.edit({ embeds: [embed] }).catch(() => {});
            }
            if (countdown <= 0) clearInterval(interval);
        }, 1000);
        const collector = m.channel.createMessageCollector({
            filter: msg2 => !msg2.author.bot && !this.answered.has(msg2.author.id) && this.active,
            time: timeLimit * 1000
        });
        collector.on('collect', async msg2 => {
            if (this.roundResolved) return;
            const answer = msg2.content.trim().toLowerCase();
            const correctLetter = labels[q.correct].toLowerCase();
            const correctText = String(q.options[q.correct]).trim().toLowerCase();
            const validLetters = ['a', 'b', 'c', 'd'];
            const optionTexts = q.options.map(option => String(option).trim().toLowerCase());
            if (!validLetters.includes(answer) && !optionTexts.includes(answer)) return;
            const isCorrect = answer === correctText || answer === correctLetter;
            if (isCorrect) {
                this.roundResolved = true;
                this.roundAdvanced = true;
                this.answered.add(msg2.author.id);
                this.addPoint(msg2.author.id, msg2.author.username);
                await addNFCoins(msg2.author.id, 50);
                await msg2.react('✅').catch(() => {});
                const explanation = q.explanation ? `\n*${q.explanation}*` : '';
                await m.channel.send(`🎉 **${msg2.author.username}** answered correctly! +50 NFC Coins${explanation}`);
                clearInterval(interval);
                collector.stop();
                this.timeout = setTimeout(() => this.startRound(m), 2000);
            } else {
                this.answered.add(msg2.author.id);
                await msg2.react('?').catch(() => {});
                await msg2.reply('? Wrong answer! You cannot answer again this round.').catch(() => {});
            }
        });
        collector.on('end', async () => {
            clearInterval(interval);
            if (!this.active) return;
            if (!this.roundResolved) {
                const explanation = q.explanation ? `\n*${q.explanation}*` : '';
                await m.channel.send(`? Time's up! The correct answer was: **${q.options[q.correct]}**.${explanation}`);
            }
            if (this.roundAdvanced) return;
            if (this.current >= this.total) return this.finish(m);
            this.timeout = setTimeout(() => this.startRound(m), 2000);
        });
    }
}

module.exports = { QuizGame, quizData };
