const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, MessageFlags } = require('discord.js');

const TRUTHS = [
  "What are your top 5 favorite shows?",
  "Do you watch TannerFishies?",
  "What is your favorite food?",
  "Who is your best friend?",
  "Do you lie on my truths/dares?",
  "How many pets do you have?",
  "Kailor or Pixane?",
  "Do you ship Jaya?",
  "Are you a lava shipper?",
  "Did you fart today?",
  "What was the last thing you ate?",
  "What was the year when you started watching Ninjago?",
  "If you could erase one character from the show, who would it be?",
  "Who are the top 3 favorite people of this server?",
  "Have you ever pretended to be older than you are on Discord?",
  "What is the most useless thing you've ever spent money on?",
  "If you had to switch lives with a Ninjago villain for a day, who would it be?",
  "Have you ever lied to someone saying they are your best friend just to not make them upset?",
  "What's the longest you've gone without showering?",
  "OG or Dragons Rising?",
  "Have you ever sent a risky DM and then immediately regretted it?",
  "Do you talk to AI?",
  "If you could bring back one dead character, who would it be?",
  "What's the most embarrassing song in your playlist?",
  "Have you ever lied about your location to someone online?",
  "IRL friends or Discord friends?",
  "Who is your favorite member of the 'Council of the Crystal King'?",
  "Have you ever been caught talking to yourself in a Discord channel?",
  "What is the most trouble you've ever been in at school/work?",
  "If you were a ghost, which Ninja would you possess?",
  "Have you ever used a voice changer to prank someone?",
  "What's the most money you've ever spent on a single Lego set?",
  "Which Ninjago realm would you absolutely HATE to live in?",
  "Have you ever blocked a friend without telling them why?",
  "What is your honest opinion on the Ninjago Movie?",
  "Who is the most famous person you've ever talked to online?",
  "Have you ever pretended to be your opposite gender online just to see what happens?",
  "What is the weirdest thing you've ever done on Discord?",
  "If you could have one elemental power in real life, but only for 10 minutes a day, what would it be?",
  "Have you ever stolen something from a friend or sibling?",
  "Are you in the biggest Ninjago server? If yes, do you like it?",
  "What is the last thing you searched for on Google? (Be honest!)",
  "Have you ever been kicked/banned from a server for a stupid reason?",
  "Which character's redesign in Season 8 did you hate the most?",
  "Do you think the show should have ended after Season 15?",
  "Do you have a crush on someone?",
  "Have you ever stayed up until 4 AM just to chat on Discord?",
  "Who do you think is the 'weakest' Ninja?",
  "What is the most annoying thing your best friend does?",
  "Have you ever had a crush on someone of your gender?",
  "If you were a Serpentine, which tribe would you belong to?",
  "What is your favorite Ninjago server?",
  "Have you ever accidentally sent a screenshot of a person to THAT same person?",
  "Who is the most creative person on this server?",
  "What is the most 'toxic' trait you have?",
  "Do you think Ninjago is better than LEGO Monkie Kid?",
  "Have you ever ghosted someone because you didn't know how to reply?",
  "Which Ninjago season has the best soundtrack?",
  "What is the scariest thing that has ever happened to you?",
  "Have you lied to Discord about your age?",
  "Who do you think is the most underrated villain?",
  "What is the most 'cringe' phase you've ever had?",
  "If you could have any vehicle from the show, which one would it be?",
  "Have you ever been jealous of someone's Discord Nitro?",
  "What is the most common lie you tell your parents?",
  "Which Ninja would you trust to drive you home?",
  "Have you ever deleted a message because no one reacted to it?",
  "Who is your favorite new ninja?",
  "Is Riyu cute?",
  "If you could be any animal, what would you be?",
  "Have you ever lied about your age to get into an 18+ server?",
  "Who is the best 'mentor' character besides Sensei Wu?",
  "What's the most childish thing you still own?",
  "Have you ever 'simped' for a fictional character? If yes, who?",
  "What is the worst thing you've ever done to a sibling?",
  "If you were trapped in a video game, which one would it be?",
  "Have you ever called someone a bad word on Discord and regretted it?",
  "What is the best thing that happened to you this week?",
  "Have you ever made someone cry?",
  "Are you home right now?",
  "Do you think the Overlord will ever truly be gone?",
  "What is the most annoying emoji people use?",
  "Which Ninjago character would you want to have as your parent?",
  "Have you ever lied about being busy just to play games?",
  "What's the most expensive thing you've ever won in a giveaway?",
  "Who is your favorite voice actor from the show?",
  "Have you ever been 'warned' by a bot on this server?",
  "What is the most 'uncool' thing about you?",
  "Do you like yourself from 1-2 years ago?",
  "Have you ever faked a laugh at a joke that wasn't funny?",
  "Who do you think is the 'smartest' Ninja?",
  "Which Ninjago character's powers would be the most dangerous in your hands?",
  "What is the longest you've ever gone without talking to your online friends?",
  "If you could delete one channel from this server, which one would it be?",
  "Who on this server do you think is the most likely to become a villain?",
  "What's a secret you've never told anyone on this server?",
  "Have you ever been caught looking at Ninjago memes during class?",
  "If you could meet Master Wu, what is the first question you would ask?",
  "Do you prefer the Ninja in their gi or in casual clothes?",
  "If the world was ending tomorrow, what would be your last Discord message?"
];

const DARES = [
"Send the 🖕 emoji to the last person you DMed (Group chats/bots dont count). (Send screenshot)",
"Tell your best friend you have a crush on them. (Send screenshot)",
"Set your profile status to what other players decide for 1 day. (Send screenshot)",
"DM your best friend saying ”I hate you”. (Send screenshot)",
"Send the 🥺 pleading emojis 5 times to the 5th person you DMed/DMed you (Group chats/bots dont count). (Send screenshot)",
"Spam the DMs of the 10th person you DMed/DMed you with random emojis (Group chats/bots dont count). (Send screenshot)",
"Prank call McDonalds, record the call and send it here.",
"Join VC and scream for 5 seconds.",
"Ping someone random and compliment them.",
"Change your bio to whatever other players decide for the next hour. (Send screenshot)",
"Break any 1 rule of the server (nothing that gets you banned!).",
"Post the last image from your phone gallery/PC.",
"Send your google search history from the last 24 hours.",
"Send your YouTube watch history.",
"Send screenshot of the chat with the last person you DMed.",
"Send screenshot of the chat with the 5th person you DMed.",
"Send screenshot of the chat with the 10th person you DMed.",
"Send screenshot of the chat with the 7th person you DMed.",
"Send screenshot of the chat with the 3rd person you DMed.",
"Send screenshot of the chat with the 2nd person you DMed.",
"Send screenshot of the chat with the 4th person you DMed.",
"DM a random friend to join this server (send screenshot).",
"Ping the person you hate most in this server.",
"Ping the owner 10 times in a row.",
"Change your profile picture to Dareth for 24 hours.",
"DM a moderator and ask them 'Are you a Serpentine spy?'. (Send screenshot)",
"Post a voice message in general chat saying 'Ninja-GO!' as loud as you can.",
"Change your server nickname to 'Dareth's #1 Fan' for 12 hours. (Send screenshot)",
"Send a screenshot of your Discord 'Blocked Users' list.",
"DM a random person on the server and send them a picture of a potato. (Send screenshot)",
"Leave a server you actually like and show proof.",
"Send a voice message screaming ”YOOOOOOO” as loud you can",
"Change your Discord theme to Light Mode and keep it for 1 hour. (Send screenshot)",
"Go to a random voice channel and play the Weekend Whip at full volume.",
"DM the 1st person on the member list and say 'Master Wu is disappointed in you'. (Send screenshot)",
"Post a screenshot of your most used emojis.",
"Change your bio to 'I ship Kai and Skylor forever' for the next hour.",
"Ping a random person and ask them for a date. (Send screenshot)",
"Send the ”E” letter in general chat every 10 seconds for the next 5 minutes.",
"Screenshot your last 3 DMs (just the list of names).",
"Change your pfp to the most embarrassing Ninjago frame you can find.",
"DM the last person you talked to and tell them you're leaving Discord forever, then wait 2 minutes to say 'JK'. (Send screenshot)",
"React with 🤡 to every message the owner sends for the next 30 minutes.",
"Find a cringy old post of yours on this server and quote-reply to it with 'What was I thinking?'.",
"Ask the chat to give you a 'punishment' nickname and keep it for 2 hours.",
"Ping a moderator and ask them to kick you (don't worry, they won't... hopefully).",
"Post a picture of your actual room right now.",
"Voice record yourself doing your best Lord Ras roaring.",
"Change your status to 'Simping for [Random Character]' for 5 hours.",
"DM a random person 'I stole your Golden Weapon' and block them for 1 minute. (Send screenshot)",
"Send the last 5 GIFs in your 'Favorites' list here.",
"Change your language settings to something you don't understand and send a screenshot.",
"Draw a ninja on your hand with a pen and post the photo.",
"Ask the person you like least on the server to be your 'Sensei' for the day. (Send screenshot)",
"Post a screenshot of your Spotify/Music 'Recently Played'.",
"DM a friend 'I'm a ghost, boo!' and don't reply for 10 minutes. (Send screenshot)",
"Change your pfp to a picture of a snake for 12 hours.",
"Beg the owner to promote you/demote you.",
"Send a screenshot of your phone's battery percentage and storage space.",
"Ping a random person and tell them 'You are the Green Ninja'. (Send screenshot)",
"Send a message in general chat using only your chin to type.",
"Delete your last 10 messages on the server, no matter what they were.",
"DM the 8th person on your DM list and ask 'Do you believe in the Overlord?'. (Send screenshot)",
"Change your bio to 'I am a loyal servant of the Crystal King'. (Send screenshot)",
"Post a screenshot of your YouTube 'Search History'.",
"Ping 3 people and don't say anything when they reply.",
"Change your nickname to 'Pink Zane' and keep it for 24 hours. (Send screenshot)",
"Post a screenshot of your Discord 'Subscriptions' to show if you have Nitro or not. (Blur the email adress!)",
"!kiss the owner.",
"Send a screenshot of your phone's home screen.",
"Type 'I'm a little teapot' in the next 3 servers you talk in. (Send screenshot proof)",
"DM a friend and tell them you've joined a cult that worships snakes. (Send screenshot)",
"Change your pfp to Kai eating banana for 1 hour.",
"Post a screenshot of your last Amazon/Online shopping cart.",
"Tell the chat your most 'unpopular' Ninjago opinion and fight everyone who disagrees for 10 mins.",
"Change your status to 'Crying over Zane's death again' for 1 hour",
"Ping the owner and tell them 'NFC Bot is better than you'. (Send screenshot)",
"Send a screenshot of your 'Screen Time' from your phone settings.",
"DM the 2nd person you DMed and ask them 'Why are you like this?'. (Send screenshot)",
"Set your profile theme to the ugliest color combination possible for 1 hour. (Send screenshot)",
"Post a voice message of you trying to do a Spinjitzu sound effect.",
"DM a random person and ask for their credit card numbers (Add 'JK' immediately!). (Send screenshot)",
"Screenshot your last conversation with your mom/dad (if safe!).",
"Change your pfp to a 'Noob' character for 2 days. (Send screenshot)",
"Ping a random person and tell them they are your new best friend.",
"Post a screenshot of your most played game on Steam/Console.",
"Send 'I love you' to an AI bot and screenshot the reply.",
"Change your nickname to 'The Ultimate Spinjitzu Master' for 1 hour. (Send screenshot)",
"DM a moderator another Discord server invite link",
"!kill the owner",
"!kiss a moderator",
"Change your status to 'Offline' and stay that way for the next 5 hours.",
"Post a screenshot of your last 5 images from you phone/PC gallery.",
"DM a friend 'I'm in your walls' and send a picture of a wall. (Send screenshot)",
"Change your pfp to bald nya from season 7 for 30 minutes.",
"Try pinging everyone (Don't if you are a moderator!)",
"Write 'BIGGEST NINJAGO SERVER SUCKS' in 5 different channels. (Send screenshot)",
"Change your bio to 'Dating [Random Person on server]' for 30 minutes. (Send screenshot)",
"Post a screenshot of your Discord 'Notifications'.",
"Leave the server for 5 minutes."
];

function pickRandom(items) {
    return items[Math.floor(Math.random() * items.length)];
}

function promptId() {
    return Math.random().toString(36).slice(2, 12);
}

function buildTruthDareButtons() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('todpick_truth').setLabel('Truth').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('todpick_dare').setLabel('Dare').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('todpick_random').setLabel('Random').setStyle(ButtonStyle.Primary),
    );
}

function buildTruthDarePromptPayload(type, requester) {
    const resolvedType = type === 'random' ? (Math.random() < 0.5 ? 'truth' : 'dare') : type;
    const prompt = resolvedType === 'truth' ? pickRandom(TRUTHS) : pickRandom(DARES);
    const bananaReference = prompt.toLowerCase().includes('kai eating banana') ? '\n\nReference: https://imgur.com/a/7B1w1TV' : '';
    const embed = new EmbedBuilder()
        .setAuthor({ name: `Requested by ${requester.username}`, iconURL: requester.displayAvatarURL?.() || undefined })
        .setDescription(`**${prompt}**${bananaReference}\n\nType: **${resolvedType.toUpperCase()}** | Rating: **PG** | ID: \`${promptId()}\``)
        .setColor(resolvedType === 'truth' ? 0x3498DB : 0xE74C3C);
    return { embeds: [embed], components: [buildTruthDareButtons()] };
}

class TruthDareGame {
    constructor(channel, hostId, rounds = 10) {
        this.channel = channel;
        this.hostId = hostId;
        this.rounds = rounds;
        this.currentRound = 0;
        this.players = new Map();
        this.playerOrder = [];
        this.active = false;
        this.createdAt = Date.now();
        this.currentPlayerId = null;
        this.lastType = null;
        this.lastPrompt = null;
        this.lastRequester = null;
    }

    addPlayer(user) {
        if (!this.players.has(user.id)) {
            this.players.set(user.id, user.username);
        }
    }

    stop() {
        this.active = false;
    }

    buildLobbyPayload() {
        const joined = this.players.size
            ? Array.from(this.players.entries()).map(([id, name]) => `<@${id}> (${name})`).join('\n')
            : 'No players yet.';
        const embed = new EmbedBuilder()
            .setTitle('Truth or Dare')
            .setDescription('Click **Join** to play. The host starts when everyone is ready.')
            .addFields(
                { name: 'Rounds', value: `${this.rounds}`, inline: true },
                { name: 'Players', value: joined.slice(0, 1000), inline: false },
            )
            .setColor(0xFF8C00);
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`tod_join_${this.channel.id}`).setLabel('Join').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`tod_start_${this.channel.id}`).setLabel('Start').setStyle(ButtonStyle.Primary),
            new ButtonBuilder().setCustomId(`tod_cancel_${this.channel.id}`).setLabel('Cancel').setStyle(ButtonStyle.Danger),
        );
        return { embeds: [embed], components: [row] };
    }

    buildTurnPayload() {
        const embed = new EmbedBuilder()
            .setTitle(`Truth or Dare - Round ${this.currentRound}/${this.rounds}`)
            .setDescription(`<@${this.currentPlayerId}>, choose **Truth**, **Dare**, or **Random**.`)
            .setColor(0xFF8C00);
        return { embeds: [embed], components: [this.buildChoiceRow()] };
    }

    buildChoiceRow() {
        return new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId(`tod_truth_${this.channel.id}`).setLabel('Truth').setStyle(ButtonStyle.Success),
            new ButtonBuilder().setCustomId(`tod_dare_${this.channel.id}`).setLabel('Dare').setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId(`tod_random_${this.channel.id}`).setLabel('Random').setStyle(ButtonStyle.Primary),
        );
    }

    start() {
        this.active = true;
        this.playerOrder = Array.from(this.players.keys());
        this.currentRound = 0;
        return this.nextRound();
    }

    nextRound() {
        if (!this.active || this.currentRound >= this.rounds) {
            this.stop();
            return null;
        }
        this.currentRound++;
        this.currentPlayerId = this.playerOrder[(this.currentRound - 1) % this.playerOrder.length];
        this.lastType = null;
        this.lastPrompt = null;
        this.lastRequester = null;
        return this.buildTurnPayload();
    }

    answer(type) {
        const prompt = type === 'truth' ? pickRandom(TRUTHS) : pickRandom(DARES);
        const bananaReference = prompt.toLowerCase().includes('kai eating banana') ? '\n\nReference: https://imgur.com/a/7B1w1TV' : '';
        return new EmbedBuilder()
            .setTitle(type === 'truth' ? 'Truth' : 'Dare')
            .setDescription(`<@${this.currentPlayerId}>\n\n${prompt}${bananaReference}`)
            .setFooter({ text: `Round ${this.currentRound}/${this.rounds}` })
            .setColor(type === 'truth' ? 0x3498DB : 0xE74C3C);
    }

    buildPromptPayload(type, requester) {
        const prompt = type === 'truth' ? pickRandom(TRUTHS) : pickRandom(DARES);
        const bananaReference = prompt.toLowerCase().includes('kai eating banana') ? '\n\nReference: https://imgur.com/a/7B1w1TV' : '';
        const id = promptId();
        this.currentPlayerId = requester.id;
        this.lastType = type;
        this.lastPrompt = prompt;
        this.lastRequester = requester.id;
        const embed = new EmbedBuilder()
            .setAuthor({ name: `Requested by ${requester.username}`, iconURL: requester.displayAvatarURL?.() || undefined })
            .setDescription(`**${prompt}**${bananaReference}\n\nType: **${type.toUpperCase()}** | Rating: **PG** | ID: \`${id}\`\nRound **${this.currentRound}/${this.rounds}**`)
            .setColor(type === 'truth' ? 0x3498DB : 0xE74C3C);
        return { embeds: [embed], components: [this.buildChoiceRow()] };
    }

    buildEndPayload() {
        return {
            embeds: [
                new EmbedBuilder()
                    .setTitle('🏁 Truth or Dare Finished')
                    .setDescription('That was 10 rounds. Good chaos, everyone.')
                    .setColor(0x2ECC71),
            ],
            components: [],
        };
    }
}

module.exports = { TruthDareGame, buildTruthDarePromptPayload };
