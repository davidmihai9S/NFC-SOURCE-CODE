const fs = require('fs');
const path = require('path');
const { AttachmentBuilder, EmbedBuilder } = require('discord.js');
const stringSimilarity = require('string-similarity');
const { addNFCoins } = require('../economy');
const { recordGameWin } = require('../stats');
const { buildResultsEmbed } = require('./QuoteGuesser');
const { guesserBlockFilter, recordGuesserWin } = require('./GuesserCooldown');
const config = require('../config');

const IMAGE_EXTENSIONS = new Set(['.png', '.jpg', '.jpeg', '.webp']);
const LOCATION_CACHE_PATH = path.join(__dirname, '..', 'location_guesser_cache.json');
const LOCATION_CATEGORY_URL = 'https://ninjago.fandom.com/api.php?action=query&list=categorymembers&cmtitle=Category:Locations&cmnamespace=0&cmlimit=max&format=json&origin=*';
const LOCATION_PAGE_URL = 'https://ninjago.fandom.com/api.php?action=query&prop=pageimages|info&piprop=original&inprop=url&format=json&origin=*';

function normalizeText(value) {
    return String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/&/g, ' and ')
        .replace(/[^a-z0-9 ]+/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function splitChunks(items, size) {
    const chunks = [];
    for (let i = 0; i < items.length; i += size) chunks.push(items.slice(i, i + size));
    return chunks;
}

function imagePayload(embed, imagePathOrUrl) {
    if (!imagePathOrUrl) return { embeds: [embed] };
    if (/^https?:\/\//i.test(imagePathOrUrl)) {
        embed.setImage(imagePathOrUrl);
        return { embeds: [embed] };
    }
    if (fs.existsSync(imagePathOrUrl)) {
        const name = path.basename(imagePathOrUrl).replace(/[^a-z0-9_.-]/gi, '_');
        embed.setImage(`attachment://${name}`);
        return { embeds: [embed], files: [new AttachmentBuilder(imagePathOrUrl, { name })] };
    }
    return { embeds: [embed] };
}

function simplifySetName(rawName) {
    return String(rawName || '')
        .replace(/^\d+(?:-\d+)?\s*-\s*/i, '')
        .replace(/_/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
}

function collapseDottedAcronyms(value) {
    return String(value || '').replace(/\b(?:[A-Za-z]\.){2,}[A-Za-z]?\.?/g, match => match.replace(/\./g, ''));
}

function dedupeRepeatedWords(value) {
    const words = String(value || '').split(/\s+/).filter(Boolean);
    const output = [];
    for (const word of words) {
        const normalized = normalizeText(collapseDottedAcronyms(word));
        if (!output.length || normalizeText(collapseDottedAcronyms(output[output.length - 1])) !== normalized) output.push(word);
    }
    return output.join(' ');
}

function simplifyMinifigureName(rawName) {
    let name = String(rawName || '');
    name = name.replace(/^fig-\d+\s*-\s*/i, '').trim();
    name = name.split(/\s+\bwith\b\s+|\s+\bin\b\s+|,\s*|\s+\-\s+|\s*\(/i)[0].trim();
    name = collapseDottedAcronyms(name);
    name = name.replace(/\bZX\b|\bDX\b|\bNRG\b/gi, '').trim();
    name = name.replace(/\bAvatar\b|\bDigi Lloyd\b/gi, '').trim();
    name = name.replace(/\s+/g, ' ').trim().replace(/^[- ]+|[- ]+$/g, '');
    const lowered = name.toLowerCase();
    if (lowered.startsWith('samurai x ')) return dedupeRepeatedWords(name.split(/\s+/).slice(-1)[0]);
    for (const prefix of ['lord ', 'master ', 'sensei ', 'general ', 'captain ', 'commander ', 'ghost ']) {
        if (lowered.startsWith(prefix)) return dedupeRepeatedWords(name.slice(prefix.length).trim());
    }
    return dedupeRepeatedWords(name);
}

function buildMinifigureVariants(answerName) {
    const variants = new Set();
    const candidates = [
        answerName,
        simplifyMinifigureName(answerName),
        collapseDottedAcronyms(answerName),
        collapseDottedAcronyms(simplifyMinifigureName(answerName)),
    ];
    for (const candidate of candidates) {
        const cleaned = dedupeRepeatedWords(candidate).trim();
        if (cleaned) variants.add(cleaned);
        variants.add(cleaned.replace(/\bmr\b/gi, 'mister').trim());
        variants.add(cleaned.replace(/\bmister\b/gi, 'mr').trim());
        variants.add(cleaned.replace(/\bdr\b/gi, 'doctor').trim());
        variants.add(cleaned.replace(/\bdoctor\b/gi, 'dr').trim());
    }
    return [...variants].filter(Boolean);
}

function isValidImageFile(filePath) {
    return fs.existsSync(filePath) && IMAGE_EXTENSIONS.has(path.extname(filePath).toLowerCase());
}

function discoverLocalImages(rootPath, simplifyName, variantBuilder = null) {
    if (!rootPath || !fs.existsSync(rootPath)) {
        throw new Error(`Image folder not found: ${rootPath}`);
    }

    const entries = [];
    const stack = [rootPath];
    while (stack.length) {
        const current = stack.pop();
        for (const entry of fs.readdirSync(current, { withFileTypes: true })) {
            const fullPath = path.join(current, entry.name);
            if (entry.isDirectory()) {
                stack.push(fullPath);
                continue;
            }
            if (!isValidImageFile(fullPath)) continue;
            const rawName = entry.name.replace(path.extname(entry.name), '').replace(/_/g, ' ').replace(/\s+/g, ' ').trim();
            const answerName = simplifyName(rawName);
            const variants = variantBuilder ? variantBuilder(answerName) : [answerName];
            const normalizedVariants = [...new Set(variants.map(normalizeText).filter(Boolean))];
            if (!normalizedVariants.length) continue;
            entries.push({
                displayName: rawName,
                answerName,
                normalizedAnswer: normalizeText(answerName),
                normalizedVariants,
                image: fullPath,
            });
        }
    }

    if (!entries.length) throw new Error(`No image files found under ${rootPath}`);
    return entries.sort((a, b) => a.answerName.localeCompare(b.answerName));
}

async function fetchJson(url) {
    const response = await fetch(url, { headers: { 'User-Agent': 'NFC-Bot/2.2.0' } });
    if (!response.ok) throw new Error(`Request failed: ${response.status}`);
    return response.json();
}

async function loadLocationEntries() {
    try {
        if (fs.existsSync(LOCATION_CACHE_PATH)) {
            const cached = JSON.parse(fs.readFileSync(LOCATION_CACHE_PATH, 'utf8'));
            if (Array.isArray(cached) && cached.length) return cached;
        }
    } catch (error) {
        console.error('[LOCATION GUESSER] Failed reading cache:', error.message);
    }

    const pages = [];
    let continueToken = null;
    do {
        const url = continueToken ? `${LOCATION_CATEGORY_URL}&cmcontinue=${encodeURIComponent(continueToken)}` : LOCATION_CATEGORY_URL;
        const data = await fetchJson(url);
        const members = data?.query?.categorymembers || [];
        for (const member of members) {
            if (member?.title) pages.push({ title: member.title, pageid: member.pageid });
        }
        continueToken = data?.continue?.cmcontinue || null;
    } while (continueToken);

    const enriched = [];
    for (const chunk of splitChunks(pages, 25)) {
        const titles = chunk.map(item => item.title).join('|');
        const data = await fetchJson(`${LOCATION_PAGE_URL}&titles=${encodeURIComponent(titles)}`);
        const resultPages = Object.values(data?.query?.pages || {});
        for (const page of resultPages) {
            const image = page?.original?.source;
            if (!image || !page?.title) continue;
            enriched.push({
                displayName: page.title,
                answerName: page.title,
                normalizedAnswer: normalizeText(page.title),
                normalizedVariants: [normalizeText(page.title)],
                image,
                pageUrl: page.fullurl || null,
            });
        }
    }

    if (!enriched.length) throw new Error('No location images found from the Ninjago wiki.');

    fs.writeFileSync(LOCATION_CACHE_PATH, JSON.stringify(enriched, null, 2));
    return enriched;
}

class ImageGuesserGame {
    constructor(channel, hostId, options) {
        this.channel = channel;
        this.hostId = hostId;
        this.mode = options.mode;
        this.title = options.title;
        this.entries = options.entries;
        this.rewardPerCorrect = options.rewardPerCorrect ?? 50;
        this.finalReward = options.finalReward ?? 500;
        this.totalRounds = Math.min(options.rounds || 10, this.entries.length);
        this.currentRound = 0;
        this.scores = new Map();
        this.active = true;
        this.createdAt = Date.now();
        this.usedIndexes = new Set();
        this.currentTimeout = null;
        this.currentEntry = null;
        this.roundStartedAt = null;
    }

    addPoint(userId, username) {
        const player = this.scores.get(userId) || { userId, username, score: 0 };
        player.score++;
        player.username = username;
        this.scores.set(userId, player);
    }

    getWinner() {
        return [...this.scores.values()].sort((a, b) => b.score - a.score)[0] || null;
    }

    pickEntry() {
        let available = this.entries.map((entry, index) => ({ entry, index })).filter(item => !this.usedIndexes.has(item.index));
        if (!available.length) {
            this.usedIndexes.clear();
            available = this.entries.map((entry, index) => ({ entry, index }));
        }
        const picked = available[Math.floor(Math.random() * available.length)];
        this.usedIndexes.add(picked.index);
        return picked.entry;
    }

    async sendRoundMessage() {
        const embed = new EmbedBuilder()
            .setTitle(`${this.title} - Round ${this.currentRound}/${this.totalRounds}`)
            .setDescription('Guess the answer from the image below.\nYou have **30 seconds**.')
            .setColor(0x3498DB);
        return this.channel.send(imagePayload(embed, this.currentEntry.image));
    }

    matchesGuess(input) {
        const normalizedGuess = normalizeText(input);
        if (!normalizedGuess) return false;
        if (this.currentEntry.normalizedVariants.includes(normalizedGuess)) return true;
        return this.currentEntry.normalizedVariants.some(variant => stringSimilarity.compareTwoStrings(normalizedGuess, variant) >= 0.82);
    }

    async finish(client) {
        if (!this.active) return;
        this.active = false;
        if (this.currentTimeout) clearTimeout(this.currentTimeout);
        const winner = this.getWinner();
        if (winner) {
            await addNFCoins(winner.userId, this.finalReward);
            await recordGameWin(this.mode, winner.userId);
            await recordGuesserWin({
                id: winner.userId,
                username: winner.username,
                send: (content) => client.users.fetch(winner.userId).then(user => user.send(content)),
            }, this.title, this.channel).catch(() => {});
        }
        await this.channel.send({ embeds: [buildResultsEmbed(`🏆 ${this.title} Results`, this.scores, this.totalRounds, winner ? `+${this.finalReward} NFC Coins` : 'No reward', 0x3498DB)] });
        require('../index').activeGames.delete(this.channel.id);
    }

    async startRound(client) {
        if (!this.active) return;
        this.currentRound++;
        if (this.currentRound > this.totalRounds) return this.finish(client);

        this.currentEntry = this.pickEntry();
        this.roundStartedAt = Date.now();
        await this.sendRoundMessage();

        let answered = false;
        const collector = this.channel.createMessageCollector({
            filter: msg => !msg.author.bot && this.active && msg.channel.id === this.channel.id && guesserBlockFilter(msg),
            time: 30000,
        });

        collector.on('collect', async msg => {
            if (answered) return;
            if (msg.content.toLowerCase() === '!exitgame') {
                answered = true;
                collector.stop();
                this.active = false;
                require('../index').activeGames.delete(this.channel.id);
                await this.channel.send(`Game stopped by ${msg.author.username}.`);
                return;
            }
            if (!this.matchesGuess(msg.content)) return;

            answered = true;
            collector.stop();
            this.addPoint(msg.author.id, msg.author.username);
            await addNFCoins(msg.author.id, this.rewardPerCorrect);
            const responseTime = ((Date.now() - this.roundStartedAt) / 1000).toFixed(1);
            await this.channel.send(`✅ **${msg.author.username}** guessed correctly! It was **${this.currentEntry.answerName}**. (${responseTime}s)\n+${this.rewardPerCorrect} NFC Coins!`);
            if (this.currentRound >= this.totalRounds) {
                await this.finish(client);
            } else {
                this.currentTimeout = setTimeout(() => this.startRound(client), 3000);
            }
        });

        collector.on('end', async () => {
            if (!this.active || answered) return;
            await this.channel.send(`⏰ Time's up! The answer was **${this.currentEntry.answerName}**.`);
            if (this.currentRound >= this.totalRounds) {
                await this.finish(client);
            } else {
                this.currentTimeout = setTimeout(() => this.startRound(client), 3000);
            }
        });
    }

    stop() {
        this.active = false;
        if (this.currentTimeout) clearTimeout(this.currentTimeout);
    }
}

async function createLocationGuesserGame(channel, hostId) {
    const entries = await loadLocationEntries();
    return new ImageGuesserGame(channel, hostId, {
        mode: 'location',
        title: 'Location Guesser',
        entries,
        rounds: 10,
        rewardPerCorrect: 50,
        finalReward: 500,
    });
}

async function createSetGuesserGame(channel, hostId) {
    const entries = discoverLocalImages(config.SET_GUESSER_DIR, simplifySetName);
    return new ImageGuesserGame(channel, hostId, {
        mode: 'set',
        title: 'Set Guesser',
        entries,
        rounds: 10,
        rewardPerCorrect: 50,
        finalReward: 500,
    });
}

async function createMinifigureGuesserGame(channel, hostId) {
    const entries = discoverLocalImages(config.MINIFIGURE_GUESSER_DIR, simplifyMinifigureName, buildMinifigureVariants);
    return new ImageGuesserGame(channel, hostId, {
        mode: 'minifigure',
        title: 'Minifigure Guesser',
        entries,
        rounds: 10,
        rewardPerCorrect: 50,
        finalReward: 500,
    });
}

module.exports = {
    ImageGuesserGame,
    createLocationGuesserGame,
    createSetGuesserGame,
    createMinifigureGuesserGame,
};
