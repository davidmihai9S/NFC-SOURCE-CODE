const { EmbedBuilder } = require('discord.js');
const stringSimilarity = require('string-similarity');
const { addNFCoins } = require('../economy');
const { buildResultsEmbed } = require('./QuoteGuesser');
const { guesserBlockFilter, recordGuesserWin } = require('./GuesserCooldown');
const { recordGameWin } = require('../stats');

let episodesData = [];
try {
    episodesData = JSON.parse(require('fs').readFileSync('episodes.json', 'utf8'));
} catch (e) {
    console.error('[EPISODES] Failed to load episodes.json');
}

class EpisodeGuesserGame {
    constructor(channel, authorId, rounds) {
        this.channel = channel;
        this.authorId = authorId;
        this.totalRounds = Math.min(rounds, episodesData.length);
        this.currentRound = 0;
        this.scores = new Map();
        this.active = true;
        this.currentEpisode = null;
        this.roundStartedAt = null;
        this.usedEpisodes = new Set();
        this.currentTimeout = null;
        this.createdAt = Date.now();
    }

    addPoint(userId, username) {
        const player = this.scores.get(userId) || { username, score: 0 };
        player.score += 1000;
        this.scores.set(userId, player);
    }

    getWinner() {
        let best = null;
        for (const [id, data] of this.scores) {
            if (!best || data.score > best.score) best = { userId: id, username: data.username, score: data.score };
        }
        return best;
    }

    getLeaderboard() {
        const scores = Array.from(this.scores.entries()).sort((a, b) => b[1].score - a[1].score);
        return scores.length ? scores.map(([_, data], index) => `${index + 1}. **${data.username}** - ${data.score} points`) : ['No points scored yet.'];
    }

    stop() {
        this.active = false;
        if (this.currentTimeout) clearTimeout(this.currentTimeout);
    }

    async sendEpisodeEmbed(channel, episode, round, totalRounds) {
        return channel.send({
            embeds: [
                new EmbedBuilder()
                    .setTitle(`🎬 Ninjago Episode Guesser - Round ${round}/${totalRounds}`)
                    .setDescription('**Guess the Episode Title!**\nType your answer below.\nYou have **30 seconds**!\nSmall typos are okay (80% accuracy required).')
                    .setImage(episode.image)
                    .setColor(0xFFD700),
            ],
        });
    }

    async startRound(m) {
        if (!this.active) return;
        this.currentRound++;

        let available = episodesData.filter(ep => !this.usedEpisodes.has(ep.id || ep.name));
        if (!available.length) {
            this.usedEpisodes.clear();
            available = episodesData;
        }

        const ep = available[Math.floor(Math.random() * available.length)];
        this.usedEpisodes.add(ep.id || ep.name);
        this.currentEpisode = ep;
        this.roundStartedAt = Date.now();
        await this.sendEpisodeEmbed(m.channel, ep, this.currentRound, this.totalRounds);

        const collector = m.channel.createMessageCollector({
            filter: msg => !msg.author.bot && this.active && msg.channel.id === m.channel.id && guesserBlockFilter(msg),
            time: 30000,
        });
        let answered = false;

        collector.on('collect', async msg => {
            if (answered) return;
            if (msg.content.toLowerCase() === '!exitgame') {
                answered = true;
                collector.stop();
                this.stop();
                require('../index').activeGames.delete(m.channel.id);
                await m.channel.send(`🛑 Game stopped by ${msg.author.username}.\n\n**Final Scores:**\n${this.getLeaderboard().join('\n')}`);
                return;
            }

            const guess = msg.content.toLowerCase().replace(/[^\w\s]/g, '').trim();
            const answer = ep.name.toLowerCase().replace(/[^\w\s]/g, '').trim();
            const similarity = stringSimilarity.compareTwoStrings(guess, answer);
            if (similarity >= 0.8) {
                answered = true;
                collector.stop();
                this.addPoint(msg.author.id, msg.author.username);
                const responseTime = ((Date.now() - this.roundStartedAt) / 1000).toFixed(1);
                await m.channel.send(`✅ **${msg.author.username}** guessed correctly! It was Season **${ep.season || '?'}**, Episode **${ep.episode || '?'}**, **${ep.name}**! (${responseTime}s)\n+100 NFC Coins!`);
                await addNFCoins(msg.author.id, 100);
                if (this.currentRound >= this.totalRounds) {
                    this.stop();
                    require('../index').activeGames.delete(m.channel.id);
                    const winner = this.getWinner();
                    if (winner) {
                        await recordGameWin('episode', winner.userId);
                        await recordGuesserWin({ id: winner.userId, username: winner.username, send: (content) => m.client.users.fetch(winner.userId).then(user => user.send(content)) }, 'Episode Guesser', m.channel);
                    }
                    await m.channel.send({ embeds: [buildResultsEmbed('🏆 Episode Guesser Results', this.scores, this.totalRounds, 'Glory and bragging rights', 0xFFD700)] });
                } else {
                    this.currentTimeout = setTimeout(() => this.startRound(m), 3000);
                }
            }
        });

        collector.on('end', () => {
            if (this.active && !answered) {
                m.channel.send(`⏰ Time's up! Episode was Season **${ep.season || '?'}**, Episode **${ep.episode || '?'}**, **${ep.name}**.`);
                if (this.currentRound >= this.totalRounds) {
                    this.stop();
                    require('../index').activeGames.delete(m.channel.id);
                    const winner = this.getWinner();
                    if (winner) {
                        recordGameWin('episode', winner.userId).catch(() => {});
                        recordGuesserWin({ id: winner.userId, username: winner.username, send: (content) => m.client.users.fetch(winner.userId).then(user => user.send(content)) }, 'Episode Guesser', m.channel).catch(() => {});
                    }
                    m.channel.send({ embeds: [buildResultsEmbed('🏆 Episode Guesser Results', this.scores, this.totalRounds, 'Glory and bragging rights', 0xFFD700)] });
                } else {
                    this.currentTimeout = setTimeout(() => this.startRound(m), 3000);
                }
            }
        });
    }
}

module.exports = { EpisodeGuesserGame, episodesData };
