﻿const fs = require('fs');
const { EmbedBuilder } = require('discord.js');
const stringSimilarity = require('string-similarity');
const { addNFCoins } = require('../economy');
const { log, userField, recordWinStreak } = require('../helpers');
const { guesserBlockFilter, recordGuesserWin } = require('./GuesserCooldown');
const { recordGameWin } = require('../stats');
const config = require('../config');

let quoteData = [];
try {
    quoteData = JSON.parse(fs.readFileSync('quotes.json', 'utf8'));
    console.log(`[QUOTES] Loaded ${quoteData.length} quotes.`);
} catch (e) {
    console.error('[QUOTES] Failed to load quotes.json');
}

function normalizeGuess(value) {
    return String(value || '')
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9 ]+/g, ' ')
        .replace(/\b(sensei|master|lord)\b/g, '')
        .replace(/\s+/g, ' ')
        .trim();
}

function isCorrectSpeakerGuess(guess, answer, aliases = []) {
    const normalizedGuess = normalizeGuess(guess);
    if (!normalizedGuess) return false;
    const accepted = [answer, ...aliases].map(normalizeGuess).filter(Boolean);
    if (accepted.includes(normalizedGuess)) return true;
    return accepted.some(item => stringSimilarity.compareTwoStrings(normalizedGuess, item) >= 0.86);
}

function buildResultsEmbed(title, scores, totalRounds, rewardText, color = 0xF1C40F) {
    const rows = Array.from(scores.values()).sort((a, b) => b.score - a.score);
    const winner = rows[0];
    const medals = ['🥇', '🥈', '🥉'];
    const leaderboard = rows.length
        ? rows.slice(0, 10).map((player, index) => `${medals[index] || `#${index + 1}`} **${player.username}** - ${player.score} pts`).join('\n')
        : 'No points scored yet.';
    return new EmbedBuilder()
        .setTitle(title)
        .setColor(color)
        .addFields(
            { name: 'Champion', value: winner ? `🏆 **${winner.username}**` : 'No winner', inline: true },
            { name: 'Final Score', value: winner ? `**${winner.score}/${totalRounds}**` : `0/${totalRounds}`, inline: true },
            { name: 'Reward', value: winner ? rewardText : 'No reward', inline: true },
            { name: 'Leaderboard', value: leaderboard, inline: false }
        )
        .setTimestamp();
}

class QuoteGuesserGame {
    constructor(channel, hostId, total) {
        this.channel = channel;
        this.hostId = hostId;
        this.total = total;
        this.current = 0;
        this.scores = new Map();
        this.active = true;
        this.usedQuotes = new Set();
        this.timeout = null;
        this.createdAt = Date.now();
        this.roundAdvanced = false;
        this.roundResolved = false;
    }
    addPoint(userId, username) {
        const entry = this.scores.get(userId) || { userId, username, score: 0 };
        entry.score++;
        entry.username = username;
        this.scores.set(userId, entry);
    }
    getLeaderboard() {
        const arr = Array.from(this.scores.values()).sort((a, b) => b.score - a.score);
        if (arr.length === 0) return ['No points scored yet.'];
        return arr.map((d, i) => `${i + 1}. **${d.username}** - ${d.score} points`);
    }
    stop() {
        this.active = false;
        if (this.timeout) clearTimeout(this.timeout);
    }
    pickQuote() {
        const available = quoteData.filter((_, index) => !this.usedQuotes.has(index));
        if (available.length === 0) return null;
        const item = available[Math.floor(Math.random() * available.length)];
        this.usedQuotes.add(quoteData.indexOf(item));
        return item;
    }
    async startRound(m) {
        if (!this.active) return;
        this.current++;
        if (this.current > this.total) return this.finish(m);
        const q = this.pickQuote();
        if (!q) return this.finish(m);
        this.roundAdvanced = false;
        this.roundResolved = false;
        const timeLimit = 15;
        const embed = new EmbedBuilder()
            .setTitle(`Quote Guesser ${this.current}/${this.total}`)
            .setDescription(`"${q.quote}"\n\n⏳ **${timeLimit}s** left`)
            .setColor(0xF1C40F)
            .setFooter({ text: 'Guess who said it. Answer with only the character name.' });
        const prompt = await m.channel.send({ embeds: [embed] });
        let countdown = timeLimit;
        const interval = setInterval(async () => {
            countdown--;
            if (countdown >= 0 && this.active) {
                embed.setDescription(`"${q.quote}"\n\n⏳ **${countdown}s** left`);
                await prompt.edit({ embeds: [embed] }).catch(() => {});
            }
            if (countdown <= 0) clearInterval(interval);
        }, 1000);
        const collector = m.channel.createMessageCollector({ filter: msg => !msg.author.bot && this.active && guesserBlockFilter(msg), time: timeLimit * 1000 });
        collector.on('collect', async msg => {
            if (this.roundResolved) return;
            if (!isCorrectSpeakerGuess(msg.content, q.answer, q.aliases)) return;
            this.roundResolved = true;
            this.roundAdvanced = true;
            this.addPoint(msg.author.id, msg.author.username);
            await addNFCoins(msg.author.id, 50);
            await msg.react('✅').catch(() => {});
            await m.channel.send(`🎉 **${msg.author.username}** got it! The answer was **${q.answer}**. +50 NFC Coins`);
            clearInterval(interval);
            collector.stop();
            this.timeout = setTimeout(() => this.startRound(m), 2000);
        });
        collector.on('end', async () => {
            clearInterval(interval);
            if (!this.active) return;
            if (!this.roundResolved) await m.channel.send(`❌ Time's up! The answer was **${q.answer}**.`);
            if (this.roundAdvanced) return;
            if (this.current >= this.total) return this.finish(m);
            this.timeout = setTimeout(() => this.startRound(m), 2000);
        });
    }
    async finish(m) {
        if (!this.active) return;
        const winner = Array.from(this.scores.values()).sort((a, b) => b.score - a.score)[0];
        if (winner) {
            await addNFCoins(winner.userId, 500);
            const streak = await recordWinStreak('quote_win', winner.userId);
            await recordGameWin('quote', winner.userId);
            await recordGuesserWin({ id: winner.userId, username: winner.username, send: (content) => m.client.users.fetch(winner.userId).then(user => user.send(content)) }, 'Quote Guesser', m.channel);
            await log('Quote Guesser Won', config.LOG_COLORS.success, [
                { name: 'Winner', value: userField({ id: winner.userId, username: winner.username }) },
                { name: 'Score', value: `${winner.score}/${this.total}`, inline: true },
                { name: 'Win Streak', value: `${streak}`, inline: true },
                { name: 'Reward', value: '500 NFC Coins', inline: true },
            ]);
        }
        await m.channel.send({ embeds: [buildResultsEmbed('🏆 Quote Guesser Results', this.scores, this.total, '+500 NFC Coins', 0xF1C40F)] });
        this.stop();
        require('../index').activeQuoteQuizzes.delete(m.channel.id);
    }
}

module.exports = { QuoteGuesserGame, quoteData, buildResultsEmbed };
