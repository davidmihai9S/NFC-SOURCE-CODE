const { ActivityType } = require('discord.js');
const { registerSlashCommands } = require('../commands/slash');
const { getAuthorizedUserCount, log } = require('../helpers');
const { ensureSuggestionChannels } = require('../suggestions');
const config = require('../config');

module.exports = {
    name: 'clientReady',
    once: true,
    async execute(client) {
        console.log(`✅ BOT ONLINE`);
        await registerSlashCommands(client);
        await ensureSuggestionChannels(client);
        await updateStatus(client);
        setInterval(() => updateStatus(client), 3600000);
        log('✅ Bot Online', config.LOG_COLORS.success, [{ name: 'Status', value: 'Bot ready.' }, { name: 'Servers', value: `${client.guilds.cache.size}` }]);
    }
};

async function updateStatus(client) {
    client.user.setPresence({ activities: [{ name: `👥 Authorized by ${await getAuthorizedUserCount()} users. Owned by NFC.`, type: ActivityType.Playing }], status: 'dnd' });
}
