const { handleSuggestionReaction } = require('../suggestions');

module.exports = {
    name: 'messageReactionAdd',
    async execute(reaction, user) {
        await handleSuggestionReaction(reaction, user).catch(console.error);
    },
};
