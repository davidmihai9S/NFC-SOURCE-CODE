const { MessageFlags, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionsBitField, ChannelType } = require('discord.js');
const config = require('../config');
const { getDb, getDatabasePath } = require('../database');
const { handleSlashCommand, generateInventoryEmbed, generateInventoryListEmbed, buildInventoryRows, buildInventoryListRows } = require('../commands/slash');
const { getNFCoins, addNFCoins, removeNFCoins } = require('../economy');
const { findCard, isBlacklisted, getAllAuthorizedUsers, restartBot, log, userField, serverField, channelField, isFullBotAdmin, hasAdminPanelAccess, isStaffRestrictedAdminAction } = require('../helpers');
const TeaGame = require('../games/TeaGame');
const { TruthDareGame, buildTruthDarePromptPayload } = require('../games/TruthDareGame');
const { handleMinesButton } = require('../games/MinesGame');
const TicTacToeGame = require('../games/TicTacToeGame');
const BlackjackGame = require('../games/BlackjackGame');
const { QuizGame } = require('../games/QuizGame');

const activeGames = require('../index').activeGames;
const activeQuizzes = require('../index').activeQuizzes;
const bot = require('../index').bot;
const pendingTrades = require('../index').pendingTrades;

function parseUserId(value) {
    const match = String(value || '').match(/\d{17,20}/);
    return match ? match[0] : null;
}

async function findAnnouncementChannel(guild, configuredId = null) {
    const me = guild.members.me || await guild.members.fetchMe().catch(() => null);
    const channels = await guild.channels.fetch().catch(() => guild.channels.cache);
    const candidates = [];
    if (configuredId) {
        const configured = channels?.get?.(configuredId) || guild.channels.cache.get(configuredId) || await guild.channels.fetch(configuredId).catch(() => null);
        if (configured) candidates.push(configured);
    }
    if (guild.systemChannel) candidates.push(guild.systemChannel);
    if (guild.publicUpdatesChannel) candidates.push(guild.publicUpdatesChannel);
    if (guild.rulesChannel) candidates.push(guild.rulesChannel);
    candidates.push(...(channels || guild.channels.cache).filter(ch => ch?.type === ChannelType.GuildText).values());

    const seen = new Set();
    for (const channel of candidates) {
        if (!channel || seen.has(channel.id) || !channel.isTextBased?.()) continue;
        seen.add(channel.id);
        const perms = me ? channel.permissionsFor(me) : null;
        if (perms?.has(['ViewChannel', 'SendMessages', 'EmbedLinks'])) return channel;
    }
    return null;
}

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        try {
            // Tea game buttons (public)
            if (interaction.isButton() && (interaction.customId.startsWith('tea_join_') || interaction.customId.startsWith('tea_start_'))) {
                await interaction.deferUpdate().catch(() => {});
                const game = activeGames.get(interaction.channel.id);
                if (!game || !(game instanceof TeaGame)) return interaction.followUp({ content: '❌ This game is no longer active.', flags: MessageFlags.Ephemeral });
                if (interaction.customId.startsWith('tea_join_')) {
                    if (game.players.has(interaction.user.id)) return interaction.followUp({ content: '❌ You are already in the game.', flags: MessageFlags.Ephemeral });
                    game.addPlayer(interaction.user.id, interaction.user.username);
                    return interaction.followUp({ content: `✅ ${interaction.user.username} joined the game!`, flags: MessageFlags.Ephemeral });
                } else {
                    if (interaction.user.id !== game.hostId && !config.authorizedAdmins.includes(interaction.user.id)) return interaction.followUp({ content: '❌ Only the host or an admin can start the game.', flags: MessageFlags.Ephemeral });
                    if (game.players.size === 0) return interaction.followUp({ content: '❌ No one joined. Game cancelled.', flags: MessageFlags.Ephemeral });
                    game.joinCollector?.stop();
                    game.active = true;
                    await interaction.editReply({ content: `🎮 Game starting with ${game.players.size} players!`, components: [] }).catch(() => {});
                    game.startRound();
                    return;
                }
            }

            if (interaction.isButton() && interaction.customId.startsWith('todpick_')) {
                const type = interaction.customId.replace('todpick_', '');
                return interaction.reply(buildTruthDarePromptPayload(type, interaction.user));
            }

            if (interaction.isButton() && interaction.customId.startsWith('mine_')) {
                return handleMinesButton(interaction);
            }

            if (interaction.isButton() && interaction.customId.startsWith('ttt_')) {
                const game = activeGames.get(interaction.channel.id);
                if (!game || !(game instanceof TicTacToeGame)) {
                    return interaction.reply({ content: 'This tic tac toe game is no longer active.', ephemeral: true });
                }
                const index = parseInt(interaction.customId.split('_')[1], 10);
                const result = await game.handleMove(interaction, index);
                if (!game.active) activeGames.delete(interaction.channel.id);
                return result;
            }

            if (interaction.isButton() && interaction.customId.startsWith('blackjack_')) {
                const game = activeGames.get(interaction.channel.id);
                if (!game || !(game instanceof BlackjackGame)) {
                    return interaction.reply({ content: 'This blackjack game is no longer active.', ephemeral: true });
                }
                const action = interaction.customId.replace('blackjack_', '');
                const result = await game.handleAction(interaction, action);
                if (!game.active) activeGames.delete(interaction.channel.id);
                return result;
            }

            if (interaction.isButton() && interaction.customId.startsWith('tod_')) {
                const parts = interaction.customId.split('_');
                const action = parts[1];
                const channelId = parts[2];
                const game = activeGames.get(channelId);
                if (!game || !(game instanceof TruthDareGame)) {
                    return interaction.reply({ content: '❌ This Truth or Dare game is no longer active.', flags: MessageFlags.Ephemeral });
                }

                if (action === 'join') {
                    if (game.active) return interaction.reply({ content: '❌ This game already started.', flags: MessageFlags.Ephemeral });
                    game.addPlayer(interaction.user);
                    return interaction.update(game.buildLobbyPayload()).catch(() => {});
                }

                if (action === 'cancel') {
                    if (interaction.user.id !== game.hostId && !config.authorizedAdmins.includes(interaction.user.id)) {
                        return interaction.reply({ content: '❌ Only the host or an admin can cancel.', flags: MessageFlags.Ephemeral });
                    }
                    game.stop();
                    activeGames.delete(channelId);
                    return interaction.update({ content: '🛑 Truth or Dare cancelled.', embeds: [], components: [] }).catch(() => {});
                }

                if (action === 'start') {
                    if (interaction.user.id !== game.hostId && !config.authorizedAdmins.includes(interaction.user.id)) {
                        return interaction.reply({ content: '❌ Only the host or an admin can start.', flags: MessageFlags.Ephemeral });
                    }
                    if (game.players.size < 2) return interaction.reply({ content: '❌ At least 2 players need to join.', flags: MessageFlags.Ephemeral });
                    return interaction.update(game.start()).catch(() => {});
                }

                if (action === 'truth' || action === 'dare' || action === 'random') {
                    if (!game.active) return interaction.reply({ content: '❌ This game has not started.', flags: MessageFlags.Ephemeral });
                    if (!game.players.has(interaction.user.id)) return interaction.reply({ content: '❌ Join the game before requesting a prompt.', flags: MessageFlags.Ephemeral });
                    if (game.lastType) {
                        const next = game.nextRound();
                        if (!next) {
                            activeGames.delete(channelId);
                            return interaction.update(game.buildEndPayload()).catch(() => {});
                        }
                    }
                    const type = action === 'random' ? (Math.random() < 0.5 ? 'truth' : 'dare') : action;
                    return interaction.update(game.buildPromptPayload(type, interaction.user)).catch(() => {});
                }
            }

            // Inventory pagination (public)
            if (interaction.isButton() && (interaction.customId.startsWith('inv_prev_') || interaction.customId.startsWith('inv_next_') || interaction.customId.startsWith('inv_sort_'))) {
                const parts = interaction.customId.split('_');
                const isSort = parts[1] === 'sort';
                const action = isSort ? parts[2] : parts[1];
                const userId = isSort ? parts[3] : parts[2];
                const oldPage = parseInt(isSort ? parts[4] : parts[3]);
                const data = bot.invPages?.get(interaction.message.id);
                if (!data) return interaction.reply({ content: '⏰ Session expired. Please use `/inventory` or `!inventory` again.', flags: MessageFlags.Ephemeral });
                if (interaction.user.id !== data.userId && interaction.user.id !== data.ownerId) return interaction.reply({ content: '❌ This inventory is not yours!', flags: MessageFlags.Ephemeral });
                let newSort = data.sort || 'alpha';
                let newPage = oldPage;
                if (isSort) {
                    newSort = action;
                    newPage = 0;
                } else {
                    newPage = action === 'prev' ? oldPage - 1 : oldPage + 1;
                }
                if (newPage < 0 || newPage >= data.totalPages) return interaction.deferUpdate().catch(() => {});
                const user = await bot.users.fetch(data.ownerId || userId).catch(() => interaction.user);
                const { embed, totalPages } = await generateInventoryEmbed(user, data.cards, newPage, newSort);
                await interaction.update({ embeds: [embed], components: buildInventoryRows(userId, newPage, totalPages, newSort) }).catch(() => {});
                data.page = newPage;
                data.sort = newSort;
                data.totalPages = totalPages;
                data.timestamp = Date.now();
                bot.invPages.set(interaction.message.id, data);
                return;
            }

            if (interaction.isButton() && (interaction.customId.startsWith('invlist_prev_') || interaction.customId.startsWith('invlist_next_'))) {
                const parts = interaction.customId.split('_');
                const action = parts[1];
                const userId = parts[2];
                const oldPage = parseInt(parts[3]);
                const data = bot.invPages?.get(interaction.message.id);
                if (!data || data.mode !== 'invlist') return interaction.reply({ content: '⏰ Session expired. Please use `!invlist` again.', flags: MessageFlags.Ephemeral });
                if (interaction.user.id !== data.userId && interaction.user.id !== data.ownerId) return interaction.reply({ content: '❌ This inventory is not yours!', flags: MessageFlags.Ephemeral });
                const newPage = action === 'prev' ? oldPage - 1 : oldPage + 1;
                if (newPage < 0 || newPage >= data.totalPages) return interaction.deferUpdate().catch(() => {});
                const user = await bot.users.fetch(data.ownerId || userId).catch(() => interaction.user);
                const { embed, totalPages } = await generateInventoryListEmbed(user, data.cards, newPage);
                await interaction.update({ embeds: [embed], components: buildInventoryListRows(userId, newPage, totalPages) }).catch(() => {});
                data.page = newPage;
                data.totalPages = totalPages;
                data.timestamp = Date.now();
                bot.invPages.set(interaction.message.id, data);
                return;
            }

            // Trade buttons (public)
            if (interaction.isButton() && (interaction.customId.startsWith('trade_accept_') || interaction.customId.startsWith('trade_decline_'))) {
                const db = getDb();
                if (interaction.customId.startsWith('trade_accept_')) {
                    const tid = interaction.customId.replace('trade_accept_', ''), trade = pendingTrades.get(tid);
                    if (!trade) return interaction.reply({ content: '❌ Trade expired.', flags: MessageFlags.Ephemeral });
                    if (interaction.user.id !== trade.to.id) return interaction.reply({ content: '❌ Not for you.', flags: MessageFlags.Ephemeral });
                    await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});
                    try {
                        await db.exec('BEGIN IMMEDIATE');
                        const fromCards = trade.fromCards || [{ name: trade.fromCard.name, quantity: 1 }];
                        const toCards = trade.toCards || [{ name: trade.toCard.name, quantity: 1 }];
                        for (const card of fromCards) {
                            const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [trade.from.id, card.name]);
                            if (!row || row.quantity < card.quantity) throw new Error(`Sender no longer has enough ${card.name}`);
                        }
                        for (const card of toCards) {
                            const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [trade.to.id, card.name]);
                            if (!row || row.quantity < card.quantity) throw new Error(`Receiver no longer has enough ${card.name}`);
                        }
                        for (const card of fromCards) {
                            const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [trade.from.id, card.name]);
                            if (row.quantity > card.quantity) await db.run('UPDATE inventory SET quantity=quantity-? WHERE userId=? AND cardName=?', [card.quantity, trade.from.id, card.name]);
                            else await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [trade.from.id, card.name]);
                            await db.run('INSERT INTO inventory (userId,cardName,quantity) VALUES (?,?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+?', [trade.to.id, card.name, card.quantity, card.quantity]);
                        }
                        for (const card of toCards) {
                            const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [trade.to.id, card.name]);
                            if (row.quantity > card.quantity) await db.run('UPDATE inventory SET quantity=quantity-? WHERE userId=? AND cardName=?', [card.quantity, trade.to.id, card.name]);
                            else await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [trade.to.id, card.name]);
                            await db.run('INSERT INTO inventory (userId,cardName,quantity) VALUES (?,?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+?', [trade.from.id, card.name, card.quantity, card.quantity]);
                        }
                        await db.run('UPDATE trade_requests SET status="completed" WHERE id=?', [tid]);
                        await db.exec('COMMIT');
                        await interaction.editReply({ content: `✅ Trade completed!` });
                        clearTimeout(trade.timeout); pendingTrades.delete(tid);
                        const fc = await bot.channels.fetch(trade.fromChannelId).catch(() => null); if (fc) { const fm = await fc.messages.fetch(trade.fromMsgId).catch(() => null); if (fm) await fm.edit({ content: `✅ Trade completed with ${trade.to.username}`, components: [] }).catch(() => {}); }
                        const tc = await bot.channels.fetch(trade.toChannelId).catch(() => null); if (tc) { const tm = await tc.messages.fetch(trade.toMsgId).catch(() => null); if (tm) await tm.edit({ content: `✅ Trade completed with ${trade.from.username}`, components: [] }).catch(() => {}); }
                    } catch (e) { await db.exec('ROLLBACK'); await interaction.editReply({ content: `❌ Trade failed: ${e.message}` }).catch(() => {}); }
                    return;
                } else {
                    const tid = interaction.customId.replace('trade_decline_', ''), trade = pendingTrades.get(tid);
                    if (!trade) return interaction.reply({ content: '❌ Trade expired.', flags: MessageFlags.Ephemeral });
                    if (interaction.user.id !== trade.to.id) return interaction.reply({ content: '❌ Not for you.', flags: MessageFlags.Ephemeral });
                    await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});
                    clearTimeout(trade.timeout); pendingTrades.delete(tid);
                    await interaction.editReply({ content: '❌ Trade declined.' });
                    const fc = await bot.channels.fetch(trade.fromChannelId).catch(() => null); if (fc) { const fm = await fc.messages.fetch(trade.fromMsgId).catch(() => null); if (fm) await fm.edit({ content: `❌ Trade declined by ${trade.to.username}`, components: [] }).catch(() => {}); }
                    const tc = await bot.channels.fetch(trade.toChannelId).catch(() => null); if (tc) { const tm = await tc.messages.fetch(trade.toMsgId).catch(() => null); if (tm) await tm.edit({ content: `❌ You declined the trade with ${trade.from.username}`, components: [] }).catch(() => {}); }
                    return;
                }
            }

            // Duel select menu (public)
            if (interaction.isStringSelectMenu() && interaction.customId === 'duel_card_select') {
                const uid = interaction.user.id;
                if (!bot.duelData || !bot.duelData[uid]) return interaction.reply({ content: '❌ Duel expired.', flags: MessageFlags.Ephemeral });
                const card = interaction.values[0]; bot.duelData[uid].selectedCard = card;
                await interaction.reply({ content: `✅ Selected **${card}**. Waiting for opponent...`, flags: MessageFlags.Ephemeral });
                const oppId = bot.duelData[uid].opponent;
                if (bot.duelData[oppId] && bot.duelData[oppId].selectedCard) {
                    const userCard = bot.duelData[uid].selectedCard, oppCard = bot.duelData[oppId].selectedCard, userObj = findCard(userCard), oppObj = findCard(oppCard), val = { Common: 1, 'Super Rare': 2, Godly: 3, MYTHIC: 4 };
                    const userVal = val[userObj?.rarity || 'Common'], oppVal = val[oppObj?.rarity || 'Common'];
                    let result, winnerId = null;
                    if (userVal > oppVal) { result = `🏆 ${interaction.user.username} wins! Their ${userObj.name} (${userObj.rarity}) beats ${oppObj.name} (${oppObj.rarity})!`; winnerId = uid; }
                    else if (oppVal > userVal) { result = `🏆 ${oppId} wins! Their ${oppObj.name} (${oppObj.rarity}) beats ${userObj.name} (${userObj.rarity})!`; winnerId = oppId; }
                    else result = `🤝 Tie! Both used ${userObj.name}.`;
                    if (winnerId) await addNFCoins(winnerId, 100);
                    await interaction.user.send(result).catch(() => {}); await bot.users.fetch(oppId).then(u => u.send(result)).catch(() => {});
                    delete bot.duelData[uid]; delete bot.duelData[oppId];
                }
                return;
            }

            // Slash commands
            if (interaction.isCommand()) {
                return handleSlashCommand(interaction);
            }

            // Admin panel buttons (RESTRICTED)
            if (interaction.isButton()) {
                if (!hasAdminPanelAccess(interaction.user.id, interaction.member)) {
                    return interaction.reply({ content: '❌ Unauthorized', flags: MessageFlags.Ephemeral });
                }
                const id = interaction.customId;
                if (!isFullBotAdmin(interaction.user.id) && isStaffRestrictedAdminAction(id)) {
                    return interaction.reply({ content: '❌ Staff cannot use that admin action.', flags: MessageFlags.Ephemeral });
                }
                // Buttons that open modals - do NOT defer
                if (id === 'invite_link' || id === 'user_info' || id === 'mass_giveaway' || id === 'server_announce' || id === 'bot_ban' || id === 'add_card' || id === 'remove_card' || id === 'manage_coins' || id === 'dm_user' || id === 'broadcast_all' || id === 'global_announce' || id === 'create_webhook') {
                    let modal;
                    if (id === 'invite_link') {
                        modal = new ModalBuilder().setCustomId('invite_modal').setTitle('Generate Invite Link');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('server_id').setLabel('Server ID').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('channel_id').setLabel('Channel ID (optional)').setStyle(TextInputStyle.Short).setRequired(false)));
                    } else if (id === 'user_info') {
                        modal = new ModalBuilder().setCustomId('userinfo_modal').setTitle('User Info Lookup');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user_id').setLabel('User ID').setStyle(TextInputStyle.Short).setRequired(true)));
                    } else if (id === 'mass_giveaway') {
                        modal = new ModalBuilder().setCustomId('giveaway_modal').setTitle('Mass Giveaway');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('card_name').setLabel('Card Name').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('quantity').setLabel('Quantity per user (default 1)').setStyle(TextInputStyle.Short).setRequired(false)));
                    } else if (id === 'server_announce') {
                        modal = new ModalBuilder().setCustomId('announce_modal').setTitle('Server Announcement');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('server_id').setLabel('Server ID').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('channel_id').setLabel('Channel ID (optional)').setStyle(TextInputStyle.Short).setRequired(false)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('message').setLabel('Message').setStyle(TextInputStyle.Paragraph).setRequired(true)));
                    } else if (id === 'bot_ban') {
                        modal = new ModalBuilder().setCustomId('ban_modal').setTitle('Ban / Unban User');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user_id').setLabel('User ID').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('action').setLabel('Action (ban or unban)').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('reason').setLabel('Reason (for ban)').setStyle(TextInputStyle.Short).setRequired(false)));
                    } else if (id === 'add_card' || id === 'remove_card') {
                        modal = new ModalBuilder().setCustomId(id === 'add_card' ? 'add_card_modal' : 'remove_card_modal').setTitle(id === 'add_card' ? 'Add Card' : 'Remove Card');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user_id').setLabel('User ID or mention').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('card_name').setLabel('Card name').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('amount').setLabel('Amount').setStyle(TextInputStyle.Short).setRequired(true)));
                    } else if (id === 'manage_coins') {
                        modal = new ModalBuilder().setCustomId('manage_coins_modal').setTitle('Manage Coins');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user_id').setLabel('User ID or mention').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('action').setLabel('Action (add or remove)').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('amount').setLabel('Amount').setStyle(TextInputStyle.Short).setRequired(true)));
                    } else if (id === 'dm_user') {
                        modal = new ModalBuilder().setCustomId('dm_modal').setTitle('Send DM to User');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('user_id').setLabel('User ID').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('message').setLabel('Message').setStyle(TextInputStyle.Paragraph).setRequired(true)));
                    } else if (id === 'broadcast_all') {
                        modal = new ModalBuilder().setCustomId('broadcast_all_modal').setTitle('Broadcast DM to All Users');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('message').setLabel('Message').setStyle(TextInputStyle.Paragraph).setRequired(true)));
                    } else if (id === 'global_announce') {
                        modal = new ModalBuilder().setCustomId('global_announce_modal').setTitle('Global Announcement');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('message').setLabel('Message').setStyle(TextInputStyle.Paragraph).setRequired(true)));
                    } else if (id === 'create_webhook') {
                        modal = new ModalBuilder().setCustomId('webhook_modal').setTitle('Create Webhook');
                        modal.addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('server_id').setLabel('Server ID').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('channel_id').setLabel('Channel ID').setStyle(TextInputStyle.Short).setRequired(true)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('webhook_name').setLabel('Webhook Name (optional)').setStyle(TextInputStyle.Short).setRequired(false)));
                    }
                    if (modal) return interaction.showModal(modal).catch(() => {});
                }
                // Action buttons - need defer but check if already replied
                if (id === 'list_servers' || id === 'leave_server' || id === 'reset_leaderboard' || id === 'export_db' || id === 'server_stats' || id === 'reload_config' || id === 'shutdown_bot' || id === 'restart_bot') {
                    if (!interaction.deferred && !interaction.replied) await interaction.deferUpdate().catch(() => {});
                    if (id === 'list_servers') {
                        const servers = bot.guilds.cache.map(g => `${g.name} (${g.id}) - ${g.memberCount} members`).join('\n');
                        return interaction.followUp({ content: `📡 **Servers:**\n${servers || 'None'}`, flags: MessageFlags.Ephemeral }).catch(() => {});
                    }
                    if (id === 'leave_server') {
                        const select = new StringSelectMenuBuilder().setCustomId('leave_select').setPlaceholder('Select a server').addOptions(bot.guilds.cache.map(g => ({ label: g.name, value: g.id })).slice(0, 25));
                        return interaction.followUp({ content: 'Select server to leave:', components: [new ActionRowBuilder().addComponents(select)], flags: MessageFlags.Ephemeral }).catch(() => {});
                    }
                    if (id === 'reset_leaderboard') {
                        const select = new StringSelectMenuBuilder().setCustomId('reset_select').setPlaceholder('Select server or "all"').addOptions([{ label: '🌍 ALL SERVERS', value: 'all' }, ...bot.guilds.cache.map(g => ({ label: g.name, value: g.id })).slice(0, 24)]);
                        return interaction.followUp({ content: '⚠️ WARNING: This will delete card data.\nSelect server:', components: [new ActionRowBuilder().addComponents(select)], flags: MessageFlags.Ephemeral }).catch(() => {});
                    }
                    if (id === 'export_db') {
                        try { await interaction.followUp({ files: [{ attachment: getDatabasePath(), name: 'database.db' }], flags: MessageFlags.Ephemeral }).catch(() => {}); } catch (e) { await interaction.followUp({ content: `❌ Failed: ${e.message}`, flags: MessageFlags.Ephemeral }).catch(() => {}); }
                        return;
                    }
                    if (id === 'server_stats') {
                        const db = getDb();
                        const totalMembers = bot.guilds.cache.reduce((a, g) => a + g.memberCount, 0), totalCatches = (await db.get('SELECT SUM(quantity) as total FROM inventory')).total || 0, totalCollectors = (await db.all('SELECT DISTINCT userId FROM inventory')).length, topServer = bot.guilds.cache.sort((a, b) => b.memberCount - a.memberCount).first();
                        return interaction.followUp({ content: `📈 **Bot Statistics**\n- Servers: ${bot.guilds.cache.size}\n- Total Members: ${totalMembers}\n- Total Cards Collected: ${totalCatches}\n- Unique Collectors: ${totalCollectors}\n- Largest Server: ${topServer ? `${topServer.name} (${topServer.memberCount} members)` : 'N/A'}`, flags: MessageFlags.Ephemeral }).catch(() => {});
                    }
                    if (id === 'reload_config') {
                        try { const newCards = JSON.parse(require('fs').readFileSync('cards.json', 'utf8')); require('../helpers').ninjagoCards.length = 0; require('../helpers').ninjagoCards.push(...newCards); return interaction.followUp({ content: `✅ Reloaded cards.json (${require('../helpers').ninjagoCards.length} cards)`, flags: MessageFlags.Ephemeral }).catch(() => {}); } catch (e) { return interaction.followUp({ content: `❌ Reload failed: ${e.message}`, flags: MessageFlags.Ephemeral }).catch(() => {}); }
                    }
                    if (id === 'shutdown_bot') { await interaction.followUp({ content: '🛑 Shutting down...', flags: MessageFlags.Ephemeral }).catch(() => {}); setTimeout(() => process.exit(0), 1000); return; }
                    if (id === 'restart_bot') { await interaction.followUp({ content: '🔄 Restarting...', flags: MessageFlags.Ephemeral }).catch(() => {}); setTimeout(() => restartBot(), 1000); return; }
                }
                return;
            }

            // Admin modals (RESTRICTED)
            if (interaction.isModalSubmit()) {
                if (!hasAdminPanelAccess(interaction.user.id, interaction.member)) {
                    return interaction.reply({ content: '❌ Unauthorized', flags: MessageFlags.Ephemeral });
                }
                await interaction.deferReply({ flags: MessageFlags.Ephemeral }).catch(() => {});
                const cid = interaction.customId;
                if (!isFullBotAdmin(interaction.user.id) && isStaffRestrictedAdminAction(cid)) {
                    return interaction.editReply({ content: '❌ Staff cannot use that admin action.' }).catch(() => {});
                }
                const db = getDb();

                if (cid === 'invite_modal') {
                    const sid = interaction.fields.getTextInputValue('server_id'), cid2 = interaction.fields.getTextInputValue('channel_id'), guild = bot.guilds.cache.get(sid);
                    if (!guild) return interaction.editReply({ content: '❌ Server not found.' }).catch(() => {});
                    let ch; if (cid2) ch = guild.channels.cache.get(cid2); else ch = guild.systemChannel || guild.channels.cache.find(c => c.type === 0 && c.permissionsFor(guild.members.me).has('CreateInstantInvite'));
                    if (!ch) return interaction.editReply({ content: '❌ No suitable channel.' }).catch(() => {});
                    try { const invite = await ch.createInvite({ maxAge: 86400, maxUses: 1 }); await interaction.editReply({ content: `🔗 Invite: ${invite.url}` }).catch(() => {}); } catch (e) { await interaction.editReply({ content: `❌ Failed: ${e.message}` }).catch(() => {}); }
                    return;
                }
                if (cid === 'userinfo_modal') {
                    const uid = interaction.fields.getTextInputValue('user_id'), user = await bot.users.fetch(uid).catch(() => null);
                    if (!user) return interaction.editReply({ content: '❌ User not found.' }).catch(() => {});
                    const cards = (await db.get('SELECT COUNT(*) as c FROM inventory WHERE userId=?', [uid])).c || 0, black = await isBlacklisted(uid);
                    return interaction.editReply({ content: `👤 **User Info**\n- Username: ${user.tag}\n- ID: ${user.id}\n- Account Created: ${user.createdAt.toDateString()}\n- Cards Owned: ${cards}\n- Blacklisted: ${black ? 'Yes' : 'No'}` }).catch(() => {});
                }
                if (cid === 'giveaway_modal') {
                    const cardName = interaction.fields.getTextInputValue('card_name'), qty = parseInt(interaction.fields.getTextInputValue('quantity') || '1'), card = findCard(cardName);
                    if (!card) return interaction.editReply({ content: '❌ Card not found.' }).catch(() => {});
                    const users = await db.all('SELECT DISTINCT userId FROM inventory');
                    if (!users.length) return interaction.editReply({ content: '❌ No collectors.' }).catch(() => {});
                    let added = 0;
                    for (const u of users) { await db.run('INSERT INTO inventory (userId,cardName,quantity) VALUES (?,?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+?', [u.userId, card.name, qty, qty]); added++; }
                    return interaction.editReply({ content: `🎁 Gave **${card.name}** (x${qty}) to ${added} collectors.` }).catch(() => {});
                }
                if (cid === 'announce_modal') {
                    const sid = interaction.fields.getTextInputValue('server_id'), cid2 = interaction.fields.getTextInputValue('channel_id'), msg = interaction.fields.getTextInputValue('message'), guild = bot.guilds.cache.get(sid);
                    if (!guild) return interaction.editReply({ content: '❌ Server not found.' }).catch(() => {});
                    let ch; if (cid2) ch = guild.channels.cache.get(cid2); else ch = guild.systemChannel || guild.channels.cache.find(c => c.type === 0 && c.permissionsFor(guild.members.me).has('SendMessages'));
                    if (!ch) return interaction.editReply({ content: '❌ No channel.' }).catch(() => {});
                    try { await ch.send(`📢 **Admin Announcement:**\n${msg}`); await interaction.editReply({ content: `✅ Sent to ${guild.name}#${ch.name}` }).catch(() => {}); } catch (e) { await interaction.editReply({ content: `❌ Failed: ${e.message}` }).catch(() => {}); }
                    return;
                }
                if (cid === 'ban_modal') {
                    const uid = interaction.fields.getTextInputValue('user_id'), action = interaction.fields.getTextInputValue('action').toLowerCase(), reason = interaction.fields.getTextInputValue('reason') || 'No reason';
                    if (action === 'ban') { await db.run('INSERT OR REPLACE INTO blacklist (userId,reason) VALUES (?,?)', [uid, reason]); return interaction.editReply({ content: `🚫 Banned <@${uid}>. Reason: ${reason}` }).catch(() => {}); }
                    else if (action === 'unban') { await db.run('DELETE FROM blacklist WHERE userId=?', [uid]); return interaction.editReply({ content: `✅ Unbanned <@${uid}>.` }).catch(() => {}); }
                    else return interaction.editReply({ content: '❌ Action must be "ban" or "unban".' }).catch(() => {});
                }
                if (cid === 'add_card_modal' || cid === 'remove_card_modal') {
                    const uid = parseUserId(interaction.fields.getTextInputValue('user_id'));
                    const cardName = interaction.fields.getTextInputValue('card_name');
                    const amount = parseInt(interaction.fields.getTextInputValue('amount'), 10);
                    const card = findCard(cardName);

                    if (!uid) return interaction.editReply({ content: '❌ Please enter a valid user ID or mention.' }).catch(() => {});
                    if (!card) return interaction.editReply({ content: '❌ Card not found.' }).catch(() => {});
                    if (!Number.isInteger(amount) || amount <= 0) return interaction.editReply({ content: '❌ Amount must be a positive whole number.' }).catch(() => {});

                    if (cid === 'add_card_modal') {
                        await db.run('INSERT INTO inventory (userId,cardName,quantity) VALUES (?,?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+?', [uid, card.name, amount, amount]);
                        await log('➕ Admin Card Added', config.LOG_COLORS.success, [{ name: 'Admin', value: userField(interaction.user) }, { name: 'User', value: `<@${uid}> (${uid})` }, { name: 'Card', value: card.name }, { name: 'Amount', value: `${amount}` }]);
                        return interaction.editReply({ content: `✅ Added **${card.name}** x${amount} to <@${uid}>.` }).catch(() => {});
                    }

                    const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [uid, card.name]);
                    if (!row) return interaction.editReply({ content: `<@${uid}> does not have **${card.name}**.` }).catch(() => {});
                    if (row.quantity < amount) return interaction.editReply({ content: `<@${uid}> only has **${card.name}** x${row.quantity}.` }).catch(() => {});

                    if (row.quantity === amount) await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [uid, card.name]);
                    else await db.run('UPDATE inventory SET quantity=quantity-? WHERE userId=? AND cardName=?', [amount, uid, card.name]);
                    await log('➖ Admin Card Removed', config.LOG_COLORS.warning, [{ name: 'Admin', value: userField(interaction.user) }, { name: 'User', value: `<@${uid}> (${uid})` }, { name: 'Card', value: card.name }, { name: 'Amount', value: `${amount}` }]);
                    return interaction.editReply({ content: `✅ Removed **${card.name}** x${amount} from <@${uid}>.` }).catch(() => {});
                }
                if (cid === 'manage_coins_modal') {
                    const uid = parseUserId(interaction.fields.getTextInputValue('user_id'));
                    const action = interaction.fields.getTextInputValue('action').toLowerCase().trim();
                    const amount = parseInt(interaction.fields.getTextInputValue('amount'), 10);

                    if (!uid) return interaction.editReply({ content: 'âŒ Please enter a valid user ID or mention.' }).catch(() => {});
                    if (action !== 'add' && action !== 'remove') return interaction.editReply({ content: 'âŒ Action must be `add` or `remove`.' }).catch(() => {});
                    if (!Number.isInteger(amount) || amount <= 0) return interaction.editReply({ content: 'âŒ Amount must be a positive whole number.' }).catch(() => {});

                    if (action === 'add') await addNFCoins(uid, amount);
                    else {
                        const removed = await removeNFCoins(uid, amount);
                        if (!removed) {
                            const balance = await getNFCoins(uid);
                            return interaction.editReply({ content: `<@${uid}> only has **${balance} NFC Coins**.` }).catch(() => {});
                        }
                    }

                    const balance = await getNFCoins(uid);
                    await log(action === 'add' ? '💰 Admin Coins Added' : '💰 Admin Coins Removed', action === 'add' ? config.LOG_COLORS.success : config.LOG_COLORS.warning, [{ name: 'Admin', value: userField(interaction.user) }, { name: 'User', value: `<@${uid}> (${uid})` }, { name: 'Amount', value: `${amount}` }, { name: 'New Balance', value: `${balance}` }]);
                    return interaction.editReply({ content: `✅ ${action === 'add' ? 'Added' : 'Removed'} **${amount} NFC Coins** ${action === 'add' ? 'to' : 'from'} <@${uid}>. New balance: **${balance}**.` }).catch(() => {});
                }
                if (cid === 'dm_modal') {
                    const uid = interaction.fields.getTextInputValue('user_id'), msg = interaction.fields.getTextInputValue('message'), user = await bot.users.fetch(uid).catch(() => null);
                    if (!user) return interaction.editReply({ content: '❌ User not found.' }).catch(() => {});
                    try { await user.send(msg); await interaction.editReply({ content: `✅ DM sent to ${user.tag}` }).catch(() => {}); } catch (e) { await interaction.editReply({ content: `❌ Failed: ${e.message}` }).catch(() => {}); }
                    return;
                }
                if (cid === 'broadcast_all_modal') {
                    const msg = interaction.fields.getTextInputValue('message');
                    const users = await getAllAuthorizedUsers();
                    let success = 0, fail = 0;
                    for (const uid of users) {
                        const u = await bot.users.fetch(uid).catch(() => null);
                        if (u) { try { await u.send(`📢 **Admin Broadcast:**\n${msg}`); success++; } catch (e) { fail++; } } else fail++;
                        await new Promise(r => setTimeout(r, 100));
                    }
                    return interaction.editReply({ content: `✅ Broadcast complete: ${success} delivered, ${fail} failed.` }).catch(() => {});
                }
                if (cid === 'global_announce_modal') {
                    const msg = interaction.fields.getTextInputValue('message');
                    const guilds = bot.guilds.cache.values();
                    let success = 0, fail = 0;
                    for (const guild of guilds) {
                        const configRow = await db.get('SELECT announcementChannelId FROM server_config WHERE guildId = ?', [guild.id]);
                        const channel = await findAnnouncementChannel(guild, configRow?.announcementChannelId);
                        if (!channel) {
                            fail++;
                            continue;
                        }
                        try { await channel.send({ embeds: [new EmbedBuilder().setTitle('🌍 Global Announcement').setDescription(msg).setColor(0x9B59B6).setTimestamp()] }); success++; } catch (e) { fail++; }
                        await new Promise(r => setTimeout(r, 200));
                    }
                    await interaction.editReply({ content: `✅ Global announcement sent to **${success}** servers (${fail} failed).` }).catch(() => {});
                    await log('🌍 Global Announcement', config.LOG_COLORS.info, [{ name: 'Admin', value: userField(interaction.user) }, { name: 'Servers Reached', value: `${success}` }, { name: 'Failed', value: `${fail}` }]);
                    return;
                }
                if (cid === 'webhook_modal') {
                    const sid = interaction.fields.getTextInputValue('server_id'), cid2 = interaction.fields.getTextInputValue('channel_id'), name = interaction.fields.getTextInputValue('webhook_name') || 'Ninjago Bot Webhook';
                    const guild = bot.guilds.cache.get(sid);
                    if (!guild) return interaction.editReply({ content: '❌ Server not found.' }).catch(() => {});
                    const channel = guild.channels.cache.get(cid2);
                    if (!channel || !channel.isTextBased()) return interaction.editReply({ content: '❌ Channel not found or not a text channel.' }).catch(() => {});
                    const me = guild.members.me;
                    if (!channel.permissionsFor(me).has('ManageWebhooks')) return interaction.editReply({ content: '❌ Bot lacks Manage Webhooks permission in that channel.' }).catch(() => {});
                    try { const webhook = await channel.createWebhook({ name }); await interaction.editReply({ content: `✅ Webhook created!\nURL: \`${webhook.url}\`` }).catch(() => {}); await log('🔗 Webhook Created', config.LOG_COLORS.success, [{ name: 'Admin', value: userField(interaction.user) }, { name: 'Server', value: serverField(guild) }, { name: 'Channel', value: channelField(channel) }, { name: 'Webhook', value: webhook.name }]); } catch (e) { await interaction.editReply({ content: `❌ Failed to create webhook: ${e.message}` }).catch(() => {}); }
                    return;
                }
            }

            // Admin select menus (RESTRICTED)
            if (interaction.isStringSelectMenu()) {
                if (!hasAdminPanelAccess(interaction.user.id, interaction.member)) {
                    return interaction.reply({ content: '❌ Unauthorized', flags: MessageFlags.Ephemeral });
                }
                await interaction.deferUpdate().catch(() => {});
                const cid = interaction.customId;
                if (!isFullBotAdmin(interaction.user.id) && isStaffRestrictedAdminAction(cid)) {
                    return interaction.followUp({ content: '❌ Staff cannot use that admin action.', flags: MessageFlags.Ephemeral }).catch(() => {});
                }
                const db = getDb();
                if (cid === 'leave_select') {
                    const gid = interaction.values[0], guild = bot.guilds.cache.get(gid);
                    if (!guild) return interaction.editReply({ content: '❌ Server not found.', components: [] }).catch(() => {});
                    await guild.leave();
                    return interaction.editReply({ content: `✅ Left ${guild.name}`, components: [] }).catch(() => {});
                }
                if (cid === 'reset_select') {
                    const scope = interaction.values[0];
                    if (scope === 'all') { await db.run('DELETE FROM inventory'); await db.run('DELETE FROM catches'); return interaction.editReply({ content: '🗑️ Reset all servers.', components: [] }).catch(() => {}); }
                    else {
                        const guild = bot.guilds.cache.get(scope);
                        if (!guild) return interaction.editReply({ content: '❌ Server not found.', components: [] }).catch(() => {});
                        const members = await guild.members.fetch(); const uids = members.map(m => m.id);
                        if (!uids.length) return interaction.editReply({ content: '❌ No members.', components: [] }).catch(() => {});
                        await db.run(`DELETE FROM inventory WHERE userId IN (${uids.map(() => '?').join(',')})`, uids);
                        await db.run(`DELETE FROM catches WHERE guildId=?`, [scope]);
                        return interaction.editReply({ content: `🗑️ Reset leaderboard for ${guild.name}.`, components: [] }).catch(() => {});
                    }
                }
            }
        } catch (e) {
            console.error('❌ Interaction error:', e);
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({ content: 'An error occurred.', flags: MessageFlags.Ephemeral }).catch(() => {});
            }
        }
    }
};
