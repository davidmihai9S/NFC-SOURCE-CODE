module.exports = {
    TOKEN: 'MTU2MTUyNTE2MjQ4MDc2NzA5Ng.GiU96-.ihsR8lOCKpt8CgPp42Iwz9v50LI69OfUv96M9s',
    ALLOWED_SERVER_IDS: ['1246541149573746849', '1496532079641628776', '1528870616482971709'],
    SPAWN_LIMIT: 25,
    COLLECTION_TIME: 25000,
    SHOP_REFRESH_MS: 30 * 60 * 1000,
    CARD_IMAGE_DIR: './assets/cards',
    LOG_WEBHOOK: 'https://discord.com/api/webhooks/1500247107821371392/IU-_R-I_1GUjE4xW5kzkXtXB-89Wv5Gzev2orP3DVaYus9bRCeGbdHPrVLStVRd-knJQ',
    LOG_WEBHOOKS: [
        'https://discord.com/api/webhooks/1500247107821371392/IU-_R-I_1GUjE4xW5kzkXtXB-89Wv5Gzev2orP3DVaYus9bRCeGbdHPrVLStVRd-knJQ',
    ],
    TOTAL_CARDS: require('./cards.json').length,
    COMMON_GIFS: [
        './assets/gifs/New Card 1.gif',
        './assets/gifs/New Card 2.gif',
    ],
    SUPER_RARE_GIFS: [
        './assets/gifs/Super Rare 1.gif',
        './assets/gifs/Super Rare 2.gif',
    ],
    SUPER_RARE_GIF: './assets/gifs/Super Rare 1.gif',
    MYTHIC_GIF: './assets/gifs/Mythical Card.gif',
    ZANT_TANZ_GIF: './assets/gifs/Zant Tanz.gif',
    SOURCE_DRAGON_GIF: './assets/gifs/Source Dragons.gif',
    SET_GUESSER_DIR: './assets/set-guesser',
    MINIFIGURE_GUESSER_DIR: './assets/minifigure-guesser',
    authorizedAdmins: ['1204043614762573914','1438499232586928141'],
    STAFF_ADMIN_ROLE_ID: '1493308704727236688',
    LOG_COLORS: { info: 0x3498DB, success: 0x2ECC71, warning: 0xFF8C00, danger: 0xFF4500, mythic: 0xFFFFFF, gold: 0xFFD700, fled: 0xFF0000 }
};
