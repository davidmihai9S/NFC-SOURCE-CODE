const { EmbedBuilder } = require('discord.js');
const config = require('./config');
const { getDb } = require('./database');
const { getNFCoins, removeNFCoins } = require('./economy');
const { ninjagoCards } = require('./helpers');

function formatDuration(ms) {
    const total = Math.max(0, Math.ceil(ms / 1000));
    const m = Math.floor(total / 60);
    const s = total % 60;
    return `${m}m ${s}s`;
}

function shopPeriod(now = Date.now()) {
    return Math.floor(now / config.SHOP_REFRESH_MS);
}

function seededRandom(seed) {
    let value = seed % 2147483647;
    if (value <= 0) value += 2147483646;
    return () => {
        value = value * 16807 % 2147483647;
        return (value - 1) / 2147483646;
    };
}

function cardPrice(card) {
    if (card.rarity === 'MYTHIC') return 25000;
    if (card.rarity === 'Godly') return 20000;
    if (card.rarity === 'Super Rare') return 10000;
    return 2500;
}

function rarityIcon(rarity) {
    if (rarity === 'Godly') return '🎆';
    if (rarity === 'MYTHIC') return '🌌';
    if (rarity === 'Super Rare') return '✨';
    return '📜';
}

function formatCoins(amount) {
    return amount.toLocaleString('en-US');
}

function currentShop() {
    const period = shopPeriod();
    const random = seededRandom(period + 149653);
    const pool = [...ninjagoCards];
    const items = [];
    while (items.length < 6 && pool.length) {
        const index = Math.floor(random() * pool.length);
        const [card] = pool.splice(index, 1);
        items.push({ slot: items.length + 1, card, price: cardPrice(card) });
    }
    const nextRefresh = (period + 1) * config.SHOP_REFRESH_MS;
    return { period, items, timeLeft: nextRefresh - Date.now() };
}

function buildShopPayload() {
    const shop = currentShop();
    const desc = shop.items.map(item => {
        const rarity = item.card.rarity || 'Common';
        return `**#${item.slot}** ${rarityIcon(rarity)} **${item.card.name}**\nRarity: **${rarity}** | Price: **${formatCoins(item.price)} NFC Coins**`;
    }).join('\n\n');

    const embed = new EmbedBuilder()
        .setTitle('🛒 Rotating NFC Coins Shop')
        .setDescription(desc)
        .addFields({ name: 'Refresh', value: `Next shop in **${formatDuration(shop.timeLeft)}**`, inline: false })
        .setColor(0x2ECC71);
    return { embeds: [embed] };
}

async function sendLiveShopMessage(replyFn) {
    const msg = await replyFn(buildShopPayload());
    let ticks = 0;
    const interval = setInterval(async () => {
        ticks++;
        if (ticks > 120) return clearInterval(interval);
        await msg.edit(buildShopPayload()).catch(() => clearInterval(interval));
    }, 5000);
    return msg;
}

async function buyShopSlot(userId, slot) {
    const shop = currentShop();
    const item = shop.items.find(x => x.slot === slot);
    if (!item) return { ok: false, message: '❌ Pick a shop slot from 1 to 6.' };

    const db = getDb();
    const existing = await db.get('SELECT 1 FROM purchases WHERE userId=? AND itemId=? AND timestamp=?', [userId, slot, shop.period]);
    if (existing) return { ok: false, message: `❌ You already bought shop slot **#${slot}** this refresh. Wait **${formatDuration(shop.timeLeft)}** for a new shop.` };

    const balance = await getNFCoins(userId);
    if (balance < item.price) {
        return { ok: false, message: `❌ You need **${formatCoins(item.price)} NFC Coins** for **${item.card.name}**. You have **${formatCoins(balance)}**.` };
    }

    await removeNFCoins(userId, item.price);
    await db.run('INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1', [userId, item.card.name]);
    await db.run('INSERT INTO purchases (userId,itemId,timestamp) VALUES (?,?,?)', [userId, slot, shop.period]);
    return { ok: true, message: `✅ Purchased **${item.card.name}** for **${formatCoins(item.price)} NFC Coins**!` };
}

module.exports = { buildShopPayload, sendLiveShopMessage, buyShopSlot };
