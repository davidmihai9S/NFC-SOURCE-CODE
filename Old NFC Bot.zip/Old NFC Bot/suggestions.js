const { ChannelType, EmbedBuilder } = require('discord.js');

const SUGGESTIONS_CATEGORY_ID = '1246541150660202547';
const TOP_SUGGESTIONS_CATEGORY_ID = '1308176331472633977';
const SUGGESTIONS_CHANNEL_NAME = '《⚙️》 • 《bot-suggestions》';
const TOP_SUGGESTIONS_CHANNEL_NAME = '《⭐》 • 《top-suggestions》';
const APPROVE_EMOJI = '✅';
const DENY_EMOJI = '❌';
const REQUIRED_APPROVALS = 5;

function channelMatches(channel, targetName) {
    const normalized = String(channel?.name || '').toLowerCase().replace(/\s+/g, '');
    const target = targetName.toLowerCase().replace(/\s+/g, '');
    const plain = targetName.includes('top') ? 'top-suggestions' : 'bot-suggestions';
    return normalized === target || normalized.includes(plain);
}

async function ensureChannel(guild, categoryId, name) {
    const category = guild.channels.cache.get(categoryId) || await guild.channels.fetch(categoryId).catch(() => null);
    if (!category || category.type !== ChannelType.GuildCategory) return null;

    const existing = guild.channels.cache.find(ch => ch.parentId === categoryId && channelMatches(ch, name));
    if (existing) return existing;

    return guild.channels.create({
        name,
        type: ChannelType.GuildText,
        parent: categoryId,
        reason: 'Ensure NFC Bot suggestion channel exists',
    }).catch(() => null);
}

async function ensureSuggestionChannels(client) {
    for (const guild of client.guilds.cache.values()) {
        if (!guild.channels.cache.has(SUGGESTIONS_CATEGORY_ID) || !guild.channels.cache.has(TOP_SUGGESTIONS_CATEGORY_ID)) {
            await guild.channels.fetch().catch(() => null);
        }
        if (guild.channels.cache.has(SUGGESTIONS_CATEGORY_ID)) {
            await ensureChannel(guild, SUGGESTIONS_CATEGORY_ID, SUGGESTIONS_CHANNEL_NAME);
        }
        if (guild.channels.cache.has(TOP_SUGGESTIONS_CATEGORY_ID)) {
            await ensureChannel(guild, TOP_SUGGESTIONS_CATEGORY_ID, TOP_SUGGESTIONS_CHANNEL_NAME);
        }
    }
}

async function ensureSuggestionsChannel(guild) {
    return ensureChannel(guild, SUGGESTIONS_CATEGORY_ID, SUGGESTIONS_CHANNEL_NAME);
}

async function ensureTopSuggestionsChannel(guild) {
    return ensureChannel(guild, TOP_SUGGESTIONS_CATEGORY_ID, TOP_SUGGESTIONS_CHANNEL_NAME);
}

function buildSuggestionEmbed(user, text, sourceChannel) {
    return new EmbedBuilder()
        .setTitle('💡 Bot Suggestion')
        .setDescription(text)
        .addFields(
            { name: 'Suggested By', value: `<@${user.id}>`, inline: true },
            { name: 'Source', value: sourceChannel ? `${sourceChannel}` : 'Unknown', inline: true },
        )
        .setColor(0xF1C40F)
        .setFooter({ text: 'Suggestion' })
        .setTimestamp();
}

async function submitSuggestion({ guild, user, sourceChannel, text }) {
    const channel = await ensureSuggestionsChannel(guild);
    if (!channel) return { ok: false, message: '❌ Suggestions category/channel could not be found or created.' };

    const sent = await channel.send({ embeds: [buildSuggestionEmbed(user, text, sourceChannel)] });
    await sent.react(APPROVE_EMOJI).catch(() => {});
    await sent.react(DENY_EMOJI).catch(() => {});
    return { ok: true, channel, message: `✅ Suggestion sent to ${channel}.` };
}

async function handleSuggestionReaction(reaction, user) {
    if (user.bot || reaction.emoji.name !== APPROVE_EMOJI) return;
    if (reaction.partial) await reaction.fetch().catch(() => null);
    const message = reaction.message.partial ? await reaction.message.fetch().catch(() => null) : reaction.message;
    if (!message?.guild || !message.embeds?.length) return;
    if (!channelMatches(message.channel, SUGGESTIONS_CHANNEL_NAME)) return;

    const embedData = message.embeds[0];
    const footerText = embedData.footer?.text || '';
    if (!footerText.startsWith('Suggestion') || footerText.includes('Promoted')) return;

    const users = await reaction.users.fetch().catch(() => null);
    const approvalCount = users ? users.filter(voter => !voter.bot).size : Math.max(0, reaction.count - 1);
    if (approvalCount < REQUIRED_APPROVALS) return;

    const topChannel = await ensureTopSuggestionsChannel(message.guild);
    if (!topChannel) return;

    const promotedEmbed = EmbedBuilder.from(embedData)
        .setTitle('⭐ Top Suggestion')
        .setColor(0x2ECC71)
        .setFooter({ text: `Promoted from ${message.id}` });
    await topChannel.send({ content: `⭐ Promoted with **${approvalCount}** approvals. Original: ${message.url}`, embeds: [promotedEmbed] }).catch(() => {});

    const originalEmbed = EmbedBuilder.from(embedData).setFooter({ text: 'Suggestion • Promoted' });
    await message.edit({ embeds: [originalEmbed] }).catch(() => {});
}

module.exports = { ensureSuggestionChannels, submitSuggestion, handleSuggestionReaction };
