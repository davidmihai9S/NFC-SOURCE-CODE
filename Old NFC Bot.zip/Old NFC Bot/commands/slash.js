const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField, MessageFlags, ChannelType, StringSelectMenuBuilder } = require('discord.js');
const config = require('../config');
const { getDb } = require('../database');
const { getNFCoins, addNFCoins, removeNFCoins } = require('../economy');
const { findCard, getRank, setNotification, getAuthorizedUserCount, log, userField, serverField, channelField, embedWithImage, sortInventoryCards, inventorySortLabel, getProfileSettings, setFavoriteCard, setElementalPower, setWishlistCard, ELEMENTS, buildServerListEmbeds, isFullBotAdmin, hasAdminPanelAccess } = require('../helpers');
const { EpisodeGuesserGame } = require('../games/EpisodeGuesser');
const TeaGame = require('../games/TeaGame');
const { buildTruthDarePromptPayload } = require('../games/TruthDareGame');
const { startMinesGame } = require('../games/MinesGame');
const TicTacToeGame = require('../games/TicTacToeGame');
const BlackjackGame = require('../games/BlackjackGame');
const { createLocationGuesserGame, createSetGuesserGame, createMinifigureGuesserGame } = require('../games/ImageGuesserGame');
const { QuizGame } = require('../games/QuizGame');
const { QuoteGuesserGame, quoteData } = require('../games/QuoteGuesser');
const { buildShopPayload, buyShopSlot } = require('../shop');
const { submitSuggestion } = require('../suggestions');
const { GAME_CHOICES, buildCoinsLeaderboardEmbed, buildGameLeaderboardEmbed } = require('../stats');
const { version: BOT_VERSION } = require('../package.json');

const activeGames = require('../index').activeGames;
const activeQuizzes = require('../index').activeQuizzes;
const activeQuoteQuizzes = require('../index').activeQuoteQuizzes;
const bot = require('../index').bot;

const rpVerbs = { attack: 'attacks', hug: 'hugs', kill: 'kills', slap: 'slaps', punch: 'punches', kiss: 'kisses', highfive: 'high-fives', handshake: 'shakes hands with' };
async function roleplayReply(i, action, target, gif) {
    const verb = rpVerbs[action] || action + 's';
    await i.reply(`**${i.user.username}** ${verb} ${target ? `**${target.username}**` : ''}! ${gif}`);
    await log('?? Roleplay Used', config.LOG_COLORS.info, [{ name: 'Action', value: action }, { name: 'User', value: userField(i.user) }, { name: 'Target', value: target ? userField(target) : 'None' }]);
}

function formatMissingCardsList(cards, maxLength = 1500) {
    const lines = cards.map(card => `- ${card.name}`);
    const output = [];
    let length = 0;

    for (const line of lines) {
        const nextLength = length + (output.length ? 1 : 0) + line.length;
        if (nextLength > maxLength) break;
        output.push(line);
        length = nextLength;
    }

    if (output.length < lines.length) {
        while (output.length) {
            const candidate = `${output.join('\n')}\nAnd More`;
            if (candidate.length <= maxLength) return candidate;
            output.pop();
        }
        return 'And More';
    }

    return output.join('\n');
}

async function generateInventoryEmbed(user, cards, page = 0, sort = 'alpha') {
    const ninjagoCards = require('../helpers').ninjagoCards;
    const sortedCards = sortInventoryCards(cards, sort);
    const perPage = 10, totalPages = Math.max(1, Math.ceil(sortedCards.length / perPage)), start = page * perPage, end = start + perPage, pageCards = sortedCards.slice(start, end);
    const rarities = pageCards.map(c => ninjagoCards.find(card => card.name === c.cardName)?.rarity || 'Common');
    const hasGodly = rarities.includes('Godly'), hasMythic = rarities.includes('MYTHIC'), hasSuperRare = rarities.includes('Super Rare');
    const embedColor = hasMythic ? 0xFFFFFF : (hasGodly ? 0xFF5A36 : (hasSuperRare ? 0xFFD700 : 0x00AE86));
    let description = '';
    for (const c of pageCards) {
        const info = ninjagoCards.find(card => card.name === c.cardName);
        const rarityEmoji = info?.rarity === 'Godly' ? '\u{1F386}' : (info?.rarity === 'MYTHIC' ? '\u{1F30C}' : (info?.rarity === 'Super Rare' ? '\u2728' : '\u{1F4DC}'));
        description += rarityEmoji + ' **' + c.cardName + '** - `x' + c.quantity + '`\n';
    }
    const uniqueCount = cards.length;
    const percent = Math.floor((uniqueCount / config.TOTAL_CARDS) * 100);
    const barLen = 20, filled = Math.floor((uniqueCount / config.TOTAL_CARDS) * barLen), empty = barLen - filled;
    const progressBar = '\u2588'.repeat(filled) + '\u2591'.repeat(empty);
    const avatarURL = user.displayAvatarURL() || 'https://cdn.discordapp.com/embed/avatars/0.png';
    const embed = new EmbedBuilder()
        .setTitle('\u{1F392} ' + user.username + "'s Ninja Scroll")
        .setDescription(description || 'No cards on this page.')
        .setColor(embedColor)
        .setThumbnail(avatarURL)
        .addFields({ name: '\u{1F4CA} Collection Progress', value: progressBar + ' ' + percent + '%', inline: false }, { name: '\u{1F3B4} Unique Cards', value: uniqueCount + '/' + config.TOTAL_CARDS, inline: true }, { name: '\u{1F4E6} Total Copies', value: String(cards.reduce((sum, c) => sum + c.quantity, 0)), inline: true }, { name: '\u{1F3C5} Rank', value: getRank(uniqueCount), inline: true })
        .setFooter({ text: 'Page ' + (page + 1) + '/' + totalPages + ' - Sorted by ' + inventorySortLabel(sort) });
    const firstInfo = pageCards.length ? ninjagoCards.find(card => card.name === pageCards[0].cardName) : null;
    if (firstInfo?.image && /^https?:\/\//i.test(firstInfo.image)) embed.setThumbnail(firstInfo.image);
    return { embed, totalPages };
}

async function generateInventoryListEmbed(user, cards, page = 0) {
    const ninjagoCards = require('../helpers').ninjagoCards;
    const groups = [
        { label: '\u{1F30C} Mythic', rarity: 'MYTHIC' },
        { label: '\u{1F386} Godly', rarity: 'Godly' },
        { label: '\u2728 Super Rare', rarity: 'Super Rare' },
        { label: '\u{1F4DC} Common', rarity: 'Common' },
    ];
    const lines = [];
    for (const group of groups) {
        const entries = cards
            .filter(card => (ninjagoCards.find(info => info.name === card.cardName)?.rarity || 'Common') === group.rarity)
            .sort((a, b) => a.cardName.localeCompare(b.cardName))
            .map(card => `• **${card.cardName}** (x${card.quantity})`);

        lines.push(`${group.label} (${entries.length})`);
        if (entries.length) lines.push(...entries);
        else lines.push('None');
        lines.push('');
    }

    const pageTexts = [];
    let currentText = '';
    for (const line of lines) {
        const nextText = currentText ? `${currentText}\n${line}` : line;
        if (nextText.length > 3800) {
            pageTexts.push(currentText);
            currentText = line;
        } else {
            currentText = nextText;
        }
    }
    if (currentText) pageTexts.push(currentText);

    const totalPages = Math.max(1, pageTexts.length);
    const safePage = Math.max(0, Math.min(page, totalPages - 1));
    const embed = new EmbedBuilder()
        .setTitle('\u{1F392} ' + user.username + "'s Full Inventory List")
        .setColor(0x3498DB)
        .setThumbnail(user.displayAvatarURL())
        .setDescription(pageTexts[safePage] || 'Inventory is empty.')
        .setFooter({ text: 'Page ' + (safePage + 1) + '/' + totalPages + ' - Total unique cards: ' + cards.length });
    return { embed, totalPages };
}

function buildInventoryRows(userId, page, totalPages, sort = 'alpha') {
    return [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('inv_prev_' + userId + '_' + page).setLabel('Prev').setStyle(ButtonStyle.Primary).setDisabled(page === 0),
            new ButtonBuilder().setCustomId('inv_next_' + userId + '_' + page).setLabel('Next').setStyle(ButtonStyle.Primary).setDisabled(page === totalPages - 1)
        ),
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('inv_sort_alpha_' + userId + '_' + page).setLabel('A-Z').setStyle(sort === 'alpha' ? ButtonStyle.Success : ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('inv_sort_rarity_' + userId + '_' + page).setLabel('Rarity').setStyle(sort === 'rarity' ? ButtonStyle.Success : ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('inv_sort_most_' + userId + '_' + page).setLabel('Most').setStyle(sort === 'most' ? ButtonStyle.Success : ButtonStyle.Secondary),
            new ButtonBuilder().setCustomId('inv_sort_least_' + userId + '_' + page).setLabel('Least').setStyle(sort === 'least' ? ButtonStyle.Success : ButtonStyle.Secondary)
        )
    ];
}

function buildInventoryListRows(userId, page, totalPages) {
    return [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('invlist_prev_' + userId + '_' + page).setLabel('Prev').setStyle(ButtonStyle.Primary).setDisabled(page === 0),
            new ButtonBuilder().setCustomId('invlist_next_' + userId + '_' + page).setLabel('Next').setStyle(ButtonStyle.Primary).setDisabled(page === totalPages - 1)
        )
    ];
}

const slashCommands = [
    { name: 'userhelp', description: 'Show all available slash commands' },
    { name: 'ping', description: 'Check bot latency' },
    { name: 'daily', description: 'Claim a random common card (once per day)' },
    { name: 'bonus', description: 'Claim a random Super Rare card (once per week)' },
    { name: 'inventory', description: 'View your card collection' },
    { name: 'profile', description: 'Show your card stats and rank' },
    { name: 'setfavorite', description: 'Set your profile favorite card', options: [{ name: 'card', type: 3, description: 'Card name you own', required: true }] },
    { name: 'setelement', description: 'Set your profile elemental power', options: [{ name: 'element', type: 3, description: 'Elemental power', required: true, choices: ELEMENTS.map(e => ({ name: e, value: e })) }] },
    { name: 'wishlist', description: 'Show or set your wishlist card', options: [{ name: 'card', type: 3, description: 'Card name, or clear', required: false }] },
    { name: 'cardscount', description: 'See how many unique cards you have' },
    { name: 'lb', description: 'Global leaderboard' },
    { name: 'coinslb', description: 'NFC Coins leaderboard' },
    { name: 'gamelb', description: 'Leaderboard for a specific game', options: [{ name: 'game', type: 3, description: 'Pick a game', required: true, choices: GAME_CHOICES }] },
    { name: 'balance', description: 'Check your NFC Coins balance' },
    { name: 'shop', description: 'View the NFC Coins shop' },
    { name: 'buy', description: 'Purchase an item from the shop', options: [{ name: 'item_id', type: 4, description: 'The ID of the item to buy', required: true }] },
    { name: 'coinflip', description: 'Gamble NFC Coins on a coin flip', options: [{ name: 'amount', type: 3, description: 'Amount of NFC Coins, or all', required: true }, { name: 'side', type: 3, description: 'heads or tails', required: false, choices: [{ name: 'heads', value: 'heads' }, { name: 'tails', value: 'tails' }] }] },
    { name: 'mines', description: 'Play NFC Mines with NFC Coins', options: [{ name: 'bet', type: 3, description: 'Amount of NFC Coins, cashout, max 50000', required: true }, { name: 'mines', type: 4, description: 'Number of mines (1-24, default 5)', required: false }] },
    { name: 'botservers', description: 'Admin: list bot servers with invite links' },
    { name: 'gift', description: 'Gift a card to someone', options: [{ name: 'user', type: 6, description: 'The user to gift to', required: true }, { name: 'card', type: 3, description: 'Card name', required: true }] },
    { name: 'cardsearch', description: 'Find who owns a specific card', options: [{ name: 'card', type: 3, description: 'Card name', required: true }] },
    { name: 'cardsleft', description: 'See which cards you\'re missing' },
    { name: 'checktrade', description: 'See what cards another user has that you don\'t', options: [{ name: 'user', type: 6, description: 'The user to check', required: true }] },
    { name: 'transferall', description: 'Move your entire collection to another user', options: [{ name: 'user', type: 6, description: 'The user to transfer to', required: true }] },
    { name: 'trade', description: 'Propose a trade', options: [{ name: 'user', type: 6, description: 'The user to trade with', required: true }, { name: 'your_card', type: 3, description: 'Your card name', required: true }, { name: 'their_card', type: 3, description: 'Their card name', required: true }] },
    { name: 'accepttrade', description: 'Accept a pending trade', options: [{ name: 'id', type: 3, description: 'Trade ID', required: true }] },
    { name: 'declinetrade', description: 'Decline a pending trade', options: [{ name: 'id', type: 3, description: 'Trade ID', required: true }] },
    { name: 'duplicates', description: 'List all cards you have more than 1 copy of' },
    { name: 'duel', description: 'Battle another player using card rarity', options: [{ name: 'user', type: 6, description: 'The user to duel', required: true }] },
    { name: 'quiz', description: 'Start a Ninjago trivia game', options: [{ name: 'rounds', type: 4, description: 'Number of questions (1-20, default 10)', required: false }] },
    { name: 'quotequiz', description: 'Start a quote guesser game', options: [{ name: 'rounds', type: 4, description: 'Number of quotes (1-20, default 10)', required: false }] },
    { name: 'locationguesser', description: 'Start a 10-round location guesser' },
    { name: 'setguesser', description: 'Start a 10-round set guesser' },
    { name: 'minifigureguesser', description: 'Start a 10-round minifigure guesser' },
    { name: 'tictactoe', description: 'Challenge someone to tic tac toe', options: [{ name: 'user', type: 6, description: 'The user to challenge', required: true }] },
    { name: 'blackjack', description: 'Play blackjack against the dealer' },
    { name: 'truth', description: 'Get a random Truth prompt' },
    { name: 'dare', description: 'Get a random Dare prompt' },
    { name: 'random', description: 'Get a random Truth or Dare prompt' },
    { name: 'tod', description: 'Get a random Truth or Dare prompt' },
    { name: 'blacktea', description: 'Start a Black Tea game (survival word game)' },
    { name: 'greentea', description: 'Start a Green Tea game (10 rounds)' },
    { name: 'teajoin', description: 'Join a pending Tea game' },
    { name: 'teaquit', description: 'Leave a Tea game' },
    { name: 'teastop', description: 'Stop the current Tea game (host/admin)' },
    { name: 'botinfo', description: 'Show bot statistics and uptime' },
    { name: 'support', description: 'Join the support server' },
    { name: 'suggest', description: 'Suggest an idea for the bot', options: [{ name: 'idea', type: 3, description: 'What should be added or changed?', required: true }] },
    { name: 'topcards', description: 'Show the 5 most owned cards' },
    { name: 'rarest', description: 'Show the 5 least owned cards' },
    { name: 'notification', description: 'Toggle DM alerts for rare card spawns', options: [{ name: 'state', type: 3, description: 'on or off', required: true, choices: [{ name: 'on', value: 'on' }, { name: 'off', value: 'off' }] }] },
    { name: 'attack', description: 'Attack someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'hug', description: 'Hug someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'kill', description: 'Kill someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'slap', description: 'Slap someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'punch', description: 'Punch someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'kiss', description: 'Kiss someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'highfive', description: 'High five someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'handshake', description: 'Handshake with someone', options: [{ name: 'user', type: 6, description: 'Target user', required: true }] },
    { name: 'ciocnesc', description: 'Easter egg duel (crack eggs)', options: [{ name: 'user', type: 6, description: 'Opponent', required: true }] },
    { name: 'admin', description: 'Open the admin control panel' },
    { name: 'setspawnchannel', description: 'Set the channel where cards will spawn (Admin only)', options: [{ name: 'channel', type: 7, description: 'The channel for card spawns', required: true }] },
    { name: 'spawnconfig', description: 'View the current spawn channel setting' },
    { name: 'setannouncementchannel', description: 'Set the channel for global announcements (Admin only)', options: [{ name: 'channel', type: 7, description: 'The channel for announcements', required: true }] }
];

async function registerSlashCommands(client) {
    await client.application.commands.set(slashCommands.map(cmd => ({
        ...cmd,
        integration_types: [0, 1],
        contexts: [0, 1, 2],
    })));
}

async function handleSlashCommand(interaction) {
    const cmd = interaction.commandName;
    const uid = interaction.user.id;

    if (cmd === 'admin') {
        if (!hasAdminPanelAccess(uid, interaction.member)) return interaction.reply({ content: '? Not authorized.', flags: MessageFlags.Ephemeral });
        const isFullAdmin = isFullBotAdmin(uid);
        const r1 = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('list_servers').setLabel('?? List Servers').setStyle(ButtonStyle.Primary), new ButtonBuilder().setCustomId('invite_link').setLabel('?? Generate Invite').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('leave_server').setLabel('?? Leave Server').setStyle(ButtonStyle.Danger));
        const r2 = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('user_info').setLabel('?? User Info').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('manage_coins').setLabel('?? Manage Coins').setStyle(ButtonStyle.Success), ...(isFullAdmin ? [new ButtonBuilder().setCustomId('mass_giveaway').setLabel('?? Mass Giveaway').setStyle(ButtonStyle.Primary), new ButtonBuilder().setCustomId('reset_leaderboard').setLabel('?? Reset Leaderboard').setStyle(ButtonStyle.Danger)] : []));
        const r3 = new ActionRowBuilder().addComponents(...(isFullAdmin ? [new ButtonBuilder().setCustomId('export_db').setLabel('?? Export Database').setStyle(ButtonStyle.Success)] : []), new ButtonBuilder().setCustomId('server_stats').setLabel('?? Server Stats').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('reload_config').setLabel('?? Reload Config').setStyle(ButtonStyle.Primary));
        const r4 = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('server_announce').setLabel('?? Server Announcement').setStyle(ButtonStyle.Secondary), new ButtonBuilder().setCustomId('bot_ban').setLabel('?? Bot Ban/Unban').setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('add_card').setLabel('? Add Card').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('remove_card').setLabel('? Remove Card').setStyle(ButtonStyle.Danger), ...(isFullAdmin ? [new ButtonBuilder().setCustomId('create_webhook').setLabel('?? Create Webhook').setStyle(ButtonStyle.Success)] : []));
        const r5 = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('dm_user').setLabel('?? DM User').setStyle(ButtonStyle.Primary), new ButtonBuilder().setCustomId('broadcast_all').setLabel('?? Broadcast DM to All Users').setStyle(ButtonStyle.Primary), new ButtonBuilder().setCustomId('global_announce').setLabel('?? Global Announcement').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId('shutdown_bot').setLabel('?? Shutdown').setStyle(ButtonStyle.Danger), new ButtonBuilder().setCustomId('restart_bot').setLabel('?? Restart').setStyle(ButtonStyle.Primary));
        return interaction.reply({ content: '??? **Admin Control Panel**', components: [r1, r2, r3, r4, r5], flags: MessageFlags.Ephemeral });
    }

    const { markUserAuthorized, isBlacklisted } = require('../helpers');
    await markUserAuthorized(interaction.user.id);
    if (await isBlacklisted(interaction.user.id)) return interaction.reply({ content: '? You are blacklisted.', flags: MessageFlags.Ephemeral });
    const full = interaction.guild ? config.ALLOWED_SERVER_IDS.includes(interaction.guild.id) : true;
    const slow = ['lb', 'coinslb', 'gamelb', 'inventory', 'profile', 'setfavorite', 'setelement', 'wishlist', 'cardsearch', 'cardsleft', 'checktrade', 'transferall', 'trade', 'duplicates', 'duel', 'topcards', 'rarest'];
    if (slow.includes(cmd)) await interaction.deferReply();

    const economySlash = ['balance', 'shop', 'buy', 'daily', 'bonus', 'coinflip', 'mines'];
    const fullOnlySlash = ['blacktea', 'greentea', 'teajoin', 'teaquit', 'teastop', 'attack', 'hug', 'kill', 'slap', 'punch', 'kiss', 'highfive', 'handshake', 'ciocnesc', 'epguesser', 'duel', 'trade', 'duplicates', 'quiz', 'quotequiz', 'truth', 'dare', 'random', 'tod', 'locationguesser', 'setguesser', 'minifigureguesser', 'tictactoe', 'blackjack'];
    if (!full && (economySlash.includes(cmd) || fullOnlySlash.includes(cmd))) {
        return interaction.reply({ content: '? This command is only available in the main server (Full Mode) or DMs.', flags: MessageFlags.Ephemeral });
    }

    const db = getDb();
    const { ninjagoCards, TOTAL_CARDS } = require('../helpers');

    if (cmd === 'userhelp') {
        const embed = new EmbedBuilder().setTitle('?? NFC Bot Help').setColor(0x00AE86).addFields(
            { name: '?? Collection', value: '`/inventory`, `/profile`, `/setfavorite`, `/setelement`, `/wishlist`, `/cardscount`, `/cardsleft`, `/cardsearch`, `/topcards`, `/rarest`' },
            { name: '?? Leaderboards', value: '`/lb`, `/coinslb`, `/gamelb`' },
            { name: '?? Trading', value: '`/gift`, `/transferall`, `/trade`, `/checktrade`, `/duplicates`' },
            { name: '?? Games', value: '`/duel`, `/quiz`, `/quotequiz`, `/locationguesser`, `/setguesser`, `/minifigureguesser`, `/truth`, `/dare`, `/random`, `/tod`, `/tictactoe`, `/blackjack`' },
            { name: '?? Tea Games', value: '`/blacktea`, `/greentea` (10 rounds), `/teajoin`, `/teaquit`, `/teastop`' },
            { name: '?? Economy', value: '`/balance`, `/shop`, `/buy`, `/daily`, `/bonus`, `/coinflip`, `/mines` (max bet 50000)' },
            { name: '?? Fair Play', value: 'Card catches under **3s** give fast-catch warnings. **2/2** = 5 minute catch block.' },
            { name: '?? Roleplay', value: '`/attack`, `/hug`, `/kill`, `/slap`, `/punch`, `/kiss`, `/highfive`, `/handshake`, `/ciocnesc`' },
            { name: '?? Notifications', value: '`/notification on/off`' },
            { name: '?? Admin', value: '`/admin`, `/botservers`, `/setspawnchannel`, `/spawnconfig`, `/setannouncementchannel`\nStaff role can use `/admin` except export DB, mass giveaway, reset leaderboard, and create webhook.' },
            { name: '?? Info', value: '`/ping`, `/botinfo`, `/support`, `/suggest`' }
        ).setFooter({ text: `${full ? 'Full Mode' : 'Restricted Mode'} - v${BOT_VERSION}` });
        return interaction.reply({ embeds: [embed] });
    }
    if (cmd === 'ping') { const sent = await interaction.reply({ content: '?? Pinging...', fetchReply: true }); return interaction.editReply(`?? Pong! Latency: ${sent.createdTimestamp - interaction.createdTimestamp}ms\n?? WebSocket: ${bot.ws.ping}ms`); }
    if (cmd === 'daily') {
        const r = await db.get('SELECT lastDaily FROM daily WHERE userId=?', [uid]), now = Date.now();
        if (r && now - r.lastDaily < 86400000) return interaction.reply({ content: `? Come back in ${Math.ceil((86400000 - (now - r.lastDaily)) / 3600000)} hours.`, flags: MessageFlags.Ephemeral });
        const commonCards = ninjagoCards.filter(c => (c.rarity || 'Common') === 'Common');
        const card = commonCards[Math.floor(Math.random() * commonCards.length)];
        await db.run('INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1', [uid, card.name]);
        await db.run('INSERT OR REPLACE INTO daily (userId,lastDaily,lastBonus) VALUES (?,?,COALESCE((SELECT lastBonus FROM daily WHERE userId=?),0))', [uid, now, uid]);
        await addNFCoins(uid, 50);
        return interaction.reply(`?? You received a daily card: **${card.name}** and **50 NFC Coins**!`);
    }
    if (cmd === 'bonus') {
        const r = await db.get('SELECT lastBonus FROM daily WHERE userId=?', [uid]), now = Date.now();
        if (r && now - r.lastBonus < 604800000) return interaction.reply({ content: `? Weekly bonus in ${Math.ceil((604800000 - (now - r.lastBonus)) / 86400000)} days.`, flags: MessageFlags.Ephemeral });
        const superRareCards = ninjagoCards.filter(c => c.rarity === 'Super Rare');
        const card = superRareCards[Math.floor(Math.random() * superRareCards.length)];
        await db.run('INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1', [uid, card.name]);
        await db.run('INSERT OR REPLACE INTO daily (userId,lastDaily,lastBonus) VALUES (?,COALESCE((SELECT lastDaily FROM daily WHERE userId=?),0),?)', [uid, uid, now]);
        await addNFCoins(uid, 200);
        return interaction.reply(`? **Weekly Bonus!** You received a Super Rare card: **${card.name}** and **200 NFC Coins**! ?`);
    }
    if (cmd === 'inventory') {
        const cards = await db.all('SELECT cardName, quantity FROM inventory WHERE userId=? ORDER BY cardName ASC', [uid]);
        if (!cards.length) return interaction.editReply('?? Your inventory is empty!');
        const sort = 'alpha';
        const { embed, totalPages } = await generateInventoryEmbed(interaction.user, cards, 0, sort);
        bot.invViews.set(`${uid}:${uid}`, { cards, timestamp: Date.now() });
        const reply = await interaction.editReply({ embeds: [embed], components: buildInventoryRows(uid, 0, totalPages, sort) });
        bot.invPages.set(reply.id, { userId: uid, ownerId: uid, cards, page: 0, totalPages, sort, timestamp: Date.now() });
        return;
    }
    if (cmd === 'profile') {
        const unique = (await db.get('SELECT COUNT(*) as c FROM inventory WHERE userId=?', [uid])).c || 0;
        const total = (await db.get('SELECT SUM(quantity) as t FROM inventory WHERE userId=?', [uid])).t || 0;
        const cards = await db.all('SELECT cardName FROM inventory WHERE userId=?', [uid]);
        const settings = await getProfileSettings(uid);
        const fav = settings.favoriteCard || (cards.length ? cards[Math.floor(Math.random() * cards.length)].cardName : 'None');
        const element = settings.elementalPower || 'Unset';
        const wishlist = settings.wishlistCard || 'Unset';
        const coins = await getNFCoins(uid);
        return interaction.editReply({ embeds: [new EmbedBuilder().setTitle(`?? ${interaction.user.username}'s Profile`).setThumbnail(interaction.user.displayAvatarURL()).addFields({ name: 'Unique Cards', value: `${unique}/${TOTAL_CARDS}`, inline: true }, { name: 'Total Catches', value: `${total}`, inline: true }, { name: 'NFC Coins', value: `${coins}`, inline: true }, { name: 'Rank', value: getRank(unique), inline: false }, { name: 'Favorite Card', value: fav, inline: true }, { name: 'Elemental Power', value: element, inline: true }, { name: 'Wishlist', value: wishlist, inline: true }).setColor(0x00AE86)] });
    }
    if (cmd === 'setfavorite') {
        const cardName = interaction.options.getString('card');
        const card = findCard(cardName);
        if (!card) return interaction.editReply('\u274c Card not found.');
        const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [uid, card.name]);
        if (!row) return interaction.editReply(`? You need to own **${card.name}** before making it your favorite.`);
        await setFavoriteCard(uid, card.name);
        return interaction.editReply(`? Favorite card set to **${card.name}**.`);
    }
    if (cmd === 'setelement') {
        const element = interaction.options.getString('element');
        if (!ELEMENTS.includes(element)) return interaction.editReply(`? Pick one of: ${ELEMENTS.join(', ')}`);
        await setElementalPower(uid, element);
        return interaction.editReply(`? Elemental power set to **${element}**.`);
    }
    if (cmd === 'wishlist') {
        const picked = interaction.options.getString('card');
        if (!picked) {
            const settings = await getProfileSettings(uid);
            return interaction.editReply(settings.wishlistCard ? `?? Your wishlist card is **${settings.wishlistCard}**.` : '?? You have no wishlist card set.');
        }
        if (picked.toLowerCase() === 'clear') {
            await setWishlistCard(uid, null);
            return interaction.editReply('? Wishlist cleared.');
        }
        const card = findCard(picked);
        if (!card) return interaction.editReply('\u274c Card not found.');
        await setWishlistCard(uid, card.name);
        return interaction.editReply(`? Wishlist card set to **${card.name}**.`);
    }
    if (cmd === 'balance') { const coins = await getNFCoins(uid); return interaction.reply({ embeds: [new EmbedBuilder().setTitle('?? NFC Coins Balance').setDescription(`You have **${coins} NFC Coins**.`).setColor(0xFFD700)] }); }
    if (cmd === 'shop') {
        await interaction.reply(buildShopPayload());
        const msg = await interaction.fetchReply();
        let ticks = 0;
        const interval = setInterval(async () => {
            ticks++;
            if (ticks > 120) return clearInterval(interval);
            await msg.edit(buildShopPayload()).catch(() => clearInterval(interval));
        }, 5000);
        return;
    }
    if (cmd === 'buy') {
        const itemId = interaction.options.getInteger('item_id');
        const result = await buyShopSlot(uid, itemId);
        return result.ok ? interaction.reply(result.message) : interaction.reply({ content: result.message, flags: MessageFlags.Ephemeral });
    }
    if (cmd === 'coinflip') {
        const wagerText = interaction.options.getString('amount')?.toLowerCase();
        const picked = interaction.options.getString('side');
        const balance = await getNFCoins(uid);
        const wager = wagerText === 'all' ? balance : parseInt(wagerText, 10);
        const choice = picked || (Math.random() < 0.5 ? 'heads' : 'tails');
        if (!Number.isInteger(wager) || wager <= 0) return interaction.reply({ content: '? Bet a positive amount of NFC Coins.', flags: MessageFlags.Ephemeral });
        if (wager > balance) return interaction.reply({ content: `? You only have **${balance} NFC Coins**.`, flags: MessageFlags.Ephemeral });
        const paid = await removeNFCoins(uid, wager);
        if (!paid) return interaction.reply({ content: '? You do not have enough NFC Coins for that bet.', flags: MessageFlags.Ephemeral });
        const result = Math.random() < 0.5 ? 'heads' : 'tails';
        const won = choice === result;
        if (won) await addNFCoins(uid, wager * 2);
        const newBalance = await getNFCoins(uid);
        return interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setTitle('?? NFC Coinflip')
                    .setDescription(won ? 'You won the flip.' : 'You lost the flip.')
                    .addFields(
                        { name: 'Your Pick', value: choice, inline: true },
                        { name: 'Result', value: result, inline: true },
                        { name: 'Bet', value: `${wager} NFC Coins`, inline: true },
                        { name: won ? 'Won' : 'Lost', value: `${wager} NFC Coins`, inline: true },
                        { name: 'Balance', value: `${newBalance} NFC Coins`, inline: true },
                    )
                    .setColor(won ? 0x2ECC71 : 0xE74C3C),
            ],
        });
    }
    if (cmd === 'mines') {
        const bet = interaction.options.getString('bet');
        const mineCount = interaction.options.getInteger('mines');
        const messageShim = {
            author: interaction.user,
            reply: async payload => {
                const response = typeof payload === 'string' ? { content: payload } : payload;
                await interaction.reply({ ...response, fetchReply: true });
                return interaction.fetchReply();
            },
        };
        return startMinesGame(messageShim, ['mines', bet, mineCount ? String(mineCount) : undefined]);
    }
    if (cmd === 'truth' || cmd === 'dare' || cmd === 'random' || cmd === 'tod') {
        const type = cmd === 'tod' ? 'random' : cmd;
        return interaction.reply(buildTruthDarePromptPayload(type, interaction.user));
    }
    if (cmd === 'botservers') {
        if (!config.authorizedAdmins.includes(uid)) return interaction.reply({ content: 'Only verified people can use this command.', flags: MessageFlags.Ephemeral });
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });
        const embeds = await buildServerListEmbeds(bot);
        await interaction.editReply({ embeds: embeds.slice(0, 10) });
        for (let i = 10; i < embeds.length; i += 10) {
            await interaction.followUp({ embeds: embeds.slice(i, i + 10), flags: MessageFlags.Ephemeral });
        }
        return;
    }
    if (cmd === 'cardscount') { const u = (await db.get('SELECT COUNT(*) as c FROM inventory WHERE userId=?', [uid])).c || 0; return interaction.reply({ embeds: [new EmbedBuilder().setTitle(`?? Progress: ${interaction.user.username}`).setColor(0x3498DB).addFields({ name: 'Cards', value: `**${u}** / ${TOTAL_CARDS}`, inline: true }, { name: 'Rank', value: `**${getRank(u)}**`, inline: true })] }); }
    if (cmd === 'lb') {
        const top = await db.all('SELECT userId,SUM(quantity) as total FROM inventory GROUP BY userId ORDER BY total DESC LIMIT 10');
        let desc = '';
        for (let i = 0; i < top.length; i++) { const u = await bot.users.fetch(top[i].userId).catch(() => null); desc += `${i + 1}. **${u ? u.username : 'Unknown'}** - ${top[i].total} cards\n`; }
        const userTotal = (await db.get('SELECT SUM(quantity) as total FROM inventory WHERE userId=?', [uid])).total || 0;
        let rank = 'N/A';
        if (userTotal > 0) rank = (await db.get('SELECT COUNT(*)+1 as r FROM (SELECT userId,SUM(quantity) as total FROM inventory GROUP BY userId HAVING total>?)', [userTotal])).r || '?';
        desc += `\n????????????????\n??? **Your rank:** #${rank} (${userTotal} cards)`;
        return interaction.editReply({ embeds: [new EmbedBuilder().setTitle("?? Global Leaderboard").setDescription(desc).setColor(0xFFD700)] });
    }
    if (cmd === 'coinslb') return interaction.editReply({ embeds: [await buildCoinsLeaderboardEmbed(bot, uid)] });
    if (cmd === 'gamelb') return interaction.editReply({ embeds: [await buildGameLeaderboardEmbed(bot, uid, interaction.options.getString('game'))] });
    if (cmd === 'gift') {
        const target = interaction.options.getUser('user'), cardName = interaction.options.getString('card'), card = findCard(cardName);
        if (!card) return interaction.reply('\u274c Card not found.');
        const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [uid, card.name]);
        if (!row) return interaction.reply(`? You don't have this card.`);
        await db.run(row.quantity > 1 ? 'UPDATE inventory SET quantity=quantity-1 WHERE userId=? AND cardName=?' : 'DELETE FROM inventory WHERE userId=? AND cardName=?', [uid, card.name]);
        await db.run('INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1', [target.id, card.name]);
        await log('?? Card Gifted', config.LOG_COLORS.success, [{ name: 'From', value: userField(interaction.user) }, { name: 'To', value: userField(target) }, { name: 'Card', value: card.name }]);
        return interaction.reply(`?? Gifted **${card.name}** to **${target.username}**!`);
    }
    if (cmd === 'cardsearch') {
        const cardName = interaction.options.getString('card'), card = findCard(cardName);
        if (!card) return interaction.editReply('\u274c Card not found.');
        const owners = await db.all('SELECT userId,quantity FROM inventory WHERE cardName=? ORDER BY quantity DESC', [card.name]);
        const desc = owners.length ? owners.map(o => `<@${o.userId}> - x${o.quantity}`).join('\n') : "No one owns this card.";
        return interaction.editReply(embedWithImage(new EmbedBuilder().setTitle(`?? Owners of: ${card.name}`).setDescription(desc).setColor(0x3498DB), card.image, 'setThumbnail'));
    }
    if (cmd === 'cardsleft') {
        const owned = new Set((await db.all('SELECT cardName FROM inventory WHERE userId=?', [uid])).map(c => c.cardName));
        const missing = ninjagoCards.filter(c => !owned.has(c.name));
        if (!missing.length) return interaction.editReply("?? All cards collected!");
        const list = formatMissingCardsList(missing);
        return interaction.editReply({ embeds: [new EmbedBuilder().setTitle(`?? Missing Cards`).setDescription(`Missing **${missing.length}** cards:\n\n${list}`).setColor(0xE74C3C)] });
    }
    if (cmd === 'checktrade') {
        const target = interaction.options.getUser('user');
        const my = new Set((await db.all('SELECT cardName FROM inventory WHERE userId=?', [uid])).map(c => c.cardName));
        const their = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=?', [target.id]);
        const matches = their.filter(c => !my.has(c.cardName));
        const list = matches.map(c => `- **${c.cardName}**${c.quantity > 1 ? ` (x${c.quantity})` : ''}`).join('\n').substring(0, 1500);
        return interaction.editReply({ embeds: [new EmbedBuilder().setTitle(`?? Trades with ${target.username}`).setDescription(list || "No new cards found.").setColor(0x2ECC71)] });
    }
    if (cmd === 'transferall') {
        const target = interaction.options.getUser('user');
        if (target.id === uid) return interaction.reply('? You cannot transfer to yourself.');
        const cards = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=?', [uid]);
        if (!cards.length) return interaction.editReply('?? Your inventory is empty.');
        await db.exec('BEGIN IMMEDIATE');
        try {
            for (const c of cards) { await db.run('INSERT INTO inventory (userId,cardName,quantity) VALUES (?,?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+?', [target.id, c.cardName, c.quantity, c.quantity]); await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [uid, c.cardName]); }
            await db.exec('COMMIT');
            return interaction.editReply(`?? Transferred ${cards.length} unique cards to **${target.username}**!`);
        } catch (e) { await db.exec('ROLLBACK'); return interaction.editReply('? Transfer failed.'); }
    }
    if (cmd === 'trade') {
        const target = interaction.options.getUser('user'), yourCard = interaction.options.getString('your_card'), theirCard = interaction.options.getString('their_card');
        if (target.id === uid) return interaction.reply({ content: '? Cannot trade with yourself.', flags: MessageFlags.Ephemeral });
        const from = findCard(yourCard), to = findCard(theirCard);
        if (!from || !to) return interaction.reply({ content: '\u274c Card not found.', flags: MessageFlags.Ephemeral });
        const fromInv = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [uid, from.name]);
        if (!fromInv) return interaction.reply({ content: `? You don't have **${from.name}**.`, flags: MessageFlags.Ephemeral });
        const toInv = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [target.id, to.name]);
        if (!toInv) return interaction.reply({ content: `? ${target.username} doesn't have **${to.name}**.`, flags: MessageFlags.Ephemeral });
        const id = Math.random().toString(36).substring(2, 10);
        await db.run('INSERT INTO trade_requests (id,fromId,toId,fromCard,toCard,status,createdAt) VALUES (?,?,?,?,?,?,?)', [id, uid, target.id, from.name, to.name, 'pending', Date.now()]);
        await interaction.reply({ content: `? Trade request created! ID: \`${id}\`\n${target.username} can accept with \`/accepttrade ${id}\` or decline.`, flags: MessageFlags.Ephemeral });
        return target.send(`?? ${interaction.user.username} wants to trade **${from.name}** for your **${to.name}**.\nUse \`/accepttrade ${id}\` to accept.`).catch(() => {});
    }
    if (cmd === 'accepttrade') {
        const tid = interaction.options.getString('id');
        const trade = await db.get('SELECT * FROM trade_requests WHERE id=? AND status="pending"', [tid]);
        if (!trade) return interaction.reply({ content: '? Trade not found or already processed.', flags: MessageFlags.Ephemeral });
        if (trade.toId !== uid) return interaction.reply({ content: '? Not your trade.', flags: MessageFlags.Ephemeral });
        await db.exec('BEGIN IMMEDIATE');
        try {
            const fromRow = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [trade.fromId, trade.fromCard]);
            if (!fromRow || fromRow.quantity < 1) throw new Error('Sender no longer has card');
            const toRow = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [trade.toId, trade.toCard]);
            if (!toRow || toRow.quantity < 1) throw new Error('Receiver no longer has card');
            if (fromRow.quantity > 1) await db.run('UPDATE inventory SET quantity=quantity-1 WHERE userId=? AND cardName=?', [trade.fromId, trade.fromCard]); else await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [trade.fromId, trade.fromCard]);
            if (toRow.quantity > 1) await db.run('UPDATE inventory SET quantity=quantity-1 WHERE userId=? AND cardName=?', [trade.toId, trade.toCard]); else await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [trade.toId, trade.toCard]);
            await db.run('INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1', [trade.toId, trade.fromCard]);
            await db.run('INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1', [trade.fromId, trade.toCard]);
            await db.run('UPDATE trade_requests SET status="completed" WHERE id=?', [tid]);
            await db.exec('COMMIT');
            await interaction.reply({ content: `? Trade completed! You received **${trade.fromCard}** and gave **${trade.toCard}**.`, flags: MessageFlags.Ephemeral });
            const fromUser = await bot.users.fetch(trade.fromId).catch(() => null);
            if (fromUser) await fromUser.send(`? ${interaction.user.username} accepted the trade. You received **${trade.toCard}** and gave **${trade.fromCard}**.`).catch(() => {});
        } catch (e) { await db.exec('ROLLBACK'); await interaction.reply({ content: `? Trade failed: ${e.message}`, flags: MessageFlags.Ephemeral }); }
        return;
    }
    if (cmd === 'declinetrade') {
        const tid = interaction.options.getString('id');
        const trade = await db.get('SELECT * FROM trade_requests WHERE id=? AND status="pending"', [tid]);
        if (!trade) return interaction.reply({ content: '? Trade not found.', flags: MessageFlags.Ephemeral });
        if (trade.toId !== uid) return interaction.reply({ content: '? Not your trade.', flags: MessageFlags.Ephemeral });
        await db.run('UPDATE trade_requests SET status="declined" WHERE id=?', [tid]);
        await interaction.reply({ content: '? Trade declined.', flags: MessageFlags.Ephemeral });
        const fromUser = await bot.users.fetch(trade.fromId).catch(() => null);
        if (fromUser) await fromUser.send(`? ${interaction.user.username} declined your trade request.`).catch(() => {});
        return;
    }
    if (cmd === 'duplicates') { const dup = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=? AND quantity>1', [uid]); if (!dup.length) return interaction.editReply('You have no duplicate cards.'); const list = dup.map(c => `- **${c.cardName}** (x${c.quantity})`).join('\n'); return interaction.editReply({ embeds: [new EmbedBuilder().setTitle('?? Your Duplicate Cards').setDescription(list).setColor(0x3498DB)] }); }
    if (cmd === 'duel') {
        const opp = interaction.options.getUser('user');
        if (opp.id === uid) return interaction.reply('? Cannot duel yourself.');
        const uCards = await db.all('SELECT cardName FROM inventory WHERE userId=?', [uid]);
        if (!uCards.length) return interaction.editReply('? You have no cards.');
        const oCards = await db.all('SELECT cardName FROM inventory WHERE userId=?', [opp.id]);
        if (!oCards.length) return interaction.editReply(`? ${opp.username} has no cards.`);
        const uOpt = uCards.slice(0, 25).map(c => ({ label: c.cardName, value: c.cardName }));
        const oOpt = oCards.slice(0, 25).map(c => ({ label: c.cardName, value: c.cardName }));
        const uSel = new StringSelectMenuBuilder().setCustomId('duel_card_select').setPlaceholder('Choose your card').addOptions(uOpt);
        const oSel = new StringSelectMenuBuilder().setCustomId('duel_card_select').setPlaceholder('Choose your card').addOptions(oOpt);
        await interaction.reply({ content: 'Choose a card:', components: [new ActionRowBuilder().addComponents(uSel)], flags: MessageFlags.Ephemeral });
        await opp.send({ content: `${opp.username}, ${interaction.user.username} challenged you to a duel! Choose a card:`, components: [new ActionRowBuilder().addComponents(oSel)] }).catch(() => interaction.followUp({ content: `? Could not DM ${opp.username}.`, flags: MessageFlags.Ephemeral }));
        if (!bot.duelData) bot.duelData = {};
        bot.duelData[uid] = { opponent: opp.id, selectedCard: null };
        bot.duelData[opp.id] = { opponent: uid, selectedCard: null };
        setTimeout(() => { if (bot.duelData[uid] && !bot.duelData[uid].selectedCard) { interaction.followUp({ content: '? Duel cancelled.', flags: MessageFlags.Ephemeral }).catch(() => {}); delete bot.duelData[uid]; delete bot.duelData[opp.id]; } }, 60000);
        return;
    }
    if (cmd === 'quiz') {
        const { quizData } = require('../games/QuizGame');
        if (quizData.length === 0) return interaction.reply({ content: '? No quiz questions available.', flags: MessageFlags.Ephemeral });
        let rounds = interaction.options.getInteger('rounds') || 10;
        if (rounds < 1) rounds = 10;
        rounds = Math.min(rounds, quizData.length);
        if (activeQuizzes.has(interaction.channel.id)) return interaction.reply({ content: '? A quiz is already active in this channel!', flags: MessageFlags.Ephemeral });
        const game = new QuizGame(interaction.channel, uid, rounds);
        activeQuizzes.set(interaction.channel.id, game);
        await interaction.reply(`?? **Ninjago Quiz started!** ${rounds} questions. Type \`/quiz stop\` or \`!quiz stop\` to cancel.\nFirst question in 3 seconds...`);
        const dummyMsg = { channel: interaction.channel, client: bot, author: interaction.user };
        setTimeout(() => game.startRound(dummyMsg), 3000);
        return;
    }
    if (cmd === 'quotequiz') {
        if (quoteData.length === 0) return interaction.reply({ content: '? No quote questions available.', flags: MessageFlags.Ephemeral });
        let rounds = interaction.options.getInteger('rounds') || 10;
        if (rounds < 1) rounds = 10;
        rounds = Math.min(rounds, quoteData.length, 20);
        if (activeQuoteQuizzes.has(interaction.channel.id)) return interaction.reply({ content: '? A quote guesser is already active in this channel!', flags: MessageFlags.Ephemeral });
        const game = new QuoteGuesserGame(interaction.channel, uid, rounds);
        activeQuoteQuizzes.set(interaction.channel.id, game);
        await interaction.reply(`?? **Quote Guesser started!** ${rounds} quotes. Type \`!quotequiz stop\` to cancel.\nFirst quote in 3 seconds...`);
        const dummyMsg = { channel: interaction.channel, client: bot, author: interaction.user };
        setTimeout(() => game.startRound(dummyMsg), 3000);
        return;
    }
    if (cmd === 'locationguesser') {
        if (activeGames.has(interaction.channel.id)) return interaction.reply({ content: '? A game is already active in this channel.', flags: MessageFlags.Ephemeral });
        try {
            const game = await createLocationGuesserGame(interaction.channel, uid);
            activeGames.set(interaction.channel.id, game);
            await interaction.reply('?? **Location Guesser started!** 10 rounds. Type `!exitgame` to stop.\nFirst location in 2 seconds...');
            setTimeout(() => game.startRound(bot), 2000);
        } catch (error) {
            await interaction.reply({ content: `❌ Could not start Location Guesser: ${error.message}`, flags: MessageFlags.Ephemeral });
        }
        return;
    }
    if (cmd === 'setguesser') {
        if (activeGames.has(interaction.channel.id)) return interaction.reply({ content: '? A game is already active in this channel.', flags: MessageFlags.Ephemeral });
        try {
            const game = await createSetGuesserGame(interaction.channel, uid);
            activeGames.set(interaction.channel.id, game);
            await interaction.reply('?? **Set Guesser started!** 10 rounds. Type `!exitgame` to stop.\nFirst set in 2 seconds...');
            setTimeout(() => game.startRound(bot), 2000);
        } catch (error) {
            await interaction.reply({ content: `❌ Could not start Set Guesser: ${error.message}`, flags: MessageFlags.Ephemeral });
        }
        return;
    }
    if (cmd === 'minifigureguesser') {
        if (activeGames.has(interaction.channel.id)) return interaction.reply({ content: '? A game is already active in this channel.', flags: MessageFlags.Ephemeral });
        try {
            const game = await createMinifigureGuesserGame(interaction.channel, uid);
            activeGames.set(interaction.channel.id, game);
            await interaction.reply('?? **Minifigure Guesser started!** 10 rounds. Type `!exitgame` to stop.\nFirst minifigure in 2 seconds...');
            setTimeout(() => game.startRound(bot), 2000);
        } catch (error) {
            await interaction.reply({ content: `❌ Could not start Minifigure Guesser: ${error.message}`, flags: MessageFlags.Ephemeral });
        }
        return;
    }
    if (cmd === 'tictactoe') {
        const opponent = interaction.options.getUser('user');
        if (!opponent || opponent.bot || opponent.id === uid) return interaction.reply({ content: 'Pick a real user other than yourself.', flags: MessageFlags.Ephemeral });
        if (activeGames.has(interaction.channel.id)) return interaction.reply({ content: '? A game is already active in this channel.', flags: MessageFlags.Ephemeral });
        const game = new TicTacToeGame(interaction.channel, interaction.user, opponent);
        activeGames.set(interaction.channel.id, game);
        return interaction.reply(game.buildStartPayload());
    }
    if (cmd === 'blackjack') {
        if (activeGames.has(interaction.channel.id)) return interaction.reply({ content: '? A game is already active in this channel.', flags: MessageFlags.Ephemeral });
        const game = new BlackjackGame(interaction.channel, interaction.user);
        activeGames.set(interaction.channel.id, game);
        return interaction.reply({ embeds: [game.buildEmbed(false)], components: game.buildRows(false) });
    }
    if (cmd === 'blacktea' || cmd === 'greentea') {
        if (!interaction.guild) return interaction.reply({ content: '? This command can only be used in a server.', flags: MessageFlags.Ephemeral });
        if (activeGames.has(interaction.channel.id)) return interaction.reply({ content: '? A game is already active in this channel.', flags: MessageFlags.Ephemeral });
        const configRow = await db.get('SELECT * FROM server_config WHERE guildId = ?', [interaction.guild.id]);
        const type = cmd === 'blacktea' ? 'black' : 'green';
        const gameConfig = { time: configRow?.tea_time || 10, language: 'en' };
        if (type === 'black') gameConfig.hp = configRow?.blacktea_hp || 2;
        else gameConfig.rounds = 10;
        const game = new TeaGame(interaction.channel, uid, type, gameConfig);
        activeGames.set(interaction.channel.id, game);
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`tea_join_${interaction.channel.id}`).setLabel('Join Game').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId(`tea_start_${interaction.channel.id}`).setLabel('Start Now').setStyle(ButtonStyle.Primary));
        await interaction.reply({ content: `?? **${type === 'black' ? 'Black' : 'Green'} Tea** game created! Click **Join Game** to participate.`, components: [row] });
        return;
    }
    if (cmd === 'teajoin') { const game = activeGames.get(interaction.channel.id); if (!game || !(game instanceof TeaGame)) return interaction.reply({ content: '? No active Tea game.', flags: MessageFlags.Ephemeral }); if (game.active) return interaction.reply({ content: '? Game already started.', flags: MessageFlags.Ephemeral }); game.addPlayer(uid, interaction.user.username); return interaction.reply(`? ${interaction.user.username} joined!`); }
    if (cmd === 'teaquit') { const game = activeGames.get(interaction.channel.id); if (!game || !(game instanceof TeaGame)) return interaction.reply({ content: '? No active Tea game.', flags: MessageFlags.Ephemeral }); game.removePlayer(uid); return interaction.reply(`?? ${interaction.user.username} left.`); }
    if (cmd === 'teastop') { const game = activeGames.get(interaction.channel.id); if (!game || !(game instanceof TeaGame)) return interaction.reply({ content: '? No active Tea game.', flags: MessageFlags.Ephemeral }); if (game.hostId !== uid && !config.authorizedAdmins.includes(uid)) return interaction.reply({ content: '? Only host/admin can stop.', flags: MessageFlags.Ephemeral }); game.stop(); return interaction.reply('?? Game stopped.'); }
    if (cmd === 'botinfo') { const totalServers = bot.guilds.cache.size, totalUsers = (await db.all('SELECT DISTINCT userId FROM inventory')).length, totalCatches = (await db.get('SELECT SUM(quantity) as total FROM inventory')).total || 0, uptime = process.uptime(); const d = Math.floor(uptime / 86400), h = Math.floor((uptime % 86400) / 3600), m = Math.floor((uptime % 3600) / 60); return interaction.reply({ embeds: [new EmbedBuilder().setTitle('?? NFC Bot Info').addFields({ name: 'Servers', value: `${totalServers}`, inline: true }, { name: 'Collectors', value: `${totalUsers}`, inline: true }, { name: 'Total Cards Caught', value: `${totalCatches}`, inline: true }, { name: 'Total Cards', value: `${TOTAL_CARDS}`, inline: true }, { name: 'Version', value: `v${BOT_VERSION}`, inline: true }, { name: 'Uptime', value: `${d}d ${h}h ${m}m`, inline: true }, { name: 'Catch Time', value: `${config.COLLECTION_TIME / 1000}s`, inline: true }).setColor(0x3498DB)] }); }
    if (cmd === 'support') return interaction.reply('?? Join support: https://discord.gg/ninjagodragonsrising');
    if (cmd === 'suggest') {
        if (!interaction.guild) return interaction.reply({ content: '? Suggestions can only be sent in a server.', flags: MessageFlags.Ephemeral });
        const text = interaction.options.getString('idea');
        const result = await submitSuggestion({ guild: interaction.guild, user: interaction.user, sourceChannel: interaction.channel, text });
        return interaction.reply(result.ok ? { content: result.message } : { content: result.message, flags: MessageFlags.Ephemeral });
    }
    if (cmd === 'topcards') { const top = await db.all('SELECT cardName, SUM(quantity) as total FROM inventory GROUP BY cardName ORDER BY total DESC LIMIT 5'); if (!top.length) return interaction.editReply('No cards collected yet.'); let desc = ''; for (let i = 0; i < top.length; i++) desc += `${i + 1}. **${top[i].cardName}** - ${top[i].total} copies\n`; return interaction.editReply({ embeds: [new EmbedBuilder().setTitle('?? Most Owned Cards').setDescription(desc).setColor(0xFFD700)] }); }
    if (cmd === 'rarest') { const rare = await db.all('SELECT cardName, SUM(quantity) as total FROM inventory GROUP BY cardName ORDER BY total ASC LIMIT 5'); if (!rare.length) return interaction.editReply('No cards collected yet.'); let desc = ''; for (let i = 0; i < rare.length; i++) desc += `${i + 1}. **${rare[i].cardName}** - ${rare[i].total} copies\n`; return interaction.editReply({ embeds: [new EmbedBuilder().setTitle('?? Rarest Cards').setDescription(desc).setColor(0xE74C3C)] }); }
    if (cmd === 'notification') { const state = interaction.options.getString('state'); await setNotification(uid, state === 'on'); return interaction.reply(`?S& Notifications ${state === 'on' ? 'enabled' : 'disabled'}.`); }
    if (['attack', 'hug', 'kill', 'slap', 'punch', 'kiss', 'highfive', 'handshake'].includes(cmd)) {
        const target = interaction.options.getUser('user');
        const gifs = { attack: 'https://tenor.com/view/jay-ninjago-ninjago-crystalized-jay-jay-ninjago-crystalized-lego-ninjago-gif-2260568897801075940', hug: 'https://tenor.com/view/ninjago-lego-ninjago-schploinky-ninjago-dragons-rising-dragons-rising-gif-1691855875669522204', kill: 'https://tenor.com/view/ras-ninjago-dragons-rising-season-3-ras-lego-ninjago-dragons-rising-season-3-ras-ninjago-dragons-rising-ras-lego-ninjago-dragons-rising-ras-lego-ninjago-gif-6105817875826362931', slap: 'https://cdn.discordapp.com/attachments/1282018169044729906/1490698848748699728/b3j7hmm.gif', punch: 'https://tenor.com/view/ninjago-cinder-ninjago-kai-punch-lego-ninjago-ninjago-dr-s2-gif-2152592207909448368', kiss: 'https://imgur.com/hj8b29L', highfive: 'https://tenor.com/view/lloyd-ninjago-lloyd-garmadon-nya-ninjago-high-five-team-gif-11354345990016101403', handshake: 'https://cdn.discordapp.com/attachments/1403761064465928312/1489992005952999574/Screen_Recording_20260404_171318_YouTube2.gif' };
        await roleplayReply(interaction, cmd, target, gifs[cmd]);
        return;
    }
    if (cmd === 'ciocnesc') { const target = interaction.options.getUser('user'), winner = Math.random() < 0.5 ? interaction.user : target; return interaction.reply({ embeds: [new EmbedBuilder().setTitle("?x?a Easter Duel!").setDescription(`**${interaction.user.username}** & **${target.username}** crack eggs...\n\nOul lui **${winner.username}** a r?r?mas ?ntreg! ?x? `).setColor(0xFFD700)] }); }
    if (cmd === 'setspawnchannel') { if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: '?R You need the `Administrator` permission.', flags: MessageFlags.Ephemeral }); const channel = interaction.options.getChannel('channel'); if (!channel || channel.type !== ChannelType.GuildText) return interaction.reply({ content: '?R Please select a valid text channel.', flags: MessageFlags.Ephemeral }); const guildId = interaction.guildId; if (!guildId) return interaction.reply({ content: '?R This command can only be used in a server.', flags: MessageFlags.Ephemeral }); await db.run('INSERT OR REPLACE INTO server_config (guildId, spawnChannelId) VALUES (?, ?)', [guildId, channel.id]); return interaction.reply({ content: `?S& Spawn channel set to ${channel}.`, flags: MessageFlags.Ephemeral }); }
    if (cmd === 'spawnconfig') { const guildId = interaction.guildId; if (!guildId) return interaction.reply({ content: '?R Server only.', flags: MessageFlags.Ephemeral }); const configRow = await db.get('SELECT spawnChannelId FROM server_config WHERE guildId = ?', [guildId]); if (!configRow || !configRow.spawnChannelId) return interaction.reply({ content: '??? No spawn channel set.', flags: MessageFlags.Ephemeral }); const channel = interaction.guild.channels.cache.get(configRow.spawnChannelId); return interaction.reply({ content: `?x? Spawn channel: ${channel ? channel.toString() : 'Unknown'}`, flags: MessageFlags.Ephemeral }); }
    if (cmd === 'setannouncementchannel') { if (!interaction.memberPermissions?.has(PermissionsBitField.Flags.Administrator)) return interaction.reply({ content: '?R You need the `Administrator` permission.', flags: MessageFlags.Ephemeral }); const channel = interaction.options.getChannel('channel'); if (!channel || channel.type !== ChannelType.GuildText) return interaction.reply({ content: '?R Please select a valid text channel.', flags: MessageFlags.Ephemeral }); const guildId = interaction.guildId; if (!guildId) return interaction.reply({ content: '?R Server only.', flags: MessageFlags.Ephemeral }); await db.run('INSERT INTO server_config (guildId, announcementChannelId) VALUES (?, ?) ON CONFLICT(guildId) DO UPDATE SET announcementChannelId = excluded.announcementChannelId', [guildId, channel.id]); return interaction.reply({ content: `?S& Announcement channel set to ${channel}.`, flags: MessageFlags.Ephemeral }); }
}

module.exports = { registerSlashCommands, handleSlashCommand, generateInventoryEmbed, buildInventoryRows, generateInventoryListEmbed, buildInventoryListRows };


