const {
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    PermissionsBitField,
    ChannelType,
    StringSelectMenuBuilder,
} = require('discord.js');

const config = require('../config');
const { getDb } = require('../database');
const { getNFCoins, addNFCoins, removeNFCoins } = require('../economy');
const {
    ninjagoCards,
    TOTAL_CARDS,
    findCard,
    isMatch,
    getRank,
    isBlacklisted,
    setNotification,
    notificationEnabled,
    parseQuotedArgs,
    log,
    userField,
    serverField,
    channelField,
    getSpawnChannel,
    sortInventoryCards,
    getProfileSettings,
    setFavoriteCard,
    setElementalPower,
    setWishlistCard,
    recordWinStreak,
    ELEMENTS,
    embedWithImage,
    hasAdminPanelAccess,
} = require('../helpers');
const { EpisodeGuesserGame, episodesData } = require('../games/EpisodeGuesser');
const { guesserBlockFilter, recordGuesserWin } = require('../games/GuesserCooldown');
const TeaGame = require('../games/TeaGame');
const { TruthDareGame, buildTruthDarePromptPayload } = require('../games/TruthDareGame');
const { startMinesGame } = require('../games/MinesGame');
const { QuizGame, quizData } = require('../games/QuizGame');
const { QuoteGuesserGame, quoteData } = require('../games/QuoteGuesser');
const TicTacToeGame = require('../games/TicTacToeGame');
const BlackjackGame = require('../games/BlackjackGame');
const { createLocationGuesserGame, createSetGuesserGame, createMinifigureGuesserGame } = require('../games/ImageGuesserGame');
const { generateInventoryEmbed, buildInventoryRows, generateInventoryListEmbed, buildInventoryListRows } = require('./slash');
const { buildShopPayload, sendLiveShopMessage, buyShopSlot } = require('../shop');
const { submitSuggestion } = require('../suggestions');
const { buildCoinsLeaderboardEmbed, buildGameLeaderboardEmbed, recordGameWin } = require('../stats');
const stringSimilarity = require('string-similarity');
const { version: BOT_VERSION } = require('../package.json');

const activeGames   = require('../index').activeGames;
const activeQuizzes = require('../index').activeQuizzes;
const activeQuoteQuizzes = require('../index').activeQuoteQuizzes;
const bot           = require('../index').bot;
const chatCooldowns = require('../index').chatCooldowns;
const pendingTrades = require('../index').pendingTrades;
const catchCount    = require('../index').catchCount;

// -----------------------------------------------------------------------------
// HELPERS
// -----------------------------------------------------------------------------

async function sendEpisodeEmbed(channel, episode, round, totalRounds) {
    return channel.send({
        embeds: [
            new EmbedBuilder()
                .setTitle(`?? Ninjago Episode Guesser - Round ${round}/${totalRounds}`)
                .setDescription(
                    `**Guess the Episode Title!**\nType your answer below.\nYou have **30 seconds**!\nSmall typos are okay.`
                )
                .setImage(episode.image)
                .setColor(0xFFD700),
        ],
    });
}

async function sendInventoryMessage(channel, user, cards, viewerId, sort = 'alpha') {
    const { embed, totalPages } = await generateInventoryEmbed(user, cards, 0, sort);
    bot.invViews.set(`${viewerId}:${user.id}`, { cards, timestamp: Date.now() });

    const msg = await channel.send({ embeds: [embed], components: buildInventoryRows(user.id, 0, totalPages, sort) });
    bot.invPages.set(msg.id, {
        userId: viewerId,
        ownerId: user.id,
        cards,
        page: 0,
        totalPages,
        sort,
        timestamp: Date.now(),
    });
    return msg;
}

async function sendInventoryList(channel, user, cards, viewerId) {
    const { embed, totalPages } = await generateInventoryListEmbed(user, cards, 0);
    const msg = await channel.send({ embeds: [embed], components: buildInventoryListRows(user.id, 0, totalPages) });
    bot.invPages.set(msg.id, {
        mode: 'invlist',
        userId: viewerId,
        ownerId: user.id,
        cards,
        page: 0,
        totalPages,
        timestamp: Date.now(),
    });
    return msg;
}

function isFullServer(guildId) {
    return config.ALLOWED_SERVER_IDS.includes(guildId);
}

function botHasAdmin(guild) {
    const me = guild.members.me;
    return me && me.permissions.has(PermissionsBitField.Flags.Administrator);
}

function parseCardList(text) {
    return text.split(',').map(part => part.trim()).filter(Boolean);
}

function formatCardBundle(cards) {
    const counts = new Map();
    for (const card of cards) counts.set(card.name, (counts.get(card.name) || 0) + (card.quantity || 1));
    return Array.from(counts.entries()).map(([name, qty]) => qty > 1 ? `**${name}** x${qty}` : `**${name}**`).join(', ');
}

function formatMissingCardsList(cards, maxLength = 1500) {
    const lines = cards.map(card => `- ${card.name}`);
    const output = [];
    let length = 0;

    for (const line of lines) {
        const nextLength = length + (output.length ? 1 : 0) + line.length;
        if (nextLength > maxLength) break;
        output.push(line);
        length = nextLength;
    }

    if (output.length < lines.length) {
        while (output.length) {
            const candidate = `${output.join('\n')}\nAnd More`;
            if (candidate.length <= maxLength) return candidate;
            output.pop();
        }
        return 'And More';
    }

    return output.join('\n');
}

async function handleCoinflip(message, args) {
    const wagerText = args[1]?.toLowerCase();
    if (!wagerText) return message.reply('Usage: `!coinflip <amount|all> [heads/tails]`');

    const balance = await getNFCoins(message.author.id);
    const wager = wagerText === 'all' ? balance : parseInt(wagerText, 10);
    const picked = args[2]?.toLowerCase();
    const choice = picked?.startsWith('h') ? 'heads' : (picked?.startsWith('t') ? 'tails' : (Math.random() < 0.5 ? 'heads' : 'tails'));

    if (!Number.isInteger(wager) || wager <= 0) return message.reply('? Bet a positive amount of NFC Coins.');
    if (wager > balance) return message.reply(`? You only have **${balance} NFC Coins**.`);

    const paid = await removeNFCoins(message.author.id, wager);
    if (!paid) return message.reply('? You do not have enough NFC Coins for that bet.');

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const won = choice === result;
    if (won) await addNFCoins(message.author.id, wager * 2);
    const newBalance = await getNFCoins(message.author.id);

    const embed = new EmbedBuilder()
        .setTitle('?? NFC Coinflip')
        .setDescription(won ? 'You won the flip.' : 'You lost the flip.')
        .addFields(
            { name: 'Your Pick', value: choice, inline: true },
            { name: 'Result', value: result, inline: true },
            { name: 'Bet', value: `${wager} NFC Coins`, inline: true },
            { name: won ? 'Won' : 'Lost', value: `${wager} NFC Coins`, inline: true },
            { name: 'Balance', value: `${newBalance} NFC Coins`, inline: true },
        )
        .setColor(won ? 0x2ECC71 : 0xE74C3C);

    return message.reply({ embeds: [embed] });
}

function normalizeTradeCards(cards) {
    const counts = new Map();
    for (const card of cards) counts.set(card.name, (counts.get(card.name) || 0) + (card.quantity || 1));
    return Array.from(counts.entries()).map(([name, qty]) => ({ name, quantity: qty }));
}

async function handleGiftCommand(m, args, targetUser) {
    const mentionedUser = m.mentions.users.first();
    const giftTarget = mentionedUser || targetUser;
    const giftText = (mentionedUser ? args.slice(2) : args.slice(1)).join(' ').trim();

    if (!giftTarget || giftTarget.id === m.author.id) return m.reply('? Reply to someone or mention a user: `!gift @user <coins|card>`');
    if (!giftText) return m.reply('? Usage: `!gift @user <coins|card>` or reply with `!gift <coins|card>`');

    if (/^\d+$/.test(giftText)) {
        const amount = parseInt(giftText, 10);
        if (!Number.isInteger(amount) || amount <= 0) return m.reply('? Gift a positive amount of NFC Coins.');
        const paid = await removeNFCoins(m.author.id, amount);
        if (!paid) {
            const balance = await getNFCoins(m.author.id);
            return m.reply(`? You only have **${balance} NFC Coins**.`);
        }
        await addNFCoins(giftTarget.id, amount);
        await log('?? Coins Gifted', config.LOG_COLORS.success, [
            { name: 'From', value: userField(m.author) },
            { name: 'To', value: userField(giftTarget) },
            { name: 'Amount', value: `${amount} NFC Coins` },
        ]);
        return m.reply(`?? Gifted **${amount} NFC Coins** to **${giftTarget.username}**!`);
    }

    const card = findCard(giftText);
    if (!card) return m.reply('\u274c Card not found.');

    const row = await getDb().get(
        'SELECT quantity FROM inventory WHERE userId=? AND cardName=?',
        [m.author.id, card.name]
    );
    if (!row) return m.reply(`? You don't have this card.`);

    await getDb().run(
        row.quantity > 1
            ? 'UPDATE inventory SET quantity=quantity-1 WHERE userId=? AND cardName=?'
            : 'DELETE FROM inventory WHERE userId=? AND cardName=?',
        [m.author.id, card.name]
    );
    await getDb().run(
        'INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1',
        [giftTarget.id, card.name]
    );
    await log('?? Card Gifted', config.LOG_COLORS.success, [
        { name: 'From', value: userField(m.author) },
        { name: 'To', value: userField(giftTarget) },
        { name: 'Card', value: card.name },
    ]);
    return m.reply(`?? Gifted **${card.name}** to **${giftTarget.username}**!`);
}

async function resolveTradeCards(userId, text, viewerId = null) {
    const parts = parseCardList(text);
    const cards = [];
    for (const part of parts) {
        let card = null;
        if (/^\d+$/.test(part)) {
            const index = parseInt(part, 10);
            const remembered = viewerId && bot.invViews?.get(`${viewerId}:${userId}`);
            if (remembered?.cards?.[index - 1]) card = findCard(remembered.cards[index - 1].cardName) || { name: remembered.cards[index - 1].cardName };
        } else {
            card = findCard(part);
        }
        if (!card) throw new Error(`Card not found: ${part}`);
        cards.push({ name: card.name, quantity: 1 });
    }
    return normalizeTradeCards(cards);
}

async function validateTradeBundle(userId, cards, username) {
    for (const card of cards) {
        const row = await getDb().get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [userId, card.name]);
        if (!row || row.quantity < card.quantity) return `${username} does not have enough ${card.name} (needs ${card.quantity}, owns ${row?.quantity || 0}).`;
    }
    return null;
}

// -----------------------------------------------------------------------------
// MAIN HANDLER
// -----------------------------------------------------------------------------

const REMOTE_CATCH_GIFS = {
    common: [
        'https://raw.githubusercontent.com/poscabro94-spec/nfc-bot-assets/main/NewCard1-ezgif.com-video-to-gif-converter.gif',
        'https://raw.githubusercontent.com/poscabro94-spec/nfc-bot-assets/main/NewCard2-ezgif.com-video-to-gif-converter.gif',
    ],
    superRare: [
        'https://raw.githubusercontent.com/poscabro94-spec/nfc-bot-assets/main/SuperRareCard1-ezgif.com-video-to-gif-converter.gif',
        'https://raw.githubusercontent.com/poscabro94-spec/nfc-bot-assets/main/SuperRareCard2-ezgif.com-video-to-gif-converter.gif',
    ],
    mythic: 'https://raw.githubusercontent.com/poscabro94-spec/nfc-bot-assets/main/NewMythicalCard-ezgif.com-video-to-gif-converter%20(1).gif',
    zantTanz: 'https://raw.githubusercontent.com/poscabro94-spec/nfc-bot-assets/main/ZantTanzElements-ezgif.com-video-to-gif-converter.gif',
    sourceDragon: 'https://raw.githubusercontent.com/poscabro94-spec/nfc-bot-assets/main/RasWithAllSources-Trim-ezgif.com-video-to-gif-converter.gif',
};

function getCatchGifUrl(card, rarity) {
    if (card.name === 'Zant Tanz') {
        return config.ZANT_TANZ_GIF;
    }
    if (/source dragon/i.test(card.name)) {
        return config.SOURCE_DRAGON_GIF;
    }
    if (rarity === 'Godly') {
        return config.MYTHIC_GIF;
    }
    if (rarity === 'Common') {
        const gifs = config.COMMON_GIFS || [];
        return gifs[Math.floor(Math.random() * gifs.length)];
    }
    if (rarity === 'Super Rare') {
        const gifs = config.SUPER_RARE_GIFS || [config.SUPER_RARE_GIF];
        return gifs[Math.floor(Math.random() * gifs.length)];
    }
    if (rarity === 'MYTHIC') {
        return config.MYTHIC_GIF;
    }
    return null;
}

function getCatchGifFallbackUrl(card, rarity) {
    if (card.name === 'Zant Tanz') return REMOTE_CATCH_GIFS.zantTanz;
    if (/source dragon/i.test(card.name)) return REMOTE_CATCH_GIFS.sourceDragon;
    if (rarity === 'Common') {
        const gifs = REMOTE_CATCH_GIFS.common;
        return gifs[Math.floor(Math.random() * gifs.length)];
    }
    if (rarity === 'Super Rare') {
        const gifs = REMOTE_CATCH_GIFS.superRare;
        return gifs[Math.floor(Math.random() * gifs.length)];
    }
    if (rarity === 'Godly' || rarity === 'MYTHIC') return REMOTE_CATCH_GIFS.mythic;
    return null;
}

function buildCatchReplyPayload(embed, card, rarity) {
    const gifPath = getCatchGifUrl(card, rarity);
    if (gifPath && typeof gifPath === 'string' && !/^https?:\/\//i.test(gifPath)) {
        try {
            const stat = require('fs').statSync(gifPath);
            if (stat.size > 8 * 1024 * 1024) {
                return embedWithImage(embed, getCatchGifFallbackUrl(card, rarity), 'setImage');
            }
        } catch (e) {
            return embedWithImage(embed, getCatchGifFallbackUrl(card, rarity), 'setImage');
        }
    }
    return embedWithImage(embed, gifPath, 'setImage');
}

function buildEpisodeGameOverEmbed(game) {
    const winner = game.getWinner();
    const rows = Array.from(game.scores.entries())
        .sort((a, b) => b[1].score - a[1].score)
        .map(([_, data], index) => `${index + 1}. **${data.username}** - ${data.score} points`);

    return new EmbedBuilder()
        .setTitle('?? Episode Guesser Results')
        .setColor(0xFFD700)
        .addFields(
            { name: 'Winner', value: winner ? `**${winner.username}** with **${winner.score}** points` : 'No winner', inline: false },
            { name: 'Leaderboard', value: rows.length ? rows.join('\n') : 'No points scored.', inline: false },
        )
        .setTimestamp();
}

function parseGameLeaderboardInput(input) {
    return String(input || '').trim().toLowerCase();
}

const fastCardCatchState = new Map();
const channelCardCatchStreaks = new Map();
const FAST_CATCH_MS = 3000;
const FAST_CATCH_STREAK_LIMIT = 2;
const CHANNEL_CATCH_STREAK_LIMIT = 5;
const CARD_CATCH_BLOCK_MS = 5 * 60 * 1000;

function formatRemainingTime(ms) {
    const totalSeconds = Math.max(1, Math.ceil(ms / 1000));
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;
    if (minutes <= 0) return `${seconds}s`;
    return `${minutes}m ${seconds}s`;
}

function getCardCatchBlockRemaining(userId) {
    const state = fastCardCatchState.get(userId);
    if (!state?.blockedUntil) return 0;
    const remaining = state.blockedUntil - Date.now();
    if (remaining <= 0) {
        fastCardCatchState.delete(userId);
        return 0;
    }
    return remaining;
}

function cardCatchFilter(msg, cardName) {
    if (!isMatch(msg.content, cardName)) return false;
    const remaining = getCardCatchBlockRemaining(msg.author.id);
    if (remaining > 0) {
        msg.reply(`? You are catching cards too fast. Try again in **${formatRemainingTime(remaining)}**.`).catch(() => {});
        return false;
    }
    return true;
}

async function trackFastCardCatch(msg, respTime) {
    const userId = msg.author.id;
    const current = fastCardCatchState.get(userId) || { streak: 0, blockedUntil: 0 };
    current.streak = respTime < FAST_CATCH_MS ? current.streak + 1 : 0;

    if (current.streak >= FAST_CATCH_STREAK_LIMIT) {
        current.streak = 0;
        current.blockedUntil = Date.now() + CARD_CATCH_BLOCK_MS;
        await msg.reply(`?? Fast catch warning **2/2**. You are blocked from catching cards for **5 minutes**.`).catch(() => {});
        await msg.author.send(
            `?? Fast catch warning **2/2**. You are catching cards really fast, which might look like cheating. ` +
            `You are blocked from catching cards for **5 minutes**. Please slow down and let other players get some cards too.`
        ).catch(() => {});
    } else if (current.streak > 0) {
        await msg.reply(`?? Fast catch warning **${current.streak}/${FAST_CATCH_STREAK_LIMIT}**. Slow down or you will be blocked from catching cards for 5 minutes.`).catch(() => {});
    }

    fastCardCatchState.set(userId, current);
}

async function trackChannelCardCatchStreak(msg) {
    const channelId = msg.channel.id;
    const userId = msg.author.id;
    const current = channelCardCatchStreaks.get(channelId);
    const next = current?.userId === userId
        ? { userId, count: current.count + 1 }
        : { userId, count: 1 };

    if (next.count >= CHANNEL_CATCH_STREAK_LIMIT) {
        next.count = 0;
        const userState = fastCardCatchState.get(userId) || { streak: 0, blockedUntil: 0 };
        userState.blockedUntil = Date.now() + CARD_CATCH_BLOCK_MS;
        userState.streak = 0;
        fastCardCatchState.set(userId, userState);
        await msg.author.send(
            `?? You caught **${CHANNEL_CATCH_STREAK_LIMIT} cards in a row** in the same channel. ` +
            `You are blocked from catching cards for **5 minutes** so other players can get some too.`
        ).catch(() => {});
    }

    channelCardCatchStreaks.set(channelId, next);
}

async function sendCatchableCardSpawn(message, channel, card, label = '') {
    const db = getDb();
    const rarity = card.rarity || 'Common';
    const rName = rarity;
    const spawnEmbed = new EmbedBuilder()
        .setTitle(rarity === 'Godly' ? '?? A GODLY CARD APPEARED!' : (rarity === 'MYTHIC' ? '?? THE CREATOR ARRIVED!' : '? NEW CARD!'))
        .setDescription(`${label ? `**${label}**\n` : ''}A **${rName}** card has appeared! Type the name to catch it! (${config.COLLECTION_TIME / 1000} seconds)`)
        .setColor(rarity === 'Godly' ? 0xFF5A36 : (rarity === 'MYTHIC' ? 0xFFFFFF : (rarity === 'Super Rare' ? 0xFFD700 : 0xDAA520)));

    const spawnTime = Date.now();
    const mainMsg = await channel.send(embedWithImage(spawnEmbed, card.image));
    const collector = channel.createMessageCollector({
        filter: msg => cardCatchFilter(msg, card.name),
        time: config.COLLECTION_TIME,
        max: 1,
    });

    collector.on('collect', async msg => {
        try {
            const respTime = Date.now() - spawnTime;
            await trackFastCardCatch(msg, respTime);
            await trackChannelCardCatchStreak(msg);
            catchCount[msg.author.id] = (catchCount[msg.author.id] || 0) + 1;
            const catchStreak = await recordWinStreak('card_catch', msg.author.id);
            await log('?? Card Caught', config.LOG_COLORS.success, [
                { name: 'User', value: userField(msg.author) },
                { name: 'Card', value: card.name },
                { name: 'Rarity', value: rName },
                { name: 'Win Streak', value: `${catchStreak}`, inline: true },
                { name: 'Response Time', value: `${respTime}ms` },
            ]);
            await db.run('INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1', [msg.author.id, card.name]);
            await db.run('INSERT INTO catches (userId,cardName,guildId,timestamp) VALUES (?,?,?,?)', [msg.author.id, card.name, message.guild.id, Date.now()]);

            const coinReward = rarity === 'Godly' ? 500 : (rarity === 'MYTHIC' ? 200 : (rarity === 'Super Rare' ? 50 : 10));
            await addNFCoins(msg.author.id, coinReward);

            const catchEmbed = new EmbedBuilder()
                .setDescription(`**${msg.author.username}** caught **${card.name}**!\n+${coinReward} NFC Coins`)
                .setColor(rarity === 'Godly' ? 0xFF5A36 : (rarity === 'MYTHIC' ? 0xFFFFFF : (rarity === 'Super Rare' ? 0xFFD700 : 0x00AE86)));
            await msg.reply(buildCatchReplyPayload(catchEmbed, card, rarity));
        } catch (err) {
            console.error('Collector error:', err);
            require('fs').appendFileSync('crash.log', `[${new Date().toISOString()}] TEST COLLECTOR ERROR: ${err.stack}\n`);
        }
    });

    collector.on('end', async (collected, reason) => {
        if (reason === 'time' && collected.size === 0) {
            const fledEmbed = EmbedBuilder.from(spawnEmbed)
                .setTitle('?? FLED...')
                .setDescription(`Too slow! The **${rName}** card was **${card.name}**.`)
                .setColor(0xFF0000);
            mainMsg.edit({ embeds: [fledEmbed] }).catch(() => {});
        }
    });
}

async function handlePrefixMessage(m) {
    try {
        if (m.author.bot) return;

        const db = getDb();
        if (await isBlacklisted(m.author.id)) return;

        const isDM      = !m.guild;
        const full      = isDM ? true : isFullServer(m.guild.id);
        const cont      = m.content.toLowerCase().trim();
        const args      = m.content.split(' ');
        const prefixCmd = args[0]?.toLowerCase();
        const mention   = m.mentions.users.first();
        const repliedUser = m.reference?.messageId
            ? (await m.fetchReference().then(msg => msg.author).catch(() => null))
            : null;
        const target    = mention || repliedUser || m.author;

        if (cont.startsWith('!setfavorite') || cont.startsWith('!setfav')) {
            const cardName = args.slice(1).join(' ');
            if (!cardName) return m.reply('? Usage: `!setfavorite Card Name`');
            const card = findCard(cardName);
            if (!card) return m.reply('\u274c Card not found.');
            const row = await db.get('SELECT quantity FROM inventory WHERE userId=? AND cardName=?', [m.author.id, card.name]);
            if (!row) return m.reply(`? You need to own **${card.name}** before making it your favorite.`);
            await setFavoriteCard(m.author.id, card.name);
            return m.reply(`? Favorite card set to **${card.name}**.`);
        }

        if (cont.startsWith('!setelement')) {
            const picked = args.slice(1).join(' ').trim();
            const element = ELEMENTS.find(e => e.toLowerCase() === picked.toLowerCase());
            if (!element) return m.reply(`? Usage: \`!setelement ${ELEMENTS[0]}\`\nPick one of: ${ELEMENTS.join(', ')}`);
            await setElementalPower(m.author.id, element);
            return m.reply(`? Elemental power set to **${element}**.`);
        }

        if (cont.startsWith('!wishlist')) {
            const picked = args.slice(1).join(' ').trim();
            if (!picked) {
                const settings = await getProfileSettings(m.author.id);
                if (settings.wishlistCard === '__LEFT__') return m.reply('?? Your wishlist is set to **left** mode. I will DM you when any card you are missing spawns.');
                return m.reply(settings.wishlistCard ? `?? Your wishlist card is **${settings.wishlistCard}**.` : '?? You have no wishlist card set. Use `!wishlist Card Name`.');
            }
            if (picked.toLowerCase() === 'clear') {
                await setWishlistCard(m.author.id, null);
                return m.reply('? Wishlist cleared.');
            }
            if (picked.toLowerCase() === 'left') {
                await setWishlistCard(m.author.id, '__LEFT__');
                return m.reply('? Wishlist set to **left** mode. I will DM you for every missing card that spawns.');
            }
            const card = findCard(picked);
            if (!card) return m.reply('\u274c Card not found.');
            await setWishlistCard(m.author.id, card.name);
            return m.reply(`? Wishlist card set to **${card.name}**.`);
        }

        // ---------------------------------------------------------------------
        // DM COMMANDS
        // ---------------------------------------------------------------------

        if (isDM) {
            if (cont === '!help' || cont === '!userhelp') {
                const embed = new EmbedBuilder()
                    .setTitle('?? NFC Bot - DM Commands')
                    .setColor(0x00AE86)
                    .addFields(
                        { name: '?? Collection', value: '`!inventory [@user]`, reply `!inv`, `!invlist [@user]`, `!profile [@user]`, `!setfavorite <card>`, `!setelement <power>`, `!wishlist <card|left|clear>`, `!cardscount [@user]`, `!cardsleft [@user]`, `!cardsearch`, `!topcards`, `!rarest`' },
                        { name: '?? Leaderboards',   value: '`!lb`, `!serverlb`, `!coinslb`, `!gamelb <episode|quote|quiz|blacktea|greentea|location|set|minifigure|tictactoe|blackjack>`' },
                        { name: '?? Trading & Gifting', value: '`!gift @user <coins|card>`, reply `!gift <coins|card>`, `!trade @user "Card 1, Card 2" "Their Card"`, `!checktrade @user`, `!transferall @user`, `!duplicates`' },
                        { name: '?? Games',           value: '`!duel @user`, `!quiz`, `!quotequiz`, `!epguesser`, `!locationguesser`, `!setguesser`, `!minifigureguesser`, `!truth`, `!dare`, `!random`, `!tod`' },
                        { name: '?? Tea Games',       value: '`!blacktea`, `!greentea` (10 rounds), `!teajoin`, `!teaquit`, `!teastop`' },
                        { name: '?? Economy',         value: '`!balance [@user]`, reply `!balance`, `!shop`, `!buy <slot>`, `!daily`, `!bonus`, `!coinflip <amount|all> [heads/tails]`, `!mines <bet|max 50000> [mines]`' },
                        { name: '?? Fair Play',       value: 'Card catches under **3s** give fast-catch warnings. **2/2** = 5 minute catch block.' },
                        { name: '?? Notifications',   value: '`!notification on/off`' },
                        { name: '?? Admin',            value: '`/admin` control panel for bot admins and staff role' },
                        { name: '?? Info',            value: '`!ping`, `!botinfo`, `!support`, `!suggest <idea>`' }
                    )
                    .setFooter({ text: 'All commands work in DMs!' });
                return m.reply({ embeds: [embed] });
            }

            if (cont === '!ping') {
                const sent = await m.reply('?? Pinging...');
                return sent.edit(
                    `?? Pong! Latency: ${sent.createdTimestamp - m.createdTimestamp}ms\n?? WebSocket: ${bot.ws.ping}ms`
                );
            }

            if (cont === '!botinfo') {
                const servers  = bot.guilds.cache.size;
                const users    = (await db.all('SELECT DISTINCT userId FROM inventory')).length;
                const catches  = (await db.get('SELECT SUM(quantity) as total FROM inventory')).total || 0;
                const upt      = process.uptime();
                return m.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle('?? NFC Bot Info')
                            .addFields(
                                { name: 'Servers',          value: `${servers}`,   inline: true },
                                { name: 'Collectors',       value: `${users}`,     inline: true },
                                { name: 'Total Cards Caught', value: `${catches}`, inline: true },
                                { name: 'Total Cards',        value: `${TOTAL_CARDS}`, inline: true },
                                { name: 'Uptime',           value: `${Math.floor(upt / 86400)}d ${Math.floor((upt % 86400) / 3600)}h ${Math.floor((upt % 3600) / 60)}m`, inline: true },
                                { name: 'Catch Time',       value: `${config.COLLECTION_TIME / 1000}s`, inline: true }
                            )
                            .setColor(0x3498DB),
                    ],
                });
            }

            if (cont === '!support') return m.reply('?? Join support: https://discord.gg/ninjagodragonsrising');
            if (cont.startsWith('!suggest')) {
                if (!m.guild) return m.reply('? Suggestions can only be sent in a server.');
                const text = m.content.slice(args[0].length).trim();
                if (!text) return m.reply('? Usage: `!suggest your idea here`');
                const result = await submitSuggestion({ guild: m.guild, user: m.author, sourceChannel: m.channel, text });
                return m.reply(result.message);
            }
            
            if (prefixCmd === '!balance') {
                const coins = await getNFCoins(target.id);
                return m.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(`?? ${target.username}'s NFC Coins Balance`)
                            .setDescription(target.id === m.author.id ? `You have **${coins} NFC Coins**.` : `**${target.username}** has **${coins} NFC Coins**.`)
                            .setColor(0xFFD700),
                    ],
                });
            }

            if (cont === '!shop') return sendLiveShopMessage(payload => m.reply(payload));
            if (cont.startsWith('!coinflip')) return handleCoinflip(m, args);
            if (cont.startsWith('!mines')) return startMinesGame(m, args);
            if (cont.startsWith('!buy')) {
                const itemId = parseInt(args[1]);
                if (isNaN(itemId)) return m.reply('? Usage: `!buy <slot>`');
                const result = await buyShopSlot(m.author.id, itemId);
                return m.reply(result.message);
            }
            if (cont === '!daily') {
                const r   = await db.get('SELECT lastDaily FROM daily WHERE userId=?', [m.author.id]);
                const now = Date.now();
                if (r && now - r.lastDaily < 86400000)
                    return m.reply(`? Come back in ${Math.ceil((86400000 - (now - r.lastDaily)) / 3600000)} hours.`);

                const commonCards = ninjagoCards.filter(c => (c.rarity || 'Common') === 'Common');
                const card = commonCards[Math.floor(Math.random() * commonCards.length)];
                await db.run(
                    'INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1',
                    [m.author.id, card.name]
                );
                await db.run(
                    'INSERT OR REPLACE INTO daily (userId,lastDaily,lastBonus) VALUES (?,?,COALESCE((SELECT lastBonus FROM daily WHERE userId=?),0))',
                    [m.author.id, now, m.author.id]
                );
                await addNFCoins(m.author.id, 50);
                return m.reply(`?? You received **${card.name}** and **50 NFC Coins**!`);
            }

            if (cont === '!bonus') {
                const r   = await db.get('SELECT lastBonus FROM daily WHERE userId=?', [m.author.id]);
                const now = Date.now();
                if (r && now - r.lastBonus < 604800000)
                    return m.reply(`? Weekly bonus in ${Math.ceil((604800000 - (now - r.lastBonus)) / 86400000)} days.`);

                const superRareCards = ninjagoCards.filter(c => c.rarity === 'Super Rare');
                const card = superRareCards[Math.floor(Math.random() * superRareCards.length)];
                await db.run(
                    'INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1',
                    [m.author.id, card.name]
                );
                await db.run(
                    'INSERT OR REPLACE INTO daily (userId,lastDaily,lastBonus) VALUES (?,COALESCE((SELECT lastDaily FROM daily WHERE userId=?),0),?)',
                    [m.author.id, m.author.id, now]
                );
                await addNFCoins(m.author.id, 200);
                return m.reply(`? **Weekly Bonus!** You received **${card.name}** and **200 NFC Coins**! ?`);
            }

            if ((prefixCmd === '!inventory' || prefixCmd === '!inv') && prefixCmd !== '!invlist') {
                const cards = await db.all(
                    'SELECT cardName,quantity FROM inventory WHERE userId=? ORDER BY cardName ASC',
                    [target.id]
                );
                if (!cards.length) return m.reply(target.id === m.author.id ? 'Your inventory is empty!' : `${target.username}'s inventory is empty!`);
                return sendInventoryMessage(m.channel, target, cards, m.author.id);
            }

            if (prefixCmd === '!profile') {
                const unique = (await db.get('SELECT COUNT(*) as c FROM inventory WHERE userId=?', [target.id])).c || 0;
                const total  = (await db.get('SELECT SUM(quantity) as t FROM inventory WHERE userId=?', [target.id])).t || 0;
                const cards  = await db.all('SELECT cardName FROM inventory WHERE userId=?', [target.id]);
                const settings = await getProfileSettings(target.id);
                const fav      = settings.favoriteCard || (cards.length ? cards[Math.floor(Math.random() * cards.length)].cardName : 'None');
                const element  = settings.elementalPower || 'Unset';
                const wishlist = settings.wishlistCard === '__LEFT__' ? 'Left Mode' : (settings.wishlistCard || 'Unset');
                const coins    = await getNFCoins(target.id);
                return m.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(`?? ${target.username}'s Profile`)
                            .setThumbnail(target.displayAvatarURL())
                            .addFields(
                                { name: 'Unique Cards',     value: `${unique}/${TOTAL_CARDS}`, inline: true },
                                { name: 'Total Catches',    value: `${total}`,                 inline: true },
                                { name: 'NFC Coins',        value: `${coins}`,                 inline: true },
                                { name: 'Rank',             value: getRank(unique),             inline: false },
                                { name: 'Favorite Card',    value: fav,                         inline: true },
                                { name: 'Elemental Power',  value: element,                     inline: true },
                                { name: 'Wishlist',         value: wishlist,                    inline: true }
                            )
                            .setColor(0x00AE86),
                    ],
                });
            }

            if (cont.startsWith('!gift')) return handleGiftCommand(m, args, target);

            if (prefixCmd === '!checktrade' || prefixCmd === '!checktrades') {
                const tradeTarget = mention || repliedUser;
                if (!tradeTarget) return m.reply('? Tag someone or reply to their message: `!checktrade @user`');

                const my    = new Set((await db.all('SELECT cardName FROM inventory WHERE userId=?', [m.author.id])).map(c => c.cardName));
                const their = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=?', [tradeTarget.id]);
                const matches = their.filter(c => !my.has(c.cardName));
                const list    = matches.map(c => `- **${c.cardName}**${c.quantity > 1 ? ` (x${c.quantity})` : ''}`).join('\n').substring(0, 1500);

                return m.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(`?? Trades with ${tradeTarget.username}`)
                            .setDescription(list || 'No new cards found.')
                            .setColor(0x2ECC71),
                    ],
                });
            }

            if (cont.startsWith('!transferall')) {
                const targetUser = m.mentions.users.first();
                if (!targetUser) return m.reply('?? Mention a user: `!transferall @user`');
                if (targetUser.id === m.author.id) return m.reply('? Cannot transfer to yourself.');

                const cards = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=?', [m.author.id]);
                if (!cards.length) return m.reply('?? Your inventory is empty.');

                await db.exec('BEGIN IMMEDIATE');
                try {
                    for (const c of cards) {
                        await db.run(
                            'INSERT INTO inventory (userId,cardName,quantity) VALUES (?,?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+?',
                            [targetUser.id, c.cardName, c.quantity, c.quantity]
                        );
                        await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [m.author.id, c.cardName]);
                    }
                    await db.exec('COMMIT');
                    return m.reply(`?? Transferred **${cards.length}** unique cards to **${targetUser.username}**!`);
                } catch (e) {
                    await db.exec('ROLLBACK');
                    return m.reply('? Transfer failed.');
                }
            }

            if (cont === '!lb') {
                const top = await db.all('SELECT userId,SUM(quantity) as total FROM inventory GROUP BY userId ORDER BY total DESC LIMIT 10');
                let desc = '';
                for (let i = 0; i < top.length; i++) {
                    const u = await bot.users.fetch(top[i].userId).catch(() => null);
                    desc += `${i + 1}. **${u ? u.username : 'Unknown'}** - ${top[i].total} cards\n`;
                }
                const userTotal = (await db.get('SELECT SUM(quantity) as total FROM inventory WHERE userId=?', [m.author.id])).total || 0;
                let rank = 'N/A';
                if (userTotal > 0)
                    rank = (await db.get(
                        'SELECT COUNT(*)+1 as r FROM (SELECT userId,SUM(quantity) as total FROM inventory GROUP BY userId HAVING total>?)',
                        [userTotal]
                    )).r || '?';
                desc += `\n????????????????\n??? **Your rank:** #${rank} (${userTotal} cards)`;
                return m.reply({
                    embeds: [new EmbedBuilder().setTitle('?? Global Leaderboard').setDescription(desc).setColor(0xFFD700)],
                });
            }

            if (prefixCmd === '!cardscount' || prefixCmd === '!count') {
                const u = (await db.get('SELECT COUNT(*) as c FROM inventory WHERE userId=?', [target.id])).c || 0;
                return m.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(`?? Progress: ${target.username}`)
                            .setColor(0x3498DB)
                            .addFields(
                                { name: 'Cards', value: `**${u}** / ${TOTAL_CARDS}`, inline: true },
                                { name: 'Rank',  value: `**${getRank(u)}**`,          inline: true }
                            ),
                    ],
                });
            }

            if (prefixCmd === '!cardsleft' || prefixCmd === '!left') {
                const owned   = new Set((await db.all('SELECT cardName FROM inventory WHERE userId=?', [target.id])).map(c => c.cardName));
                const missing = ninjagoCards.filter(c => !owned.has(c.name));
                if (!missing.length) return m.reply('?? All cards collected!');
                const list = formatMissingCardsList(missing);
                return m.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle('?? Missing Cards')
                            .setDescription(`Missing **${missing.length}** cards:\n\n${list}`)
                            .setColor(0xE74C3C),
                    ],
                });
            }

            if (cont === '!notification on')  { await setNotification(m.author.id, true);  return m.reply('? DM notifications enabled.'); }
            if (cont === '!notification off') { await setNotification(m.author.id, false); return m.reply('? DM notifications disabled.'); }

            if (cont.startsWith('!quiz')) {
                const qargs = cont.split(' ');

                if (qargs[1] === 'stop') {
                    const qz = activeQuizzes.get(m.channel.id);
                    if (!qz) return m.reply('? No active quiz.');
                    qz.stop();
                    activeQuizzes.delete(m.channel.id);
                    return m.reply(`?? Quiz stopped.\n?? Final leaderboard:\n${qz.getLeaderboard().join('\n')}`);
                }

                if (quizData.length === 0) return m.reply('? No quiz questions available.');

                let rounds = parseInt(qargs[1]) || 10;
                if (isNaN(rounds) || rounds < 1) rounds = 10;
                rounds = Math.min(rounds, quizData.length);

                if (activeQuizzes.has(m.channel.id)) return m.reply('? A quiz is already active!');

                const game = new QuizGame(m.channel, m.author.id, rounds);
                activeQuizzes.set(m.channel.id, game);
                await m.reply(`?? **Ninjago Quiz started!** ${rounds} questions. Type \`!quiz stop\` to cancel.\nFirst question in 3 seconds...`);
                setTimeout(() => game.startRound(m), 3000);
                return;
            }

            if (cont.startsWith('!quotequiz')) {
                const qargs = cont.split(' ');
                if (qargs[1] === 'stop') {
                    const game = activeQuoteQuizzes.get(m.channel.id);
                    if (!game) return m.reply('? No active quote guesser.');
                    game.stop();
                    activeQuoteQuizzes.delete(m.channel.id);
                    return m.reply(`?? Quote Guesser stopped.\n?? Final leaderboard:\n${game.getLeaderboard().join('\n')}`);
                }
                if (quoteData.length === 0) return m.reply('? No quote questions available.');
                let rounds = parseInt(qargs[1]) || 10;
                if (isNaN(rounds) || rounds < 1) rounds = 10;
                rounds = Math.min(rounds, quoteData.length, 20);
                if (activeQuoteQuizzes.has(m.channel.id)) return m.reply('? A quote guesser is already active!');
                const game = new QuoteGuesserGame(m.channel, m.author.id, rounds);
                activeQuoteQuizzes.set(m.channel.id, game);
                await m.reply('?? **Quote Guesser started!** ' + rounds + ' quotes. Type !quotequiz stop to cancel.\nFirst quote in 3 seconds...');
                setTimeout(() => game.startRound(m), 3000);
                return;
            }

            return; // end of DM block
        }

        // ---------------------------------------------------------------------
        // GUILD MESSAGES
        // ---------------------------------------------------------------------

        const spawnChannel = await getSpawnChannel(m.guild);

        // Award coins for chatting in spawn channel (60s cooldown)
        if (spawnChannel && m.channel.id === spawnChannel.id) {
            const now      = Date.now();
            const cooldown = chatCooldowns.get(m.author.id) || 0;
            if (now - cooldown > 60000) {
                await addNFCoins(m.author.id, 5);
                chatCooldowns.set(m.author.id, now);
            }
        }

        // Guard: bot needs Administrator to run most commands
        if (cont.startsWith('!') && !botHasAdmin(m.guild)) {
            const allowed = ['!help', '!ping', '!support', '!botinfo'];
            if (!allowed.includes(cont.split(' ')[0]))
                return m.reply('? **This bot requires the `Administrator` permission to function.**\nPlease grant it and try again.');
        }

        // Guard: economy commands are NFC-only
        const economyCommands = ['!balance', '!shop', '!buy', '!daily', '!bonus', '!coinflip', '!mines'];
        if (economyCommands.includes(cont.split(' ')[0]) && !full)
            return m.reply('? Economy features are only available in NFC.');

        // Guard: full-server-only commands
        const fullOnlyPrefixes = [
            '!blacktea','!greentea','!teajoin','!teaquit','!teastop',
            '!attack','!hug','!kill','!slap','!punch',
            '!kiss','!highfive','!handshake','!ciocnesc',
            '!epguesser','!duel','!trade','!duplicates','!quiz','!quotequiz','!tod','!truth','!dare','!random',
            '!locationguesser','!locguesser','!setguesser','!minifigureguesser','!minifigguesser',
            '!tictactoe','!ttt','!blackjack',
        ];
        if (fullOnlyPrefixes.some(p => cont.startsWith(p)) && !full)
            return m.reply('? This command is only available in NFC.');

        // -- Admin / Config ----------------------------------------------------

        if (cont.startsWith('!setspawnchannel')) {
            if (!m.member.permissions.has(PermissionsBitField.Flags.Administrator))
                return m.reply('? You need the `Administrator` permission.');
            const channel = m.mentions.channels.first() || m.guild.channels.cache.get(args[1]);
            if (!channel || channel.type !== ChannelType.GuildText)
                return m.reply('? Please mention a valid text channel.');
            await db.run(
                'INSERT OR REPLACE INTO server_config (guildId, spawnChannelId) VALUES (?, ?)',
                [m.guild.id, channel.id]
            );
            return m.reply(`? Spawn channel set to ${channel}.`);
        }

        if (cont === '!spawnconfig') {
            const configRow = await db.get('SELECT spawnChannelId FROM server_config WHERE guildId = ?', [m.guild.id]);
            if (!configRow || !configRow.spawnChannelId) return m.reply('?? No spawn channel set.');
            const channel = m.guild.channels.cache.get(configRow.spawnChannelId);
            return m.reply(`?x? Spawn channel: ${channel ? channel.toString() : 'Unknown'}`);
        }

        if (cont.startsWith('!setannouncementchannel')) {
            if (!m.member.permissions.has(PermissionsBitField.Flags.Administrator))
                return m.reply('? You need the `Administrator` permission.');
            const channel = m.mentions.channels.first() || m.guild.channels.cache.get(args[1]);
            if (!channel || channel.type !== ChannelType.GuildText)
                return m.reply('? Please mention a valid text channel.');
            await db.run(
                'INSERT INTO server_config (guildId, announcementChannelId) VALUES (?, ?) ON CONFLICT(guildId) DO UPDATE SET announcementChannelId = excluded.announcementChannelId',
                [m.guild.id, channel.id]
            );
            return m.reply(`? Announcement channel set to ${channel}.`);
        }

        // -- Economy -----------------------------------------------------------

        if (cont === '!shop') return sendLiveShopMessage(payload => m.reply(payload));
        if (cont.startsWith('!coinflip')) return handleCoinflip(m, args);
        if (cont.startsWith('!mines')) return startMinesGame(m, args);
        if (cont.startsWith('!buy')) {
            const itemId = parseInt(args[1]);
            if (isNaN(itemId)) return m.reply('? Usage: `!buy <slot>`');
            const result = await buyShopSlot(m.author.id, itemId);
            return m.reply(result.message);
        }
        if (cont === '!daily') {
            const r   = await db.get('SELECT lastDaily FROM daily WHERE userId=?', [m.author.id]);
            const now = Date.now();
            if (r && now - r.lastDaily < 86400000)
                return m.reply(`? Come back in ${Math.ceil((86400000 - (now - r.lastDaily)) / 3600000)} hours.`);

            const commonCards = ninjagoCards.filter(c => (c.rarity || 'Common') === 'Common');
            const card = commonCards[Math.floor(Math.random() * commonCards.length)];
            await db.run(
                'INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1',
                [m.author.id, card.name]
            );
            await db.run(
                'INSERT OR REPLACE INTO daily (userId,lastDaily,lastBonus) VALUES (?,?,COALESCE((SELECT lastBonus FROM daily WHERE userId=?),0))',
                [m.author.id, now, m.author.id]
            );
            await addNFCoins(m.author.id, 50);
            return m.reply(`?? You received a daily card: **${card.name}** and **50 NFC Coins**!`);
        }

        if (cont === '!bonus') {
            const r   = await db.get('SELECT lastBonus FROM daily WHERE userId=?', [m.author.id]);
            const now = Date.now();
            if (r && now - r.lastBonus < 604800000)
                return m.reply(`? Weekly bonus in ${Math.ceil((604800000 - (now - r.lastBonus)) / 86400000)} days.`);

            const superRareCards = ninjagoCards.filter(c => c.rarity === 'Super Rare');
            const card = superRareCards[Math.floor(Math.random() * superRareCards.length)];
            await db.run(
                'INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1',
                [m.author.id, card.name]
            );
            await db.run(
                'INSERT OR REPLACE INTO daily (userId,lastDaily,lastBonus) VALUES (?,COALESCE((SELECT lastDaily FROM daily WHERE userId=?),0),?)',
                [m.author.id, m.author.id, now]
            );
            await addNFCoins(m.author.id, 200);
            return m.reply(`? **Weekly Bonus!** You received a Super Rare card: **${card.name}** and **200 NFC Coins**! ?`);
        }

        // -- Tea Games ---------------------------------------------------------

        if (cont === '!blacktea' || cont === '!greentea') {
            if (activeGames.has(m.channel.id)) return m.reply('? A game is already active in this channel.');

            const configRow  = await db.get('SELECT * FROM server_config WHERE guildId = ?', [m.guild.id]);
            const type       = cont === '!blacktea' ? 'black' : 'green';
            const gameConfig = { time: configRow?.tea_time || 10, language: 'en' };

            if (type === 'black') gameConfig.hp  = configRow?.blacktea_hp  || 2;
            else                  gameConfig.rounds = 10;

            const game = new TeaGame(m.channel, m.author.id, type, gameConfig);
            activeGames.set(m.channel.id, game);

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`tea_join_${m.channel.id}`).setLabel('Join Game').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId(`tea_start_${m.channel.id}`).setLabel('Start Now').setStyle(ButtonStyle.Primary)
            );
            await m.reply({
                content: `?? **${type === 'black' ? 'Black' : 'Green'} Tea** game created! Click **Join Game** to participate.`,
                components: [row],
            });
            return;
        }

        if (cont === '!teajoin') {
            const game = activeGames.get(m.channel.id);
            if (!game || !(game instanceof TeaGame)) return m.reply('? No active Tea game.');
            if (game.active) return m.reply('? Game already started.');
            game.addPlayer(m.author.id, m.author.username);
            return m.reply(`? ${m.author.username} joined!`);
        }

        if (cont === '!teaquit') {
            const game = activeGames.get(m.channel.id);
            if (!game || !(game instanceof TeaGame)) return m.reply('? No active Tea game.');
            game.removePlayer(m.author.id);
            return m.reply(`?? ${m.author.username} left.`);
        }

        if (cont === '!teastop') {
            const game = activeGames.get(m.channel.id);
            if (!game || !(game instanceof TeaGame)) return m.reply('? No active Tea game.');
            if (game.hostId !== m.author.id && !config.authorizedAdmins.includes(m.author.id))
                return m.reply('? Only host/admin can stop.');
            game.stop();
            return m.reply('?? Game stopped.');
        }

        // -- Quiz --------------------------------------------------------------

        if (cont.startsWith('!quiz')) {
            const qargs = cont.split(' ');

            if (qargs[1] === 'stop') {
                const qz = activeQuizzes.get(m.channel.id);
                if (!qz) return m.reply('? No active quiz.');
                qz.stop();
                activeQuizzes.delete(m.channel.id);
                return m.reply(`?? Quiz stopped.\n?? Final leaderboard:\n${qz.getLeaderboard().join('\n')}`);
            }

            if (quizData.length === 0) return m.reply('? No quiz questions available.');

            let rounds = parseInt(qargs[1]) || 10;
            if (isNaN(rounds) || rounds < 1) rounds = 10;
            rounds = Math.min(rounds, quizData.length);

            if (activeQuizzes.has(m.channel.id)) return m.reply('? A quiz is already active!');

            const game = new QuizGame(m.channel, m.author.id, rounds);
            activeQuizzes.set(m.channel.id, game);
            await m.reply(`?? **Ninjago Quiz started!** ${rounds} questions. Type \`!quiz stop\` to cancel.\nFirst question in 3 seconds...`);
            setTimeout(() => game.startRound(m), 3000);
            return;
        }

        // -- Help --------------------------------------------------------------

        if (cont.startsWith('!quotequiz')) {
            const qargs = cont.split(' ');
            if (qargs[1] === 'stop') {
                const game = activeQuoteQuizzes.get(m.channel.id);
                if (!game) return m.reply('? No active quote guesser.');
                game.stop();
                activeQuoteQuizzes.delete(m.channel.id);
                return m.reply(`?? Quote Guesser stopped.\n?? Final leaderboard:\n${game.getLeaderboard().join('\n')}`);
            }
            if (quoteData.length === 0) return m.reply('? No quote questions available.');
            let rounds = parseInt(qargs[1]) || 10;
            if (isNaN(rounds) || rounds < 1) rounds = 10;
            rounds = Math.min(rounds, quoteData.length, 20);
            if (activeQuoteQuizzes.has(m.channel.id)) return m.reply('? A quote guesser is already active!');
            const game = new QuoteGuesserGame(m.channel, m.author.id, rounds);
            activeQuoteQuizzes.set(m.channel.id, game);
            await m.reply('?? **Quote Guesser started!** ' + rounds + ' quotes. Type !quotequiz stop to cancel.\nFirst quote in 3 seconds...');
            setTimeout(() => game.startRound(m), 3000);
            return;
        }

        if (cont === '!help') {
            const isAdmin = hasAdminPanelAccess(m.author.id, m.member);
            const embed = new EmbedBuilder()
                    .setTitle('?? NFC Bot Commands')
                .setColor(isAdmin ? 0x42F5A1 : 0xFFFFFF)
                .addFields(
                    { name: '?? Collection',   value: '`!inventory [@user]`, reply `!inv`, `!invlist [@user]`, `!profile [@user]`, `!setfavorite <card>`, `!setelement <power>`, `!wishlist <card|left|clear>`, `!cardscount [@user]`, `!cardsleft [@user]`, `!cardsearch`, `!topcards`, `!rarest`' },
                    { name: '?? Leaderboards', value: '`!lb`, `!serverlb`, `!coinslb`, `!gamelb <episode|quote|quiz|blacktea|greentea|location|set|minifigure|tictactoe|blackjack>`' },
                    { name: '?? Trading',      value: '`!gift @user <coins|card>`, reply `!gift <coins|card>`, `!transferall`, `!trade @user "Card 1, Card 2" "Their Card"`, `!checktrade`, `!duplicates`' },
                    { name: '?? Games',        value: '`!duel`, `!epguesser`, `!locationguesser`, `!setguesser`, `!minifigureguesser`, `!quiz`, `!quotequiz`, `!truth`, `!dare`, `!random`, `!tod`, `!tictactoe @user`, `!blackjack`' },
                    { name: '?? Tea Games',    value: '`!blacktea`, `!greentea` (10 rounds), `!teajoin`, `!teaquit`, `!teastop`' },
                    { name: '?? Economy',      value: '`!balance [@user]`, reply `!balance`, `!shop`, `!buy <slot>`, `!daily`, `!bonus`, `!coinflip <amount|all> [heads/tails]`, `!mines <bet|max 50000> [mines]`' },
                    { name: '?? Fair Play',    value: 'Card catches under **3s** give fast-catch warnings. **2/2** = 5 minute catch block. 5 same-channel catches in a row also triggers a block.' },
                    { name: '?? Roleplay',     value: '`!attack`, `!hug`, `!kill`, `!slap`, `!punch`, `!kiss`, `!highfive`, `!handshake`, `!ciocnesc`' },
                    { name: '?? Notifications',value: '`!notification on/off`' },
                    { name: '?? Admin',        value: '`/admin`, `!setspawnchannel`, `!spawnconfig`, `!setannouncementchannel`\nStaff role can use `/admin` except export DB, mass giveaway, reset leaderboard, and create webhook.' },
                    { name: '?? Info',         value: '`!ping`, `!botinfo`, `!support`, `!suggest <idea>`' }
                )
                .setFooter({ text: `${full ? 'Full Mode' : 'Restricted Mode'} - v${BOT_VERSION}` });
            return m.reply({ embeds: [embed] });
        }

        if (cont.startsWith('!spawncard')) {
            if (!hasAdminPanelAccess(m.author.id, m.member)) return m.reply('? Not authorized.');
            let card = null;
            const picked = args.slice(1).join(' ').trim();
            if (picked) card = findCard(picked);
            if (picked && !card) return m.reply('\u274c Card not found.');
            if (!card) card = ninjagoCards[Math.floor(Math.random() * ninjagoCards.length)];

            const spawnCh = await getSpawnChannel(m.guild) || m.channel;
            const me = m.guild.members.me;
            if (!me || !spawnCh.permissionsFor(me).has(['SendMessages', 'EmbedLinks', 'AttachFiles'])) {
                return m.reply('? I cannot spawn a card there. I need Send Messages, Embed Links, and Attach Files.');
            }

            await sendCatchableCardSpawn(m, spawnCh, card, 'Admin Spawn');
            return m.reply(`? Spawned a card in ${spawnCh}.`);
        }

        // -- Episode Guesser ---------------------------------------------------

        if (cont.startsWith('!epguesser') && full && episodesData.length) {
            let rounds = parseInt(args[1]);
            if (isNaN(rounds) || rounds < 1) return m.reply('? Usage: `!epguesser <rounds>`');
            rounds = Math.min(rounds, episodesData.length);

            if (activeGames.has(m.channel.id)) return m.reply('? A game is already active! Use `!exitgame` to stop.');

            const game = new EpisodeGuesserGame(m.channel, m.author.id, rounds);
            activeGames.set(m.channel.id, game);

            await m.reply(`?? **Episode Guesser started!** ${rounds} round(s). Type \`!exitgame\` to stop.\nFirst episode in 2 seconds...`);

            async function startRound() {
                if (!game.active) return;
                game.currentRound++;

                let avail = episodesData.filter(ep => !game.usedEpisodes.has(ep.id || ep.name) && ep.name && ep.image);
                if (!avail.length) {
                    game.usedEpisodes.clear();
                    avail = episodesData.filter(ep => ep.name && ep.image);
                }
                if (!avail.length) {
                    game.stop();
                    activeGames.delete(m.channel.id);
                    return m.channel.send('? No valid episodes available.');
                }

                const ep = avail[Math.floor(Math.random() * avail.length)];
                game.usedEpisodes.add(ep.id || ep.name);
                game.currentEpisode  = ep;
                game.roundStartedAt  = Date.now();

                await sendEpisodeEmbed(m.channel, ep, game.currentRound, game.totalRounds);

                let answered  = false;
                const collector = m.channel.createMessageCollector({
                    filter: msg => !msg.author.bot && game.active && msg.channel.id === m.channel.id && guesserBlockFilter(msg),
                    time: 30000,
                });

                collector.on('collect', async msg => {
                    if (answered || !msg.content) return;

                    if (msg.content.toLowerCase() === '!exitgame') {
                        answered = true;
                        collector.stop();
                        game.stop();
                        activeGames.delete(m.channel.id);
                        await m.channel.send(`?? Game stopped by ${msg.author.username}.\n\n**Final Scores:**\n${game.getLeaderboard().join('\n')}`);
                        return;
                    }

                    const epName = ep.name || '';
                    if (!epName) return;

                    const sim = stringSimilarity.compareTwoStrings(
                        msg.content.toLowerCase().replace(/[^\w\s]/g, '').trim(),
                        epName.toLowerCase().replace(/[^\w\s]/g, '').trim()
                    );

                    if (sim >= 0.8) {
                        answered = true;
                        collector.stop();
                        game.addPoint(msg.author.id, msg.author.username);
                        const resp = ((Date.now() - game.roundStartedAt) / 1000).toFixed(1);
                        await m.channel.send(
                            `? **${msg.author.username}** guessed correctly! It was Season **${ep.season || '?'}**, Episode **${ep.episode || '?'}**, **${epName}**! (${resp}s)\n+100 NFC Coins!`
                        );
                        await addNFCoins(msg.author.id, 100);

                        if (game.currentRound >= game.totalRounds) {
                            game.stop();
                            activeGames.delete(m.channel.id);
                            const w = game.getWinner();
                            if (w) {
                                await recordGameWin('episode', w.userId);
                                await recordGuesserWin({ id: w.userId, username: w.username, send: (content) => bot.users.fetch(w.userId).then(user => user.send(content)) }, 'Episode Guesser', m.channel);
                            }
                            await m.channel.send({ embeds: [buildEpisodeGameOverEmbed(game)] });
                        } else {
                            game.currentTimeout = setTimeout(() => startRound(), 3000);
                        }
                    }
                });

                collector.on('end', () => {
                    if (game.active && !answered) {
                        const epName = ep.name || 'Unknown';
                        m.channel.send(`? Time's up! Episode was Season **${ep.season || '?'}**, Episode **${ep.episode || '?'}**, **${epName}**.`);

                        if (game.currentRound >= game.totalRounds) {
                            game.stop();
                            activeGames.delete(m.channel.id);
                            const w = game.getWinner();
                            if (w) {
                                recordGameWin('episode', w.userId).catch(() => {});
                                recordGuesserWin({ id: w.userId, username: w.username, send: (content) => bot.users.fetch(w.userId).then(user => user.send(content)) }, 'Episode Guesser', m.channel).catch(() => {});
                            }
                            m.channel.send({ embeds: [buildEpisodeGameOverEmbed(game)] });
                        } else {
                            game.currentTimeout = setTimeout(() => startRound(), 3000);
                        }
                    }
                });
            }

            game.currentTimeout = setTimeout(() => startRound(), 2000);
            return;
        }

        if ((cont === '!locationguesser' || cont === '!locguesser') && full) {
            if (activeGames.has(m.channel.id)) return m.reply('? A game is already active! Use `!exitgame` to stop.');
            try {
                const game = await createLocationGuesserGame(m.channel, m.author.id);
                activeGames.set(m.channel.id, game);
                await m.reply('?? **Location Guesser started!** 10 rounds. Type `!exitgame` to stop.\nFirst location in 2 seconds...');
                game.currentTimeout = setTimeout(() => game.startRound(bot), 2000);
            } catch (error) {
                await m.reply(`❌ Could not start Location Guesser: ${error.message}`);
            }
            return;
        }

        if (cont === '!setguesser' && full) {
            if (activeGames.has(m.channel.id)) return m.reply('? A game is already active! Use `!exitgame` to stop.');
            try {
                const game = await createSetGuesserGame(m.channel, m.author.id);
                activeGames.set(m.channel.id, game);
                await m.reply('?? **Set Guesser started!** 10 rounds. Type `!exitgame` to stop.\nFirst set in 2 seconds...');
                game.currentTimeout = setTimeout(() => game.startRound(bot), 2000);
            } catch (error) {
                await m.reply(`❌ Could not start Set Guesser: ${error.message}`);
            }
            return;
        }

        if ((cont === '!minifigureguesser' || cont === '!minifigguesser') && full) {
            if (activeGames.has(m.channel.id)) return m.reply('? A game is already active! Use `!exitgame` to stop.');
            try {
                const game = await createMinifigureGuesserGame(m.channel, m.author.id);
                activeGames.set(m.channel.id, game);
                await m.reply('?? **Minifigure Guesser started!** 10 rounds. Type `!exitgame` to stop.\nFirst minifigure in 2 seconds...');
                game.currentTimeout = setTimeout(() => game.startRound(bot), 2000);
            } catch (error) {
                await m.reply(`❌ Could not start Minifigure Guesser: ${error.message}`);
            }
            return;
        }

        if ((cont === '!truth' || cont === '!dare' || cont === '!random' || cont === '!tod') && full) {
            const type = cont === '!tod' ? 'random' : cont.slice(1);
            return m.reply(buildTruthDarePromptPayload(type, m.author));
        }

        // -- Exit Game ---------------------------------------------------------

        if (cont === '!exitgame') {
            const g = activeGames.get(m.channel.id);
            if (!g) return m.reply('? No active game.');

            if (g instanceof EpisodeGuesserGame) {
                g.stop();
                activeGames.delete(m.channel.id);
                await m.reply(`?? Game stopped.\n\n**Final Scores:**\n${g.getLeaderboard().join('\n')}`);
            } else if (g instanceof TruthDareGame) {
                g.stop();
                activeGames.delete(m.channel.id);
                await m.reply('?? Truth or Dare stopped.');
            } else if (g instanceof TeaGame) {
                g.stop();
                await m.reply('?? Tea game stopped.');
            } else if (g instanceof QuizGame) {
                g.stop();
                activeQuizzes.delete(m.channel.id);
                await m.reply(`?? Quiz stopped.\n\n**Final Scores:**\n${g.getLeaderboard().join('\n')}`);
            } else {
                g.stop();
                activeGames.delete(m.channel.id);
                await m.reply('?? Game stopped.');
            }
            return;
        }

        // -- Info --------------------------------------------------------------

        if (cont === '!ping') {
            const sent = await m.reply('?? Pinging...');
            await sent.edit(`?? Pong! Latency: ${sent.createdTimestamp - m.createdTimestamp}ms\n?? WebSocket: ${bot.ws.ping}ms`);
            return;
        }

        if (cont === '!botinfo') {
            const servers  = bot.guilds.cache.size;
            const users    = (await db.all('SELECT DISTINCT userId FROM inventory')).length;
            const catches  = (await db.get('SELECT SUM(quantity) as total FROM inventory')).total || 0;
            const upt      = process.uptime();
            await m.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('?? NFC Bot Info')
                        .addFields(
                            { name: 'Servers',            value: `${servers}`,   inline: true },
                            { name: 'Collectors',         value: `${users}`,     inline: true },
                            { name: 'Total Cards Caught', value: `${catches}`,   inline: true },
                            { name: 'Total Cards',        value: `${TOTAL_CARDS}`, inline: true },
                            { name: 'Version',            value: `v${BOT_VERSION}`, inline: true },
                            { name: 'Uptime',             value: `${Math.floor(upt / 86400)}d ${Math.floor((upt % 86400) / 3600)}h ${Math.floor((upt % 3600) / 60)}m`, inline: true },
                            { name: 'Catch Time',         value: `${config.COLLECTION_TIME / 1000}s`, inline: true }
                        )
                        .setColor(0x3498DB),
                ],
            });
            return;
        }

        if (cont === '!support') return m.reply('?? Join support: https://discord.gg/ninjagodragonsrising');
        if (cont.startsWith('!suggest')) {
            if (!m.guild) return m.reply('? Suggestions can only be sent in a server.');
            const text = m.content.slice(args[0].length).trim();
            if (!text) return m.reply('? Usage: `!suggest your idea here`');
            const result = await submitSuggestion({ guild: m.guild, user: m.author, sourceChannel: m.channel, text });
            return m.reply(result.message);
        }

        // -- Inventory / Collection --------------------------------------------

        if ((prefixCmd === '!inventory' || prefixCmd === '!inv') && prefixCmd !== '!invlist') {
            const cards = await db.all(
                'SELECT cardName,quantity FROM inventory WHERE userId=? ORDER BY cardName ASC',
                [target.id]
            );
            if (!cards.length) return m.reply(target.id === m.author.id ? 'Your inventory is empty!' : `${target.username}'s inventory is empty!`);
            return sendInventoryMessage(m.channel, target, cards, m.author.id);
        }

        if (prefixCmd === '!invlist') {
            const cards = await db.all(
                'SELECT cardName,quantity FROM inventory WHERE userId=? ORDER BY cardName ASC',
                [target.id]
            );
            if (!cards.length) return m.reply(target.id === m.author.id ? 'Your inventory is empty!' : `${target.username}'s inventory is empty!`);
            await sendInventoryList(m.channel, target, cards, m.author.id);
            return;
        }

        if (prefixCmd === '!profile') {
            const unique   = (await db.get('SELECT COUNT(*) as c FROM inventory WHERE userId=?', [target.id])).c || 0;
            const total    = (await db.get('SELECT SUM(quantity) as t FROM inventory WHERE userId=?', [target.id])).t || 0;
            const cards    = await db.all('SELECT cardName FROM inventory WHERE userId=?', [target.id]);
            const settings = await getProfileSettings(target.id);
            const fav      = settings.favoriteCard || (cards.length ? cards[Math.floor(Math.random() * cards.length)].cardName : 'None');
            const element  = settings.elementalPower || 'Unset';
            const wishlist = settings.wishlistCard === '__LEFT__' ? 'Left Mode' : (settings.wishlistCard || 'Unset');
            const coins    = await getNFCoins(target.id);
            await m.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle(`?? ${target.username}'s Profile`)
                        .setThumbnail(target.displayAvatarURL())
                        .addFields(
                            { name: 'Unique Cards',    value: `${unique}/${TOTAL_CARDS}`, inline: true },
                            { name: 'Total Catches',   value: `${total}`,                 inline: true },
                            { name: 'NFC Coins',       value: `${coins}`,                 inline: true },
                            { name: 'Rank',            value: getRank(unique),             inline: false },
                            { name: 'Favorite Card',   value: fav,                         inline: true },
                            { name: 'Elemental Power', value: element,                     inline: true },
                            { name: 'Wishlist',        value: wishlist,                    inline: true }
                        )
                        .setColor(0x00AE86),
                ],
            });
            return;
        }

        if (cont.startsWith('!gift')) return handleGiftCommand(m, args, target);

        if (prefixCmd === '!checktrade' || prefixCmd === '!checktrades') {
            const tradeTarget = mention || repliedUser;
            if (!tradeTarget) return m.reply('? Tag someone or reply to their message: `!checktrade @user`');

            const my      = new Set((await db.all('SELECT cardName FROM inventory WHERE userId=?', [m.author.id])).map(c => c.cardName));
            const their   = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=?', [tradeTarget.id]);
            const matches = their.filter(c => !my.has(c.cardName));
            const list    = matches.map(c => `- **${c.cardName}**${c.quantity > 1 ? ` (x${c.quantity})` : ''}`).join('\n').substring(0, 1500);

            await m.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle(`?? Trades with ${tradeTarget.username}`)
                        .setDescription(list || 'No new cards found.')
                        .setColor(0x2ECC71),
                ],
            });
            return;
        }

        if (cont.startsWith('!trade')) {
            const to = m.mentions.users.first();
            if (!to) return m.reply('? Usage: `!trade @user "Your Card, Another" "Their Card"`');
            if (to.id === m.author.id) return m.reply('? Cannot trade with yourself.');

            const quoted = parseQuotedArgs(m.content.replace(/<@!?\d+>/, '').trim());
            if (quoted.length < 2) return m.reply('? Use quotes: `!trade @user "Card1, Card2" "Their Card"`');

            let fromCards, toCards;
            try {
                fromCards = await resolveTradeCards(m.author.id, quoted[0], m.author.id);
                toCards = await resolveTradeCards(to.id, quoted[1], m.author.id);
            } catch (e) {
                return m.reply('? ' + e.message);
            }
            const fromError = await validateTradeBundle(m.author.id, fromCards, m.author.username);
            if (fromError) return m.reply('? ' + fromError);
            const toError = await validateTradeBundle(to.id, toCards, to.username);
            if (toError) return m.reply('? ' + toError);

            const tid = Date.now() + m.author.id;
            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder().setCustomId(`trade_accept_${tid}`).setLabel('? Accept').setStyle(ButtonStyle.Success),
                new ButtonBuilder().setCustomId(`trade_decline_${tid}`).setLabel('? Decline').setStyle(ButtonStyle.Danger)
            );

            const fromText = formatCardBundle(fromCards);
            const toText = formatCardBundle(toCards);
            const fromMsg = await m.channel.send({ content: `${m.author} proposed trade with ${to}: ${fromText} ?? ${toText}.`, components: [row] });
            const toMsg = await to.send({ content: `${m.author.username} wants to trade ${fromText} for your ${toText}. Accept?`, components: [row] }).catch(() => null);
            if (!toMsg) {
                await fromMsg.edit({ content: `? Could not DM ${to.username}.`, components: [] });
                return;
            }
            const timeout = setTimeout(async () => {
                if (pendingTrades.get(tid)) {
                    pendingTrades.delete(tid);
                    await fromMsg.edit({ content: '? Trade expired.', components: [] }).catch(() => {});
                    await toMsg.edit({ content: '? Trade expired.', components: [] }).catch(() => {});
                }
            }, 60000);
            pendingTrades.set(tid, {
                from: { id: m.author.id, username: m.author.username },
                to: { id: to.id, username: to.username },
                fromCards, toCards, fromMsgId: fromMsg.id, toMsgId: toMsg.id,
                fromChannelId: m.channel.id, toChannelId: toMsg.channel.id, timeout
            });
            return;
        }

        if (cont === '!duplicates') {
            const dup = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=? AND quantity>1', [m.author.id]);
            if (!dup.length) return m.reply('You have no duplicate cards.');
            const list = dup.map(c => `- **${c.cardName}** (x${c.quantity})`).join('\n');
            await m.reply({
                embeds: [new EmbedBuilder().setTitle('?? Your Duplicate Cards').setDescription(list).setColor(0x3498DB)],
            });
            return;
        }

        if (cont.startsWith('!duel')) {
            const opp = m.mentions.users.first();
            if (!opp) return m.reply('? Usage: `!duel @user`');
            if (opp.id === m.author.id) return m.reply('? Cannot duel yourself.');

            const uCards = await db.all('SELECT cardName FROM inventory WHERE userId=?', [m.author.id]);
            if (!uCards.length) return m.reply('? You have no cards.');

            const oCards = await db.all('SELECT cardName FROM inventory WHERE userId=?', [opp.id]);
            if (!oCards.length) return m.reply(`? ${opp.username} has no cards.`);

            const uOpt = uCards.slice(0, 25).map(c => ({ label: c.cardName, value: c.cardName }));
            const oOpt = oCards.slice(0, 25).map(c => ({ label: c.cardName, value: c.cardName }));

            const uSel = new StringSelectMenuBuilder().setCustomId('duel_card_select').setPlaceholder('Choose your card').addOptions(uOpt);
            const oSel = new StringSelectMenuBuilder().setCustomId('duel_card_select').setPlaceholder('Choose your card').addOptions(oOpt);

            await m.reply({ content: `${m.author}, choose a card:`, components: [new ActionRowBuilder().addComponents(uSel)] });
            await opp.send({ content: `${opp.username}, ${m.author} challenged you to a duel! Choose a card:`, components: [new ActionRowBuilder().addComponents(oSel)] })
                .catch(() => m.reply(`? Could not DM ${opp.username}.`));

            if (!bot.duelData) bot.duelData = {};
            bot.duelData[m.author.id] = { opponent: opp.id, selectedCard: null };
            bot.duelData[opp.id]      = { opponent: m.author.id, selectedCard: null };

            setTimeout(() => {
                if (bot.duelData[m.author.id] && !bot.duelData[m.author.id].selectedCard) {
                    m.reply('? Duel cancelled.');
                    delete bot.duelData[m.author.id];
                    delete bot.duelData[opp.id];
                }
            }, 60000);
            return;
        }

        if (cont === '!serverlb') {
            const catches = await db.all(
                'SELECT userId,COUNT(*) as count FROM catches WHERE guildId=? GROUP BY userId ORDER BY count DESC LIMIT 10',
                [m.guild.id]
            );
            let desc = '';
            for (let i = 0; i < catches.length; i++) {
                const u = await bot.users.fetch(catches[i].userId).catch(() => null);
                desc += `${i + 1}. **${u ? u.username : 'Unknown'}** - ${catches[i].count} cards\n`;
            }
            const userTotal = (await db.get('SELECT COUNT(*) as count FROM catches WHERE guildId=? AND userId=?', [m.guild.id, m.author.id])).count || 0;
            let rank = 'N/A';
            if (userTotal > 0)
                rank = (await db.get(
                    'SELECT COUNT(*)+1 as r FROM (SELECT userId,COUNT(*) as cnt FROM catches WHERE guildId=? GROUP BY userId HAVING cnt>?)',
                    [m.guild.id, userTotal]
                )).r || '?';
            desc += `\n????????????????\n??? **Your rank:** #${rank} (${userTotal} cards)`;
            await m.reply({
                embeds: [new EmbedBuilder().setTitle(`?? Server Leaderboard - ${m.guild.name}`).setDescription(desc).setColor(0xFFD700)],
            });
            return;
        }

        if (cont === '!lb' || cont === '!leaderboard') {
            const top = await db.all('SELECT userId,SUM(quantity) as total FROM inventory GROUP BY userId ORDER BY total DESC LIMIT 10');
            let desc = '';
            for (let i = 0; i < top.length; i++) {
                const u = await bot.users.fetch(top[i].userId).catch(() => null);
                desc += `${i + 1}. **${u ? u.username : 'Unknown'}** - ${top[i].total} cards\n`;
            }
            const userTotal = (await db.get('SELECT SUM(quantity) as total FROM inventory WHERE userId=?', [m.author.id])).total || 0;
            let rank = 'N/A';
            if (userTotal > 0)
                rank = (await db.get(
                    'SELECT COUNT(*)+1 as r FROM (SELECT userId,SUM(quantity) as total FROM inventory GROUP BY userId HAVING total>?)',
                    [userTotal]
                )).r || '?';
            desc += `\n????????????????\n??? **Your rank:** #${rank} (${userTotal} cards)`;
            await m.reply({
                embeds: [new EmbedBuilder().setTitle('?? Global Leaderboard').setDescription(desc).setColor(0xFFD700)],
            });
            return;
        }

        if (prefixCmd === '!balance') {
            const coins = await getNFCoins(target.id);
            await m.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle(`?? ${target.username}'s NFC Coins Balance`)
                        .setDescription(target.id === m.author.id ? `You have **${coins} NFC Coins**.` : `**${target.username}** has **${coins} NFC Coins**.`)
                        .setColor(0xFFD700),
                ],
            });
            return;
        }

        if (cont === '!coinslb' || cont === '!coinlb') {
            await m.reply({ embeds: [await buildCoinsLeaderboardEmbed(bot, m.author.id)] });
            return;
        }

        if (cont.startsWith('!gamelb')) {
            const gameKey = parseGameLeaderboardInput(args[1]);
            if (!gameKey) {
                return m.reply('Usage: `!gamelb <episode|quote|quiz|blacktea|greentea|location|set|minifigure|tictactoe|blackjack>`');
            }
            const embed = await buildGameLeaderboardEmbed(bot, m.author.id, gameKey);
            if (!embed) {
                return m.reply('Unknown game. Use: `episode`, `quote`, `quiz`, `blacktea`, `greentea`, `location`, `set`, `minifigure`, `tictactoe`, or `blackjack`.');
            }
            await m.reply({ embeds: [embed] });
            return;
        }

        if (prefixCmd === '!cardscount' || prefixCmd === '!count') {
            const u = (await db.get('SELECT COUNT(*) as c FROM inventory WHERE userId=?', [target.id])).c || 0;
            await m.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle(`?? Progress: ${target.username}`)
                        .setColor(0x3498DB)
                        .addFields(
                            { name: 'Cards', value: `**${u}** / ${TOTAL_CARDS}`, inline: true },
                            { name: 'Rank',  value: `**${getRank(u)}**`,          inline: true }
                        ),
                ],
            });
            return;
        }

        if (cont.startsWith('!cardsearch')) {
            const cardName = args.slice(1).join(' ');
            const card = findCard(cardName);
            if (!card) return m.reply('\u274c Card not found.');

            const owners = await db.all('SELECT userId,quantity FROM inventory WHERE cardName=? ORDER BY quantity DESC', [card.name]);
            const desc   = owners.length ? owners.map(o => `<@${o.userId}> - x${o.quantity}`).join('\n') : 'No one owns this card.';

            await m.reply(embedWithImage(new EmbedBuilder().setTitle(`?? Owners of: ${card.name}`).setDescription(desc).setColor(0x3498DB), card.image, 'setThumbnail'));
            return;
        }

        if (prefixCmd === '!cardsleft' || prefixCmd === '!left') {
            const owned   = new Set((await db.all('SELECT cardName FROM inventory WHERE userId=?', [target.id])).map(c => c.cardName));
            const missing = ninjagoCards.filter(c => !owned.has(c.name));
            if (!missing.length) return m.reply('?? All cards collected!');
            const list = formatMissingCardsList(missing);
            await m.reply({
                embeds: [
                    new EmbedBuilder()
                        .setTitle('?? Missing Cards')
                        .setDescription(`Missing **${missing.length}** cards:\n\n${list}`)
                        .setColor(0xE74C3C),
                ],
            });
            return;
        }

        if (cont.startsWith('!transferall')) {
            const targetUser = m.mentions.users.first();
            if (!targetUser) return m.reply('?? Mention a user: `!transferall @user`');
            if (targetUser.id === m.author.id) return m.reply('? Cannot transfer to yourself.');

            const cards = await db.all('SELECT cardName,quantity FROM inventory WHERE userId=?', [m.author.id]);
            if (!cards.length) return m.reply('?? Your inventory is empty.');

            await db.exec('BEGIN IMMEDIATE');
            try {
                for (const c of cards) {
                    await db.run(
                        'INSERT INTO inventory (userId,cardName,quantity) VALUES (?,?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+?',
                        [targetUser.id, c.cardName, c.quantity, c.quantity]
                    );
                    await db.run('DELETE FROM inventory WHERE userId=? AND cardName=?', [m.author.id, c.cardName]);
                }
                await db.exec('COMMIT');
                await m.reply(`?? Transferred **${cards.length}** unique cards to **${targetUser.username}**!`);
            } catch (e) {
                await db.exec('ROLLBACK');
                await m.reply('? Transfer failed.');
            }
            return;
        }

        // -- Full-server-only commands ------------------------------------------

        if (full) {
            if (cont === '!topcards') {
                const top = await db.all('SELECT cardName, SUM(quantity) as total FROM inventory GROUP BY cardName ORDER BY total DESC LIMIT 5');
                if (!top.length) return m.reply('No cards collected yet.');
                let desc = '';
                for (let i = 0; i < top.length; i++) desc += `${i + 1}. **${top[i].cardName}** - ${top[i].total} copies\n`;
                await m.reply({ embeds: [new EmbedBuilder().setTitle('?? Most Owned Cards').setDescription(desc).setColor(0xFFD700)] });
                return;
            }

            if (cont === '!rarest') {
                const rare = await db.all('SELECT cardName, SUM(quantity) as total FROM inventory GROUP BY cardName ORDER BY total ASC LIMIT 5');
                if (!rare.length) return m.reply('No cards collected yet.');
                let desc = '';
                for (let i = 0; i < rare.length; i++) desc += `${i + 1}. **${rare[i].cardName}** - ${rare[i].total} copies\n`;
                await m.reply({ embeds: [new EmbedBuilder().setTitle('?? Rarest Cards').setDescription(desc).setColor(0xE74C3C)] });
                return;
            }

            if (cont === '!notification on')  { await setNotification(m.author.id, true);  await m.reply('? You will now receive DM notifications for rare card spawns.'); return; }
            if (cont === '!notification off') { await setNotification(m.author.id, false); await m.reply('? You will no longer receive DM notifications.'); return; }

            if (cont.startsWith('!tictactoe') || cont.startsWith('!ttt')) {
                if (activeGames.has(m.channel.id)) return m.reply('? A game is already active in this channel.');
                const opponent = m.mentions.users.first();
                if (!opponent) return m.reply('Usage: `!tictactoe @user`');
                if (opponent.bot) return m.reply('Pick a real user, not a bot.');
                if (opponent.id === m.author.id) return m.reply('Pick someone other than yourself.');
                const game = new TicTacToeGame(m.channel, m.author, opponent);
                activeGames.set(m.channel.id, game);
                await m.reply(game.buildStartPayload());
                return;
            }

            if (cont === '!blackjack') {
                if (activeGames.has(m.channel.id)) return m.reply('? A game is already active in this channel.');
                const game = new BlackjackGame(m.channel, m.author);
                activeGames.set(m.channel.id, game);
                await m.reply({ embeds: [game.buildEmbed(false)], components: game.buildRows(false) });
                return;
            }

            // Roleplay commands (require a mention target)
            const rpTarget = mention;
            if (rpTarget) {
                const rpActions = ['!attack','!hug','!kill','!slap','!punch','!kiss','!highfive','!handshake','!ciocnesc'];
                const used      = rpActions.find(a => cont.startsWith(a));

                if (used && used !== '!ciocnesc') {
                    await log('?? Roleplay Used', config.LOG_COLORS.info, [
                        { name: 'Action', value: used.slice(1) },
                        { name: 'User',   value: userField(m.author) },
                        { name: 'Target', value: userField(rpTarget) },
                    ]);
                }

                if (cont.startsWith('!attack'))    return m.channel.send(`? **${m.author.username}** attacks **${rpTarget.username}**!\nhttps://tenor.com/view/jay-ninjago-ninjago-crystalized-jay-jay-ninjago-crystalized-lego-ninjago-gif-2260568897801075940`);
                if (cont.startsWith('!hug'))        return m.channel.send(`?? **${m.author.username}** hugs **${rpTarget.username}**!\nhttps://tenor.com/view/ninjago-lego-ninjago-schploinky-ninjago-dragons-rising-dragons-rising-gif-1691855875669522204`);
                if (cont.startsWith('!kill'))       return m.channel.send(`?? **${m.author.username}** kills **${rpTarget.username}**!\nhttps://tenor.com/view/ras-ninjago-dragons-rising-season-3-ras-lego-ninjago-dragons-rising-season-3-ras-ninjago-dragons-rising-ras-lego-ninjago-dragons-rising-ras-lego-ninjago-gif-6105817875826362931`);
                if (cont.startsWith('!slap'))       return m.channel.send(`?? **${m.author.username}** slaps **${rpTarget.username}**!\nhttps://cdn.discordapp.com/attachments/1282018169044729906/1490698848748699728/b3j7hmm.gif`);
                if (cont.startsWith('!punch'))      return m.channel.send(`?? **${m.author.username}** punches **${rpTarget.username}**!\nhttps://tenor.com/view/ninjago-cinder-ninjago-kai-punch-lego-ninjago-ninjago-dr-s2-gif-2152592207909448368`);
                if (cont.startsWith('!kiss'))       return m.channel.send(`?? **${m.author.username}** kisses **${rpTarget.username}**!\nhttps://imgur.com/hj8b29L`);
                if (cont.startsWith('!highfive'))   return m.channel.send(`? **${m.author.username}** high-fives **${rpTarget.username}**!\nhttps://tenor.com/view/lloyd-ninjago-lloyd-garmadon-nya-ninjago-high-five-team-gif-11354345990016101403`);
                if (cont.startsWith('!handshake'))  return m.channel.send(`?? **${m.author.username}** shakes hands with **${rpTarget.username}**!\nhttps://cdn.discordapp.com/attachments/1403761064465928312/1489992005952999574/Screen_Recording_20260404_171318_YouTube2.gif`);
                if (cont.startsWith('!ciocnesc')) {
                    const winner = Math.random() < 0.5 ? m.author : rpTarget;
                    return m.channel.send({
                        embeds: [
                            new EmbedBuilder()
                                .setTitle('?? Easter Duel!')
                                .setDescription(`**${m.author.username}** & **${rpTarget.username}** crack eggs...\n\nOul lui **${winner.username}** a rar?mas ?ntreg! ??`)
                                .setColor(0xFFD700),
                        ],
                    });
                }
            }
        }

        // ---------------------------------------------------------------------
        // SPAWN SYSTEM (per-server, fires every N messages)
        // ---------------------------------------------------------------------

        if (!botHasAdmin(m.guild)) return;

        const index   = require('../index');
        const tracker = index.getSpawnTracker(m.guild.id);
        tracker.messageCount++;

        const currentCount = tracker.messageCount;
        if (currentCount % 5 === 0)
            console.log(`[LOG] [${m.guild.name}] ${m.channel.name || m.channel.id}: Progress ${currentCount}/${config.SPAWN_LIMIT}`);

        if (currentCount >= config.SPAWN_LIMIT && index.canSpawn(m.guild.id)) {
            tracker.messageCount = 0;

            const me           = m.guild.members.me;
            let   spawnCh      = await getSpawnChannel(m.guild);
            if (!spawnCh) spawnCh = m.channel;

            if (!me || !spawnCh.permissionsFor(me).has(['SendMessages', 'EmbedLinks', 'AttachFiles'])) {
                await log('?? Spawn Skipped - Missing Permissions', config.LOG_COLORS.warning, [
                    { name: 'Server',  value: serverField(m.guild) },
                    { name: 'Channel', value: channelField(spawnCh) },
                    { name: 'Reason',  value: 'Missing SendMessages or EmbedLinks' },
                ]);
                return;
            }

            // Determine rarity
            const rand   = Math.random();
            const rarity = rand < 0.001 ? 'MYTHIC' : (rand < 0.01 ? 'Godly' : (rand < 0.11 ? 'Super Rare' : 'Common'));
            const pool   = ninjagoCards.filter(c => (c.rarity || 'Common') === rarity);
            const card   = pool[Math.floor(Math.random() * pool.length)];
            const rName  = rarity; // alias for clarity below

            // Log the spawn
            await log(
                rarity === 'Godly' ? '?? Godly Card Spawned' : (rarity === 'MYTHIC' ? '?? MYTHIC Card Spawned' : (rarity === 'Super Rare' ? '? Super Rare Card Spawned' : '? Card Spawned')),
                rarity === 'Godly' ? config.LOG_COLORS.warning : (rarity === 'MYTHIC' ? config.LOG_COLORS.mythic : (rarity === 'Super Rare' ? config.LOG_COLORS.gold : config.LOG_COLORS.info)),
                [
                    { name: 'Rarity',  value: rName },
                    { name: 'Server',  value: serverField(m.guild) },
                    { name: 'Channel', value: channelField(spawnCh) },
                ]
            );

            // DM notifications for rare spawns
            if (rarity !== 'Common') {
                const notifUsers = await db.all('SELECT userId FROM notifications WHERE enabled=1');
                for (const u of notifUsers) {
                    try {
                        const user   = await bot.users.fetch(u.userId).catch(() => null);
                        if (!user) continue;
                        const member = await m.guild.members.fetch(user.id).catch(() => null);
                        if (!member) continue;
                        if (!spawnCh.permissionsFor(member).has('ViewChannel')) continue;
                        await user.send(`?? A **${rName}** card has spawned in ${m.guild.name} ${channelField(spawnCh)}! Type its name to catch it!`).catch(() => {});
                    } catch (e) { /* ignore */ }
                }
            }

            const wishlistUsers = await db.all('SELECT userId, wishlistCard FROM profile_settings WHERE wishlistCard IS NOT NULL AND wishlistCard = ?', [card.name]);
            for (const row of wishlistUsers) {
                try {
                    const enabled = await notificationEnabled(row.userId);
                    if (!enabled) continue;
                    const user = await bot.users.fetch(row.userId).catch(() => null);
                    if (!user) continue;
                    const member = await m.guild.members.fetch(user.id).catch(() => null);
                    if (!member) continue;
                    if (!spawnCh.permissionsFor(member).has('ViewChannel')) continue;
                    await user.send(`?? Your wishlist card **${card.name}** just spawned in ${m.guild.name} ${channelField(spawnCh)}! Go catch it!`).catch(() => {});
                } catch (e) { /* ignore */ }
            }

            const leftModeUsers = await db.all("SELECT userId FROM profile_settings WHERE wishlistCard = '__LEFT__'");
            for (const row of leftModeUsers) {
                try {
                    const enabled = await notificationEnabled(row.userId);
                    if (!enabled) continue;
                    const ownsCard = await db.get('SELECT 1 FROM inventory WHERE userId=? AND cardName=?', [row.userId, card.name]);
                    if (ownsCard) continue;
                    const user = await bot.users.fetch(row.userId).catch(() => null);
                    if (!user) continue;
                    const member = await m.guild.members.fetch(user.id).catch(() => null);
                    if (!member) continue;
                    if (!spawnCh.permissionsFor(member).has('ViewChannel')) continue;
                    await user.send(`?? A card you still need just spawned in ${m.guild.name} ${channelField(spawnCh)}! Go catch it!`).catch(() => {});
                } catch (e) { /* ignore */ }
            }

            // Build and send spawn embed
            const spawnEmbed = new EmbedBuilder()
                .setTitle(rarity === 'Godly' ? '?? A GODLY CARD APPEARED!' : (rarity === 'MYTHIC' ? '?? THE CREATOR ARRIVED!' : '? NEW CARD!'))
                .setDescription(`A **${rName}** card has appeared! Type the name to catch it! (${config.COLLECTION_TIME / 1000} seconds)`)
                .setColor(rarity === 'Godly' ? 0xFF5A36 : (rarity === 'MYTHIC' ? 0xFFFFFF : (rarity === 'Super Rare' ? 0xFFD700 : 0xDAA520)));

            const spawnTime = Date.now();
            const mainMsg   = await spawnCh.send(embedWithImage(spawnEmbed, card.image));
            console.log(`[LOG] [${m.guild.name}] ${spawnCh.name || spawnCh.id}: Card Spawned - ${card.name}`);

            const collector = spawnCh.createMessageCollector({
                filter: msg => cardCatchFilter(msg, card.name),
                time: config.COLLECTION_TIME,
                max: 1,
            });

            collector.on('collect', async msg => {
                try {
                    const respTime = Date.now() - spawnTime;
                    await trackFastCardCatch(msg, respTime);
                    await trackChannelCardCatchStreak(msg);
                    catchCount[msg.author.id] = (catchCount[msg.author.id] || 0) + 1;
                    const catchStreak = await recordWinStreak('card_catch', msg.author.id);
                    if (respTime < 400)
                        await log('? Suspiciously Fast Catch', config.LOG_COLORS.danger, [
                            { name: 'User',          value: userField(msg.author) },
                            { name: 'Card',          value: `${card.name} (${rName})` },
                            { name: 'Response Time', value: `${respTime}ms` },
                        ]);

                    if (catchCount[msg.author.id] % 10 === 0)
                        await log('?? High Catch Rate', config.LOG_COLORS.warning, [
                            { name: 'User',              value: userField(msg.author) },
                            { name: 'Cards This Session', value: `${catchCount[msg.author.id]}` },
                        ]);

                    await log('?? Card Caught', config.LOG_COLORS.success, [
                        { name: 'User',          value: userField(msg.author) },
                        { name: 'Card',          value: card.name },
                        { name: 'Rarity',        value: rName },
                        { name: 'Win Streak',    value: `${catchStreak}`, inline: true },
                        { name: 'Response Time', value: `${respTime}ms` },
                    ]);

                    await db.run(
                        'INSERT INTO inventory (userId,cardName) VALUES (?,?) ON CONFLICT(userId,cardName) DO UPDATE SET quantity=quantity+1',
                        [msg.author.id, card.name]
                    );
                    await db.run(
                        'INSERT INTO catches (userId,cardName,guildId,timestamp) VALUES (?,?,?,?)',
                        [msg.author.id, card.name, m.guild.id, Date.now()]
                    );

                    const coinReward = rarity === 'Godly' ? 500 : (rarity === 'MYTHIC' ? 200 : (rarity === 'Super Rare' ? 50 : 10));
                    await addNFCoins(msg.author.id, coinReward);

                    if (await notificationEnabled(msg.author.id))
                        msg.author.send(`?? You caught **${card.name}** (${rName}) in ${respTime}ms! +${coinReward} NFC Coins`).catch(() => {});
                    const catchEmbed = new EmbedBuilder()
                        .setDescription(`**${msg.author.username}** caught **${card.name}**!\n+${coinReward} NFC Coins`)
                        .setColor(rarity === 'Godly' ? 0xFF5A36 : (rarity === 'MYTHIC' ? 0xFFFFFF : (rarity === 'Super Rare' ? 0xFFD700 : 0x00AE86)));
                    await msg.reply(buildCatchReplyPayload(catchEmbed, card, rarity));

                } catch (err) {
                    console.error('? Collector error:', err);
                    require('fs').appendFileSync('crash.log', `[${new Date().toISOString()}] COLLECTOR ERROR: ${err.stack}\n`);
                }
            });

            collector.on('end', async (collected, reason) => {
                if (reason === 'time' && collected.size === 0) {
                    await log('?? Card Fled', config.LOG_COLORS.fled, [
                        { name: 'Card',    value: card.name },
                        { name: 'Rarity',  value: rName },
                        { name: 'Server',  value: serverField(m.guild) },
                        { name: 'Channel', value: channelField(spawnCh) },
                    ]);
                    const fledEmbed = EmbedBuilder.from(spawnEmbed)
                        .setTitle('?? FLED...')
                        .setDescription(`Too slow! The **${rName}** card was **${card.name}**.`)
                        .setColor(0xFF0000);
                    mainMsg.edit({ embeds: [fledEmbed] }).catch(() => {});
                }
            });
        }

    } catch (e) {
        console.error('? Message handler error:', e);
        require('fs').appendFileSync('crash.log', `[${new Date().toISOString()}] MESSAGE HANDLER ERROR: ${e.stack}\n`);
    }
}

module.exports = { handlePrefixMessage };

