const { getDb } = require('./database');

async function getNFCoins(uid) {
    const db = getDb();
    const r = await db.get('SELECT nfcoins FROM economy WHERE userId = ?', [uid]);
    return r ? r.nfcoins : 0;
}

async function addNFCoins(uid, amt) {
    const db = getDb();
    await db.run('INSERT INTO economy (userId, nfcoins) VALUES (?, ?) ON CONFLICT(userId) DO UPDATE SET nfcoins = nfcoins + ?', [uid, amt, amt]);
}

async function removeNFCoins(uid, amt) {
    const cur = await getNFCoins(uid);
    if (cur < amt) return false;
    const db = getDb();
    await db.run('UPDATE economy SET nfcoins = nfcoins - ? WHERE userId = ?', [amt, uid]);
    return true;
}

async function grantTemporaryNFCoins(uid, amt, durationMs = 5 * 60 * 1000) {
    const db = getDb();
    const expiresAt = Date.now() + durationMs;
    await addNFCoins(uid, amt);
    await db.run('INSERT INTO temp_point_grants (userId, amount, expiresAt, reverted) VALUES (?, ?, ?, 0)', [uid, amt, expiresAt]);
    setTimeout(() => revertExpiredTemporaryGrants().catch(console.error), durationMs + 1000);
    return expiresAt;
}

async function revertExpiredTemporaryGrants() {
    const db = getDb();
    const rows = await db.all('SELECT * FROM temp_point_grants WHERE reverted = 0 AND expiresAt <= ?', [Date.now()]);
    for (const row of rows) {
        await addNFCoins(row.userId, -row.amount);
        await db.run('UPDATE temp_point_grants SET reverted = 1 WHERE id = ?', [row.id]);
    }
    return rows.length;
}

module.exports = { getNFCoins, addNFCoins, removeNFCoins, grantTemporaryNFCoins, revertExpiredTemporaryGrants };
